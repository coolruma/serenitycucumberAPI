package com.wealth.trading.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

public class PortfolioTransactingPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();

	@FindBy(id = "f1:accsearch:accountSearch")
	private WebElementFacade accountSearchField;

	@FindBy(xpath = "//a[@class='ui-corner-all']")
	private WebElementFacade accountMenuItem;

	@FindBy(css = ".jumpersMenuPrimary span")
	private WebElementFacade newTransactionSpan;

	@FindBy(linkText = "Buy new listed security")
	private WebElementFacade buyNewListedSecurityLink;
	
	@FindBy(linkText = "Buy new managed investments")
	private WebElementFacade buyNewManagedInvestmentsLink;

	@FindBy(id = "f1:modaldec:lsModalView:securityCode")
	private WebElementFacade securityCodeSearchField;
	
	@FindBy(partialLinkText = "CBA - ")
	private WebElementFacade securityMenuItem; // to be removed -- currently
												// enhanced in method to make it
												// dynamic

	@FindBy(id = "jq-spinnerContainer")
	private WebElementFacade spinnerContainer;

	@FindBy(id = "f1:modaldec:lsModalView:quantityField")
	private WebElementFacade quantityField;

	@FindBy(id = "f1:modaldec:lsModalView:executeField")
	private WebElementFacade executeField;

	@FindBy(id = "f1:modaldec:lsModalView:limitField")
	private WebElementFacade limitField;

	@FindBy(id = "f1:modaldec:lsModalView:expirationField")
	private WebElementFacade expirationField;

	@FindBy(xpath = "//a[@class='jq-continue jq-jsf primaryButton']")
	private WebElementFacade modalContinueButton;

	@FindBy(xpath = "//a[@class='jq-generate jq-jsf primaryButton']")
	private WebElementFacade generateOrdersButton;
	
	
	@FindBy(id="f1:modaldec:miModalView:miCode")
	private WebElementFacade buyManagedInvestmentsSearchField;
	
	@FindBy(id="f1:modaldec:miModalView:tradeValueField")
	private WebElementFacade buyManagedInvestmentsAmountField;

	public void searchForAccount(String accountCode) {
		accountSearchField.waitUntilClickable();
		accountSearchField.click();
		accountSearchField.sendKeys(accountCode);
		accountMenuItem.waitUntilClickable();
		accountMenuItem.click();
		pageUtils.waitForInvisibility(spinnerContainer, 20);

	}

	public void openBuyNewListedSecurityModal() {

		((JavascriptExecutor) getDriver())
				.executeScript("var grandparent = document.getElementsByClassName('jq-jumpNavigationPort jumpNavigation');var parents = grandparent[0].children;var parent = parents[1];var children = parent.children;var child = children[1];child.style.cssText = 'visibility: visible; display: block;'");

		buyNewListedSecurityLink.waitUntilVisible();
		buyNewListedSecurityLink.click();
		pageUtils.waitForInvisibility(spinnerContainer, 20);
	
	}
	
	public void openBuyNewManagedInvestmentsScreen() {

		((JavascriptExecutor) getDriver())
				.executeScript("var grandparent = document.getElementsByClassName('jq-jumpNavigationPort jumpNavigation');var parents = grandparent[0].children;var parent = parents[1];var children = parent.children;var child = children[1];child.style.cssText = 'visibility: visible; display: block;'");

		buyNewManagedInvestmentsLink.waitUntilVisible();
		buyNewManagedInvestmentsLink.click();
		pageUtils.waitForInvisibility(spinnerContainer, 20);


	}

	public void enterEquityTradeInfo(String securityCode, String quantity,
			String executeAt, String limit, String expiration) {
		
		pageUtils.fluentWaitElement(
				By.id("f1:modaldec:lsModalView:securityCode"),
				10);
		securityCodeSearchField.waitUntilVisible();
		securityCodeSearchField.sendKeys(securityCode);
		
		pageUtils.fluentWaitElement(
				By.partialLinkText(securityCode.trim().toUpperCase() + " -"),
				10);
		pageUtils.fluentWaitElementSerenity(
				By.partialLinkText(securityCode.trim().toUpperCase() + " -"),
				10).waitUntilEnabled();
		pageUtils.fluentWaitElement(
				By.partialLinkText(securityCode.trim().toUpperCase() + " -"))
				.click();
		spinnerContainer.waitUntilVisible();
		spinnerContainer.waitUntilNotVisible();
		quantityField.waitUntilEnabled();
		quantityField.clear();
		quantityField.sendKeys(quantity);
		executeField.waitUntilEnabled();
		executeField.selectByValue(executeAt);
		if ("limit".equals(executeAt)) {
			limitField.waitUntilEnabled();
			limitField.clear();
			limitField.sendKeys(limit);
		}

		expirationField.waitUntilEnabled();
		expirationField.selectByValue(expiration);
		modalContinueButton.waitUntilPresent();
		modalContinueButton.click();
		pageUtils.waitForInvisibility(spinnerContainer, 20);
	}
	
	public void enterManagedInvestmentInfo(String securityCode, String amount) {
		
		pageUtils.fluentWaitElement(
				By.id("f1:modaldec:miModalView:miCode"),
				10);
		buyManagedInvestmentsSearchField.waitUntilVisible();
		buyManagedInvestmentsSearchField.sendKeys(securityCode);
		pageUtils.fluentWaitElement(
				By.partialLinkText(securityCode.trim().toUpperCase() + " -"),
				10);
		pageUtils.fluentWaitElementSerenity(
				By.partialLinkText(securityCode.trim().toUpperCase() + " -"),
				10).waitUntilEnabled();
		pageUtils.fluentWaitElement(
				By.partialLinkText(securityCode.trim().toUpperCase() + " -"))
				.click();
		spinnerContainer.waitUntilVisible();
		spinnerContainer.waitUntilNotVisible();
		buyManagedInvestmentsAmountField.waitUntilEnabled();
		buyManagedInvestmentsAmountField.clear();
		buyManagedInvestmentsAmountField.sendKeys(amount);
		modalContinueButton.waitUntilPresent();
		modalContinueButton.click();
		pageUtils.waitForInvisibility(spinnerContainer, 20);
	}

	public void generateOrders() {
		pageUtils.fluentWaitElement(
				By.xpath("//a[@class='jq-generate jq-jsf primaryButton']"), 20);
		pageUtils.fluentWaitElementSerenity(
				By.xpath("//a[@class='jq-generate jq-jsf primaryButton']"), 20)
				.waitUntilEnabled();
		generateOrdersButton.click();
		pageUtils.waitForInvisibility(spinnerContainer, 20);

	}

}
