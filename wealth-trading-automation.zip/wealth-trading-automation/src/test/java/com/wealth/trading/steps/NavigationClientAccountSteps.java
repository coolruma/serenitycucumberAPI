package com.wealth.trading.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;

import net.thucydides.core.annotations.Screenshots;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import com.wealth.trading.models.SetGetAccountNumber;
import com.wealth.trading.pages.AuthoriseOrdersPage;
import com.wealth.trading.pages.LoginPage;
import com.wealth.trading.pages.OrderConfirmationPage;
import com.wealth.trading.pages.PortfolioTransactingPage;

public class NavigationClientAccountSteps extends ScenarioSteps {
	LoginPage loginPage;
	PortfolioTransactingPage portfolioTransactingPage;
	OrderConfirmationPage orderConfirmationPage;
	AuthoriseOrdersPage authoriseOrdersPage;
	static com.wealth.trading.pages.HomePage HomePage;
	com.wealth.trading.pages.ClientDetailsPage	ClientDetailsPage;
	//static com.wealth.trading.models.SetGetAccountNumber SetGetAccountNumber;
	static com.wealth.trading.models.SetGetAccountNumber setGetAccountNumber=new SetGetAccountNumber();
	
	@SuppressWarnings("static-access")
	@Step
	public static void SetAccountNumber(String BV, String ClientOrAccount, String SQL) throws IOException{
		
		if(ClientOrAccount.toUpperCase().equalsIgnoreCase("NA")){
			
			ClientOrAccount = HomePage.getDBAccountNumber(BV,SQL);
			
			System.out.println("the DB account value is ---"+ClientOrAccount);
			setGetAccountNumber.setAccountNumber(ClientOrAccount);
			
		}
		setGetAccountNumber.setAccountNumber(ClientOrAccount);
	}
	
	@Step
	public void Client_Account_Search(String BV) throws IOException {
		
				
		HomePage.clientAccountSearch(BV,setGetAccountNumber.getAccountNumber());		
		
	}
	
	@Step
	public String getAccountNumber(String BV) throws IOException {
		
				
		return setGetAccountNumber.getAccountNumber();		
		
	}
	
	@Step
	public void log(String message) {}
	
	@Step
	public void ModifyFileNotes(String BV){
		
		ClientDetailsPage.modifyFileNotes(BV);
		
	}
	
	@Step
	public void verify_ListItems_Choose(String BV, String AccountType){
		
		ClientDetailsPage.verifylistItem_ChooseDropDown(BV, AccountType);
		
	}
	
	@Step
	@Screenshots(forEachAction=true)
	public void verify_ClientAccountNavigations(String BV) throws InterruptedException, IOException{
		
			
		ClientDetailsPage.UpdateClientDetails(BV, setGetAccountNumber.getAccountNumber());
		ClientDetailsPage.verifyNavigation_ChooseDropDown(BV,setGetAccountNumber.getAccountNumber());
		
	}
	
	
}
