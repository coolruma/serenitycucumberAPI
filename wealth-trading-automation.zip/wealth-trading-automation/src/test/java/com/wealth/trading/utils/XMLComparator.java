package com.wealth.trading.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.DifferenceListener;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Node;

public class XMLComparator extends XMLTestCase {

	private static final Log log = LogFactory.getLog(XMLComparator.class);

	private static final String[] IGNORE_TAGS = new String[] { ".*\\/CorrespondenceIdentifierList.*", };
	private static final String[] IGNORE_VALUES = new String[] { ".*201\\d-\\d\\d-\\d\\d.*", };

	public void assertXMLEquals(String xml1, String xml2) throws Exception {
		Diff diff = compareXML(xml1, xml2);

		diff.overrideDifferenceListener(new DifferenceListener() {

			private boolean isIgnoredDifference(Difference difference) {
				String controlTag = difference.getControlNodeDetail().getXpathLocation().toString();
				log.debug("Found difference in tag " + controlTag);
				for (int i = 0; i < IGNORE_TAGS.length; ++i) {
					if (controlTag.matches(IGNORE_TAGS[i])) {
						log.debug("Ignoring difference in tag " + controlTag);
						return true;
					}
				}

				String controlValue = difference.getControlNodeDetail().getNode().toString();
				log.debug("Found difference in value " + controlValue);
				for (int i = 0; i < IGNORE_VALUES.length; ++i) {
					if (controlValue.matches(IGNORE_VALUES[i])) {
						log.debug("Ignoring difference in value" + controlValue);
						return true;
					}
				}

				return false;
			}

			@Override
			public void skippedComparison(Node arg0, Node arg1) {

			}

			@Override
			public int differenceFound(Difference difference) {
				if (isIgnoredDifference(difference)) {
					return RETURN_IGNORE_DIFFERENCE_NODES_IDENTICAL;
				} else {
					return RETURN_ACCEPT_DIFFERENCE;
				}
			}
		});

		log.debug("XMLs similar? " + diff.similar());
		log.debug("XMLs identical? " + diff.identical());
		DetailedDiff detailedDiff = new DetailedDiff(diff);
		for (Object object : detailedDiff.getAllDifferences()) {
			Difference difference = (Difference) object;
			log.debug("Difference found: " + difference);
		}
		assertTrue(diff.similar());
	}

}
