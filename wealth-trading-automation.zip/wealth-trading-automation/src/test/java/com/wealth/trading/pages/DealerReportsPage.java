package com.wealth.trading.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class DealerReportsPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();
	HomePage HomePage = new HomePage();

	@FindBy(xpath = "(//*[contains(text(), 'all')])[1]")
	private WebElementFacade lnk_allReportByDealer;
	
	@FindBy(xpath = "//*[contains(text(), 'report by dealer')]")
	private WebElementFacade elm_ReportByDealer;
	
	public void navigate_ReportByDealerScreen(String BV) {
		
		if(lnk_allReportByDealer.isPresent()){
			
			//pageUtils.log("This option exists for " +BV);
			lnk_allReportByDealer.waitUntilVisible();
			lnk_allReportByDealer.click();
			elm_ReportByDealer.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'report by dealer')]")).getText()).containsIgnoringCase("report by dealer");
			Serenity.takeScreenshot();
		} else {
			
			//pageUtils.log("This option does not exist for " +BV);
		}
		
	}
	
	@FindBy(xpath = "(//a[contains(text(), 'download')])[1]")
	private WebElementFacade lnk_Download;
	
	@FindBy(xpath = "//span[contains(text(), 'select download function')]")
	private WebElementFacade elm_SelectDownload;
	
	public void navigate_DownloadFiles(String BV) {
		
		if(lnk_Download.isPresent()){
			
			//pageUtils.log("This option exists for " +BV);
			lnk_Download.waitUntilVisible();
			lnk_Download.click();
			elm_SelectDownload.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'select download function')]")).getText()).containsIgnoringCase("select download function");
			Serenity.takeScreenshot();
			
		} else {
			
			//pageUtils.log("This option does not exist for " +BV);
		}
				
	}
	
	@FindBy(xpath = "//*[contains(text(), 'esi auth')]")
	private WebElementFacade lnk_esiAuth;
	
	@FindBy(xpath = "(//*[contains(text(), 'esi')])[3]")
	private WebElementFacade elm_Esi;
	
	public void navigate_esiAuthDetails(String BV) {
		
		if(lnk_esiAuth.isPresent()){
			
			//pageUtils.log("This option exists for " +BV);
			lnk_esiAuth.waitUntilVisible();
			lnk_esiAuth.click();
			elm_Esi.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'esi')])[3]")).getText()).containsIgnoringCase("esi");
			Serenity.takeScreenshot();
		}else {
			
			//pageUtils.log("This option does not exist for " +BV);
		}
		
	}
	
	@FindBy(xpath = "//*[contains(text(), 'fee dis')]")
	private WebElementFacade lnk_feedisclosurestmt;
	
	@FindBy(xpath = "//*[contains(text(), 'Maintain FDS Profiles')]")
	private WebElementFacade elm_feedisclosurestmt;
	
	@FindBy(xpath = "//*[@id='serviceProfileSearchForm:profilesearch:serviceProfileSearch']")
	private WebElementFacade txt_profileSearch;
	
	
	public void navigate_feeDisclosureStmt(String BV) {
		
		if(lnk_feedisclosurestmt.isPresent()){
		
			//pageUtils.log("This option exists for " +BV);
			lnk_feedisclosurestmt.waitUntilVisible();
			lnk_feedisclosurestmt.click();
			elm_feedisclosurestmt.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'Maintain FDS Profiles')]")).getText()).containsIgnoringCase("Maintain FDS Profiles");
			txt_profileSearch.click();
			Serenity.takeScreenshot();
		}else {
			
			//pageUtils.log("This option does not exist for " +BV);
		}
				
	}
	
	@FindBy(xpath = "//*[contains(text(), 'Recipient')]")
	private WebElementFacade lnk_RecipientCreatedTaxInvoices;
	
	@FindBy(xpath = "(//*[contains(text(), 'Recipient Created Tax Invoices (RCTIs)')])[2]")
	private WebElementFacade elm_RecipientCreatedTaxInvoices;
	
	public void navigate_RCTI(String BV) {
		
		if(lnk_RecipientCreatedTaxInvoices.isPresent()){
		
			//pageUtils.log("This option exists for " +BV);
			lnk_RecipientCreatedTaxInvoices.waitUntilVisible();
			lnk_RecipientCreatedTaxInvoices.click();
			elm_RecipientCreatedTaxInvoices.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'Recipient Created Tax Invoices (RCTIs)')])[2]")).getText()).containsIgnoringCase("Recipient Created Tax Invoices");
			Serenity.takeScreenshot();			
		}else {
			
			//pageUtils.log("This option does not exist for " +BV);
		}
				
	}
	
	
}
