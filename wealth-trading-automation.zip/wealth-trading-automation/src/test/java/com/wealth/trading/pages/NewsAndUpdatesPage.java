package com.wealth.trading.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class NewsAndUpdatesPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();
	HomePage HomePage = new HomePage();

	@FindBy(xpath = "//*[contains(text(), 'latest')]")
	private WebElementFacade lnk_latestNews;
	
	@FindBy(xpath = "(//*[contains(text(), 'latest')])[2]")
	private WebElementFacade lnk_latestNewsING;
	
	@FindBy(xpath = "//span[contains(text(), 'latest')]")
	private WebElementFacade elm_latestNews;
	
	
	public void navigate_latestNews(String BV) {
						
			HomePage.NavigateNewsNUpdates(BV);
			
			if(BV.toUpperCase().contains("ING")){
				
				lnk_latestNewsING.waitUntilVisible();
				lnk_latestNewsING.click();
				
			}else {
				
				lnk_latestNews.waitUntilVisible();
				lnk_latestNews.click();
			}
			
			
			elm_latestNews.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'latest')]")).getText()).containsIgnoringCase("latest news");
			Serenity.takeScreenshot();
		
	}
	

	@FindBy(xpath = "//*[contains(text(), 'investment m')]")
	private WebElementFacade lnk_InvestmentMenu;
	
	@FindBy(xpath = "(//*[contains(text(), 'investment m')])[2]")
	private WebElementFacade lnk_InvestmentMenuING;
	
	@FindBy(xpath = "//span[contains(text(), 'investment m')]")
	private WebElementFacade elm_InvestmentMenu;
	
	public void navigate_InvestmentMenu(String BV) {
		
		HomePage.NavigateNewsNUpdates(BV);
		
		
		if(BV.toUpperCase().contains("ING")){
			
			lnk_InvestmentMenuING.waitUntilVisible();
			lnk_InvestmentMenuING.click();
			
		}else {
			
			lnk_InvestmentMenu.waitUntilVisible();
			lnk_InvestmentMenu.click();
		}
					
		elm_InvestmentMenu.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'investment m')]")).getText()).containsIgnoringCase("investment menu");
		Serenity.takeScreenshot();
	
	}
	
	@FindBy(xpath = "//*[contains(text(), 'distribution')]")
	private WebElementFacade lnk_distributionUpdate;
	
	
	public void NavigateDistributionUpdate(String BV){
		
		String parentWindowHandle = getDriver().getWindowHandle();
	
		HomePage.NavigateNewsNUpdates(BV);
		
		pageUtils.WrapHeaderMenuNavigation(lnk_distributionUpdate);
				
		
		for(int a =1; a <=5; a++ ){									
			if(getDriver().getWindowHandles().size()>1){						
				break;
			}
		}			
		
		for(String handle : getDriver().getWindowHandles()){		
				
				getDriver().switchTo().window(handle);						
		}
				
		assertThat(getDriver().getCurrentUrl()).containsIgnoringCase("distupda");
		
		Serenity.takeScreenshot();
		getDriver().close();
		getDriver().switchTo().window(parentWindowHandle);
		
	}
			
	
}
