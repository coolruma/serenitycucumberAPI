package com.wealth.trading.models;

public class SetGetAccountNumber {

	public String accountNumber;


	public void setAccountNumber(String AccountNumber) {
		this.accountNumber = AccountNumber;
	
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}


}
