package com.wealth.trading.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

public class AuthoriseOrdersPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();

	@FindBy(id = "jq-spinnerContainer")
	private WebElementFacade spinnerContainer;

	@FindBy(name = "f1:a1:j_idt331")
	private WebElementFacade confirmCheckbox;

	@FindBy(name = "f1:a1:j_idt344")
	private WebElementFacade accessCodeField;

	@FindBy(name = "f1:a1:j_idt346")
	private WebElementFacade passwordField;

	@FindBy(id = "f1:a1:actions-authorise")
	private WebElementFacade authoriseButton;

	public void populateAuthorizationForm(String accessCode, String password) {
		// spinnerContainer.waitUntilVisible();
		pageUtils.fluentWaitElement(By.name("f1:a1:j_idt344"), 20);
		accessCodeField.waitUntilVisible();
		// accessCodeField.clear();
		// accessCodeField.sendKeys(accessCode);
		passwordField.sendKeys(password);
		confirmCheckbox.click();
	}

	public void populateAuthorizationForm(String password) {
		pageUtils.fluentWaitElement(By.name("f1:a1:j_idt346"), 30);
		passwordField.waitUntilVisible();
		passwordField.sendKeys(password);
		confirmCheckbox.click();
	}

	public void clickAuthoriseButton() {
		authoriseButton.click();
		spinnerContainer.waitUntilVisible();
		pageUtils.waitForInvisibility(spinnerContainer, 20);
	}
}
