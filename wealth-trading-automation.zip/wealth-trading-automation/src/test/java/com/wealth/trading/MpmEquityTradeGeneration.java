package com.wealth.trading;

import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/TradeGeneration/mpm_equity_trade_generation.feature")
public class MpmEquityTradeGeneration {
}
