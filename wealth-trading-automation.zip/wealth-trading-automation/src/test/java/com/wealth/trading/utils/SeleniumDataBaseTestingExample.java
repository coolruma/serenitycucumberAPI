package com.wealth.trading.utils;
//import org.testng.Assert;
//import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class SeleniumDataBaseTestingExample {

    //Test to verify Employee ID '1' has employee name 'Jack'
    @Test
	
    public void testVerifySpecificRecord() {
        //String sqlQuery = "SELECT top 1 account_code FROM  sd065_account_search l WHERE  l.bus_ven_id IN ('MPM') and l.adviser_id in ('ZAMMIT', 'LANTER', 'STONE1', 'PLAZA', 'N01DAS') and l.product IN ('IM') AND l.account_status ='Active'";
    	String sqlQuery ="SELECT top 1 l.account_code FROM sd078_holding h, sd065_account_search l, sd_main..sd003_register_entity e, aa_holding aa, aa_asset asset WHERE h.client_id = l.account_code and l.bus_ven_id IN ('MPM') and l.product IN ('IC') AND l.account_status ='Active' and h.units > 5000 and e.entity_type = 'V' and e.access_code = '60006754'and substring(e.entity_key, 1, 4) = l.dealer_id and substring(e.entity_key, 5,6 ) = l.adviser_id";
        String expectedEmpName = "CASH";
        //Getting employee name by Id
        String actualEmpNameById = DataBaseConnector.executeSQLQuery("Test2", sqlQuery);
        System.out.println("Employee name retrieved from database :" + actualEmpNameById);

        //org.junit.Assert.assertEquals(expectedEmpName, actualEmpNameById);
    }

    //Test to verify Employee table has a record with employee name 'Jack'
    //@Test(priority = 2)
    /*public void tesVerifyListOfRecords() {
        boolean flag = false;
        List<String> listOfDBValues = new ArrayList<String>();
        String expEmployeeName = "Jack";
        String sqlQuery = "select EmpName from employee";
        //Getting list of employee names from employee table
        listOfDBValues = DataBaseConnector.executeSQLQuery_List("QA", sqlQuery);
        for (String strName : listOfDBValues) {
            if (strName.equalsIgnoreCase(expEmployeeName)) {
                flag = true;
                break;
            }
        }
        //Assert.assertTrue(flag, "Retrieved values are not matching with Expected values");
    }*/

}
