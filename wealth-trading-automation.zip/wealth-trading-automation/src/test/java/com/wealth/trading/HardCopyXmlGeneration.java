package com.wealth.trading;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/GenerateHardCopyXml/generate_hardcopy_xml.feature")
public class HardCopyXmlGeneration {

}
