package com.wealth.trading.models;

public class SetGetTestEnv {

	public String testEnv;


	public void settestEnv(String testEnv) {
		this.testEnv = testEnv;
	
	}

	public String gettestEnv() {
		return this.testEnv;
	}


}
