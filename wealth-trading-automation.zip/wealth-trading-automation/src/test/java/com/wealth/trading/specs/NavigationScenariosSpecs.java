package com.wealth.trading.specs;

import java.io.IOException;
import java.util.List;

import net.thucydides.core.annotations.Steps;

import com.wealth.trading.steps.TransactingSteps;
import com.wealth.trading.utils.PageObjectUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;

public class NavigationScenariosSpecs {
	PageObjectUtils pageUtils = new PageObjectUtils();

	@Steps
	com.wealth.trading.steps.NavigationClientAccountSteps NavigationClientAccountSteps;

	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser obtains the \"(.*)\" using \"(.*)\" if applicable")
	public void setAccountNumber(String BV, String ClientOrAccount, String SQL) throws IOException{
		
		NavigationClientAccountSteps.SetAccountNumber(BV, ClientOrAccount, SQL);
		
	}
	
	@When("^the \"(.*)\" adviser obtains the client details screen")	
	public void navigateToPortfolioTransactingWithSearchAccount(String BV) throws IOException {
		NavigationClientAccountSteps.log("The account number being used in this scenario is -- "+NavigationClientAccountSteps.getAccountNumber(BV));
		NavigationClientAccountSteps.Client_Account_Search(BV);
		
	}
	
	@Then("^adviser can modify the file notes for \"(.*)\"")	
	public void ModifyFileNotes(String BV) {
		
		NavigationClientAccountSteps.ModifyFileNotes(BV);
		
	}
	
	@And("^the adviser can verify the values in the choose dropdown for \"(.*)\" and for \"(.*)\"")	
	public void Verify_ChooseDropDownValues(String BV, String AccountType) {
		
		NavigationClientAccountSteps.verify_ListItems_Choose(BV, AccountType);;
		
	}
	
	@And("^the \"(.*)\" adviser can perform all the client account navigations for the account")	
	public void Verify_ClientAccountNavigations(String BV) throws InterruptedException, IOException {
		
		NavigationClientAccountSteps.verify_ClientAccountNavigations(BV);
		
	}

}
