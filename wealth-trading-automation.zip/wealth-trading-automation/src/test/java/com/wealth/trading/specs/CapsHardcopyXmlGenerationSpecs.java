package com.wealth.trading.specs;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.wealth.trading.steps.CapsHardcopyXmlGenerationSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class CapsHardcopyXmlGenerationSpecs {
	
	private static final Log log = LogFactory.getLog(CapsHardcopyXmlGenerationSpecs.class);
	
	@Steps
	CapsHardcopyXmlGenerationSteps hardcopySteps;
		
	@Given("Corporate action with id (\\d+) of type (.*) exists")	
	public void verifyCorporateActionData(int capsId, String actionType) throws IOException {
		hardcopySteps.retrieveCorporateAction(capsId);
		log.debug("Caps id is :" + capsId);
		log.debug("Action type is :" + actionType);
	}
	
	@When("an advisory hardcopy request has been generated for id (\\d+)")	
	public void generateRequest(int capsId) {
		hardcopySteps.generateRequest(capsId);
	}
	
	@When("hardcopy batch has processed the request")	
	public void processRequest() {
		hardcopySteps.processRequest();
	}
	
	@Then("Generated Xml should match expected xml (.*)")	
	public void verifyXml(String filename) throws Exception {
		hardcopySteps.verifyXml(filename);
	}
}
