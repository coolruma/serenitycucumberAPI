package com.wealth.trading.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.fail;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.wealth.trading.utils.DataBaseConnector;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class EmailBouncebackSteps extends ScenarioSteps {

	private static final long serialVersionUID = 1L;
	private static final Log log = LogFactory.getLog(DataBaseConnector.class);

	@Step
	public void setEmailInitialStatus(String id, String initialStatus) {
		try {
			DataBaseConnector.executeUpdateSQL(
					"update sd_caps_adviser_email_client set status = '" + initialStatus + "' where id = " + id);
		} catch (SQLException e) {
			log.error("Error setEmailInitialStatus", e);
			fail("Error setEmailInitialStatus");
		}
	}

	@Step
	public void callReportingServiceStoredProcedure(String corroID, String reportStatus) {
		String returnValue = "";
		String returnOutput = "";

		try {
			CallableStatement proc = DataBaseConnector
					.prepareStoredProc("{call sd_caps_docgen_status_upd(?, ?, ?, ?)}");

			proc.setString(1, corroID);
			proc.setString(2, reportStatus);
			proc.registerOutParameter(3, Types.VARCHAR);
			proc.registerOutParameter(4, Types.VARCHAR);

			proc.execute();

			returnValue = proc.getString(3);
			returnOutput = proc.getString(4);

			log.debug("returnValue " + returnValue);
			log.debug("returnOutput " + returnOutput);
			assertThat(returnValue, notNullValue());
			assertThat(returnOutput, notNullValue());

			proc.close();
			proc.getConnection().close();
		} catch (SQLException e) {
			log.error("Error callReportingServiceStoredProcedure", e);
			// dont fail as some have expected exception
		}
	}

	@Step
	public void confirmUpdatedStatus(String id, String updatedStatus) {
		String sql = "select status from sd_caps_adviser_email_client where id = " + id;
		String result = null;
		try {
			result = DataBaseConnector.executeSQLQuery(sql);
		} catch (SQLException e) {
			log.error("Error confirmUpdatedStatus", e);
			fail("Error confirmUpdatedStatus");
		}
		assertThat(result, equalTo(updatedStatus));
	}

}
