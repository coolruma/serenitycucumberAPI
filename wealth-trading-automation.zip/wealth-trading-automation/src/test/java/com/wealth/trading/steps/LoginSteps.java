package com.wealth.trading.steps;

import java.io.IOException;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import com.wealth.trading.models.SetGetAccountNumber;
import com.wealth.trading.models.SetGetTestEnv;
import com.wealth.trading.pages.LoginPage;


public class LoginSteps extends ScenarioSteps {
	static LoginPage loginPage;
	static com.wealth.trading.models.SetGetTestEnv SetGetTestEnv=new SetGetTestEnv();
	
	String accessCodeHardCoded = "60006754", passwordHardCoded = "pass123";

	@Step
	public void open_WrapOnline_LoginPage(String bv) throws IOException,
			InterruptedException {
		String testEnv = loginPage.openWrapOnlineLoginPage(bv);
		//System.out.println("Guru print test env: "+testEnv);
		SetGetTestEnv.settestEnv(testEnv);
	}
	
	@Step
	public String getTestEnv(){
		
		return SetGetTestEnv.gettestEnv();
	}

	@Step
	public void login_to_WrapOnline_HardCoded_ToBeDeleted(String BV) throws IOException, InterruptedException {
		loginPage.enterAccessCode(accessCodeHardCoded);
		loginPage.enterPasswordField(passwordHardCoded);
		loginPage.clickLogInButton(BV);
	}

	@Step
	public void login_to_WrapOnline(String BV, String accessCode, String password) throws IOException, InterruptedException {
		loginPage.enterAccessCode(accessCode);
		loginPage.enterPasswordField(password);
		loginPage.clickLogInButton(BV);
	}

	@Step
	public void signIn_to_WrapOnline() throws InterruptedException {
		loginPage.enterAccessCode(accessCodeHardCoded);
		loginPage.enterPasswordField(passwordHardCoded);
		loginPage.clickSignInButton();
	}

	@Step
	static public void clickOnHomeLink() {
		loginPage.clickHomeLink();
	}
	
	@Step
	static public void clickOnHomeLinkING() {
		loginPage.clickHomeLinkING();
	}


	@Step
	public void logOut() {
		loginPage.logOut();
	}
	
	@Step
	public void logOutING() {
		loginPage.logOutING();
	}

	@Step
	public void endSession() {
		loginPage.endSession();
	}
	
	@Step
	public void log(String message) {}
	
	@Step
	public void clickOnAdministrationLink() {
		loginPage.clickAdministrationLink();
	}
	
}
