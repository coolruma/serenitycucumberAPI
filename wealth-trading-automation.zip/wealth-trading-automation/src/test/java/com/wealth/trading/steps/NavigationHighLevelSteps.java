package com.wealth.trading.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;

import net.thucydides.core.annotations.Screenshots;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import com.wealth.trading.models.SetGetAccountNumber;
import com.wealth.trading.pages.AuthoriseOrdersPage;
import com.wealth.trading.pages.LoginPage;
import com.wealth.trading.pages.OrderConfirmationPage;
import com.wealth.trading.pages.PortfolioTransactingPage;

public class NavigationHighLevelSteps extends ScenarioSteps {
	LoginPage loginPage;
	PortfolioTransactingPage portfolioTransactingPage;
	OrderConfirmationPage orderConfirmationPage;
	AuthoriseOrdersPage authoriseOrdersPage;
	static com.wealth.trading.pages.HomePage HomePage;
	com.wealth.trading.pages.ClientDetailsPage	ClientDetailsPage;
	//static com.wealth.trading.models.SetGetAccountNumber SetGetAccountNumber;
	static com.wealth.trading.models.SetGetAccountNumber setGetAccountNumber=new SetGetAccountNumber();
	com.wealth.trading.pages.DealerReportsPage DealerReportsPage = new com.wealth.trading.pages.DealerReportsPage();
	com.wealth.trading.pages.WorkInProgressPage WorkInProgressPage = new com.wealth.trading.pages.WorkInProgressPage();
	com.wealth.trading.pages.NewsAndUpdatesPage NewsAndUpdatesPage;
	com.wealth.trading.pages.ClientAndAdviserReportsPage ClientAndAdviserReportsPage;
	com.wealth.trading.pages.AdministrationPage AdministrationPage;
		
	
	@Step
	public void Navigate_Dealer_Reporting(String BV) throws InterruptedException{
					
		HomePage.navigateDealerReporting(BV);		
		
	}
	
	@Step
	public void Navigate_ReportByDealer(String BV){
		
		DealerReportsPage.navigate_ReportByDealerScreen(BV);
		
	}
	
	@Step
	public void Navigate_downloadFiles(String BV){
		
		DealerReportsPage.navigate_DownloadFiles(BV);
		
	}
	
	@Step
	public void Navigate_esiAuthDetails(String BV){
		
		DealerReportsPage.navigate_esiAuthDetails(BV);
		
	}
	
	@Step
	public void Navigate_FeeDisclosureStmt(String BV){
		
		DealerReportsPage.navigate_feeDisclosureStmt(BV);
		
	}
	
	@Step
	public void Navigate_RCTI(String BV){
		
		DealerReportsPage.navigate_RCTI(BV);
		
	}
	
	@Step
	public void Navigate_WorkInProgress(String BV){
		
		HomePage.navigateWorkInProgress(BV);
		
	}
	
	@Step
	public void Navigate_Orders(String BV) throws InterruptedException{
		
		WorkInProgressPage.navigate_WipOrders(BV);
		
	}
	
	@Step
	public void Navigate_ContractNotes(String BV){
		
		WorkInProgressPage.navigate_ContractNotes(BV);
		
	}
	
	@Step
	public void Navigate_TransferInDetails(String BV){
		
		WorkInProgressPage.navigate_TransferIn(BV);
		
	}
	
	@Step
	public void Navigate_esiTransactingInstruction(String BV){
		
		WorkInProgressPage.navigate_esiTransatingInstruction(BV);
		
	}
	
	@Step
	public void Navigate_CashPaymentsNReceipts(String BV){
		
		WorkInProgressPage.navigate_CashPaymentNReceipts(BV);
		
	}
	
	@Step
	public void Navigate_ExistingOnlineApps(String BV) throws InterruptedException{
		
		WorkInProgressPage.navigate_existingOnlineApps(BV);
		
	}
	
	@Step
	public void Navigate_InvestmentOrders(String BV){
		
		WorkInProgressPage.navigate_investmentOrders(BV);
		
	}
	
	@Step
	public void Navigate_SuperOrders(String BV){
		
		WorkInProgressPage.navigate_SuperOrders(BV);
		
	}
	
	@Step
	public void Navigate_PresetOrders(String BV){
		
		WorkInProgressPage.navigate_PresetOrders(BV);
		
	}
	
	@Step
	public void Navigate_PensionOrders(String BV){
		
		WorkInProgressPage.navigate_PensionOrders(BV);
		
	}
	
	@Step
	public void Navigate_PortfolioTransacting(String BV){
		
		HomePage.NavigatePortfolioTransacting(BV);
		
	}
	
	@Step
	public void Navigate_CorporateActions(String BV){
		
		HomePage.NavigateCorporateActions(BV);
		
	}
	
	@Step
	public void Navigate_Models(String BV){
		
		HomePage.NavigateModels(BV);		
	}
	
	@Step
	public void Navigate_BulkWholesaleManagedInvestments(String BV){
		
		HomePage.NavigateBulkWholesaleMgdInvestments(BV);		
	}
	
	@Step
	public void Navigate_OtherAssets(String BV){
		
		HomePage.NavigateOtherAssets(BV);		
	}
	
	@Step
	public void Navigate_TransactingInvestmentING(String BV){
		
		HomePage.navigateTransactingInvestmentING(BV);		
	}
	
	@Step
	public void Navigate_TransactingSuperING(String BV){
		
		HomePage.navigateTransactingSuperING(BV);		
	}
	
	@Step
	public void Navigate_TransactingPensionING(String BV){
		
		HomePage.navigateTransactingPensionING(BV);		
	}
	
	@Step
	public void Navigate_TransferInDetailsING(String BV){
		
		HomePage.navigateTransferInDetailsING(BV);		
	}
	
	@Step
	public void Navigate_Resources(String BV){
		
		HomePage.NavigateResources(BV);		
	}
	
	@Step
	public void Navigate_NewsNUpdates(String BV){
		
		HomePage.NavigateNewsNUpdates(BV);		
	}
	
	@Step
	public void Navigate_TechLibrary(String BV){
		
		HomePage.NavigateTechLibrary(BV);		
	}
	
	@Step
	public void Navigate_MacqAccess(String BV) throws InterruptedException{
		
		HomePage.NavigateMacquarieAccess(BV);		
	}
	
	@Step
	public void Navigate_latestNews(String BV) throws InterruptedException{
		
		NewsAndUpdatesPage.navigate_latestNews(BV);		
	}
	
	@Step
	public void Navigate_InvestmentMenu(String BV) throws InterruptedException{
		
		NewsAndUpdatesPage.navigate_InvestmentMenu(BV);		
	}
	
	@Step
	public void Navigate_DistributionUpdate(String BV) throws InterruptedException{
		
		NewsAndUpdatesPage.NavigateDistributionUpdate(BV);		
	}
	
	@Step
	public void Navigate_alerts(String BV) throws InterruptedException{
		
		HomePage.NavigateAlerts(BV);	
	
	}
	
	@Step
	public void Navigate_portfolioReviewReport(String BV) throws InterruptedException{
		
		HomePage.NavigatePortfolioReviewReport(BV);	
	
	}
	
	@Step
	public void Navigate_ClientNAdvierReporting(String BV) throws InterruptedException{
		
		HomePage.navigateClientNAdviserReporting(BV);	
	
	}
	
	@Step
	public void Navigate_RunReportInvestment(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_RunReportInvestment(BV);	
		
	}
	
	@Step
	public void Navigate_RunReportSuper(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_RunReportSuper(BV);
		
	}
	
	@Step
	public void Navigate_RunReportPension(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_RunReportPension(BV);
		
	}
	
	@Step
	public void Navigate_RunReportAccountGroup(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_RunReportAccountGroup(BV);
		
	}
	
	@Step
	public void Navigate_RunReportByAdviser(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_RunReportByAdviser(BV);
		
	}
	
	@Step
	public void Navigate_DownloadStmts(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_downloadStatements(BV);
		
	}
	
	/*@Step
	public void Navigate_DownloadFiles(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_DownloadFiles(BV);
		
	}*/
	
	@Step
	public void Navigate_DownloadExcelReport(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_DownloadExcelReports(BV);
		
	}
	
	@Step
	public void Navigate_ScheduleReport(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_ScheduleReports(BV);
		
	}
	
	@Step
	public void Navigate_ReportContactDetails(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_ReportContactDetails(BV);
		
	}
	
	@Step
	public void Navigate_FeeDiscStatementsAdviser(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_FeeDisclosureStmtsAdviser(BV);
		
	}
	
	@Step
	public void Navigate_FiduciaryReportsAdviser(String BV) throws InterruptedException{
		
		ClientAndAdviserReportsPage.navigate_FiduciaryReportsAdviser(BV);
		
	}
	
	@Step
	public void Navigate_Administration(String BV) throws InterruptedException{
		
		HomePage.navigateAdministration(BV);
		
	}
	
	@Step
	public void Navigate_MaintainInvestmentAccount(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_MaintainInvestmentAccount(BV);
		
	}
	
	@Step
	public void Navigate_MaintainSuperannuationAccount(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_MaintainSuperAccount(BV);		
	}
	
	@Step
	public void Navigate_MaintainPensionAccount(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_MaintainPensionAccount(BV);		
	}
	
	@Step
	public void Navigate_MaintainFiduciaryAccount(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_MaintainfiduciaryAccount(BV);		
	}
	
	@Step
	public void Navigate_ChangeAdviserTaxElection(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_ChangeAdviserTaxElection(BV);		
	}
	
	@Step
	public void Navigate_ModifyUserPreferences(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_ModifyUserPreferences(BV);		
	}
	
	@Step
	public void Navigate_SetupOrMaintainAssetAllocationOverride(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_SetupOrMaintainAssetAllocationOverride(BV);		
	}
	
	@Step
	public void Navigate_ModifyAdviserOrStaffDetails(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_ModifyAdviserOrStaffDetails(BV);		
	}
	
	@Step
	public void Navigate_EnterTransferInDetails(String BV) throws InterruptedException{
		
		AdministrationPage.navigate_EnterTransferInDetails(BV);		
	}
		
	@Step
	public void log(String message) {}
		
}
