package com.wealth.trading.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.DataBaseConnector;
import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class HomePage extends PageObject {

	static PageObjectUtils pageUtils = new PageObjectUtils();
	static DataBaseConnector dbConnect = new DataBaseConnector();

	@FindBy(id = "clientAccountSearchField")
	private WebElementFacade txt_clientAccountSearchField;
	
	@FindBy(xpath = "//*[@name='searchStringField']")
	private WebElementFacade txt_clientAccountSearchFieldING;
		
	@FindBy(xpath = "//*[@class='bannerSearchButton']")
	private WebElementFacade btn_Go;
	
	@FindBy(xpath = "//*[@alt='Go']")
	private WebElementFacade btn_GoING;
		
	@FindBy(xpath = "//*[contains(text(),'client accounts')]")
	private WebElementFacade elm_ClientAccounts;
	
	@FindBy(xpath = "//*[contains(text(),'client list')]")
	private WebElementFacade elm_clientlist;
	
	@FindBy(xpath = "(//*[contains(text(),'client list')])[2]")
	private WebElementFacade elm_clientlistING;
		
	@FindBy(xpath = "//*[@id='applicationMessages']/table[3]")
	private WebElementFacade tbl_clientlistTableS;
	
	String tbl_clientlistTable = "//*[@id='applicationMessages']/table[3]";
	String tbl_clientlistTableING = "//table[@class='clientList']";
	String ByVal = "xpath";
	
	public void clientAccountSearch(String BV, String ClientOrAccount) {
		
		
		if(BV.toUpperCase().contains("ING")){
			
			txt_clientAccountSearchFieldING.sendKeys(ClientOrAccount);
			btn_GoING.click();
			
			if(elm_clientlistING.isPresent()){
				
				PageObjectUtils.clickTableCell(getDriver(), ByVal, tbl_clientlistTableING, ClientOrAccount);	
				
			}
			
					
		}else {
			
			txt_clientAccountSearchField.sendKeys(ClientOrAccount);
			btn_Go.click();
			
			//assertThat(elm_clientlist.getText()).isEqualToIgnoringCase("client list") != null
			
			if(elm_clientlist.isPresent()){
				
				PageObjectUtils.clickTableCell(getDriver(), ByVal, tbl_clientlistTable, ClientOrAccount);	
				
			}
		
				
		}
		
		pageUtils.fluentWaitElement(By.xpath("//*[contains(text(),'client accounts')]"), 50);
		elm_ClientAccounts.waitUntilVisible();
	}
	
	@SuppressWarnings("static-access")
	public static String getDBAccountNumber(String BV, String SQL) throws IOException{
		
		String url = pageUtils.getSUTValue("webdriver.base.url." + BV);
		String testEnv = "";
		String ClientOrAccount1 = "";
					
			
			if(url.toLowerCase().contains("test1")){
				
				testEnv =  "TEST1";
				
				System.out.println("the test env is --" +testEnv);
				
			}else if(url.toLowerCase().contains("test2")){
				
				testEnv =  "TEST2";
				System.out.println("the test env is --" +testEnv);
			}
			
			ClientOrAccount1 = dbConnect.executeSQLQuery(testEnv, SQL);
			
			System.out.println("the DB account number is -- "+ClientOrAccount1);
					
		
		return ClientOrAccount1;
	}
	
	
	@FindBy(xpath = "//a[@class='sf-with-ul' and contains(., 'Reporting')]")
	private WebElementFacade lnk_Reporting;

	@FindBy(linkText = "Dealer")
	private WebElementFacade lnk_Dealer;
	
	@FindBy(xpath = "//*[contains(text(), 'dealer info')]")
	private WebElementFacade elm_DealerInfo;
	
	@FindBy(xpath = "(//*[contains(text(), 'dealer info')])[1]")
	private WebElementFacade lnk_DealerING;
	
	@FindBy(xpath = "(//*[contains(text(), 'dealer info')])[2]")
	private WebElementFacade elm_DealerInfoING;
		
	public void navigateDealerReporting(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
		
        case "MPMING":
        	pageUtils.WrapHeaderMenuNavigation(lnk_DealerING);
        	elm_DealerInfoING.waitUntilVisible();
    		assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'dealer info')])[2]")).getText()).containsIgnoringCase("dealer");
        	break;
        	
        default:
        	pageUtils.WrapHeaderMenuNavigation(lnk_Reporting, lnk_Dealer);
    		elm_DealerInfo.waitUntilVisible();
    		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'dealer info')]")).getText()).containsIgnoringCase("dealer");		
            break;
        }
		
		Serenity.takeScreenshot();
	}
	
	@FindBy(partialLinkText = "Client &")
	private WebElementFacade lnk_ClientNAdviser;
	
	@FindBy(xpath = "//a[contains(text(), 'reporting')]")
	private WebElementFacade lnk_ReportingING;
	
	@FindBy(xpath = "//span[contains(text(), 'reporting')]")
	private WebElementFacade elm_Reporting;
	
	public void navigateClientNAdviserReporting(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
		
        case "MPMING":
        	pageUtils.WrapHeaderMenuNavigation(lnk_ReportingING);
        	elm_Reporting.waitUntilVisible();
        	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'reporting')]")).getText()).containsIgnoringCase("reporting");
        	break;
        	
        default:
        	pageUtils.WrapHeaderMenuNavigation(lnk_Reporting, lnk_ClientNAdviser);
        	elm_Reporting.waitUntilVisible();
    		assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'reporting')]")).getText()).containsIgnoringCase("reporting");		
            break;
        }
		
		Serenity.takeScreenshot();
				
	}
	
	@FindBy(linkText = "Administration")
	private WebElementFacade lnk_Adminstration;
	
	@FindBy(linkText = "administration")
	private WebElementFacade lnk_AdminstrationING;
	
	@FindBy(xpath = "//span[contains(text(), 'administration')]")
	private WebElementFacade elm_Administration;
	
	
	public void navigateAdministration(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
		
        case "MPMING":
        	pageUtils.WrapHeaderMenuNavigation(lnk_AdminstrationING);
        	elm_Administration.waitUntilVisible();
        	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'administration')]")).getText()).containsIgnoringCase("administration");
        	break;
        	
        default:
        	pageUtils.WrapHeaderMenuNavigation(lnk_Adminstration);
        	elm_Administration.waitUntilVisible();
    		assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'administration')]")).getText()).containsIgnoringCase("administration");		
            break;
        }
		
		Serenity.takeScreenshot();
				
	}
	
	@FindBy(xpath = "//*[contains(text(), 'Work in progress')]")
	private WebElementFacade lnk_wip;
	
	@FindBy(xpath = "//*[contains(text(), 'work in progress')]")
	private WebElementFacade lnk_wipING;
	
	@FindBy(xpath = "//*[contains(text(), 'work in progress')]")
	private WebElementFacade elm_wip;
	
	@FindBy(xpath = "(//*[contains(text(), 'work in progress')])[2]")
	private WebElementFacade elm_wipING;
	
	public void navigateWorkInProgress(String BV){
		
		if(BV.toUpperCase().contains("ING")){
			
			pageUtils.WrapHeaderMenuNavigation(lnk_wipING);
			elm_wipING.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'work in progress')])[2]")).getText()).containsIgnoringCase("work in progress");
			
		} else {
					
			pageUtils.WrapHeaderMenuNavigation(lnk_wip);
			elm_wip.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'work in progress')]")).getText()).containsIgnoringCase("work in progress");
		}
		
		
		Serenity.takeScreenshot();
		
	}
	
	
	@FindBy(xpath = "//a[@class='sf-with-ul' and contains(., 'Transacting')]")
	private WebElementFacade transactingMenu;

	//@FindBy(linkText = "Portfolio transacting")
	@FindBy(partialLinkText = "Portfolio")
	private WebElementFacade portfolioTransactingLink;
	
	@FindBy(xpath = "//h2[contains(text(), 'Portfolio transacting')]")
	private WebElementFacade elm_portfolioTransacting;
	
	public void NavigatePortfolioTransacting(String BV){
		
			pageUtils.WrapHeaderMenuNavigation(transactingMenu, portfolioTransactingLink);
			elm_portfolioTransacting.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//h2[contains(text(), 'Portfolio transacting')]")).getText()).containsIgnoringCase("Portfolio transacting");
			Serenity.takeScreenshot();
	}
	
	@FindBy(partialLinkText = "Corporate")
	private WebElementFacade lnk_CorporateActions;
	
	@FindBy(linkText = "corporate actions")
	private WebElementFacade lnk_CorporateActionsING;
	
	@FindBy(xpath = "(//*[contains(text(), 'corporate actions')])[1]")
	private WebElementFacade elm_corporateActions;
	
	@FindBy(xpath = "(//*[contains(text(), 'corporate actions')])[2]")
	private WebElementFacade elm_corporateActionsING;
	
	@FindBy(linkText = "corporate actions calendar")
	private WebElementFacade lnk_CorporateActionsCalender;
	
	@FindBy(linkText = "floats and placements calendar")
	private WebElementFacade lnk_FloatsNPlacementCalender;	
			
	
	public void NavigateCorporateActions(String BV){
		
			
		if(BV.toUpperCase().contains("ING")){
			
			pageUtils.WrapHeaderMenuNavigation(transactingMenu_ING, lnk_CorporateActionsING);
			elm_corporateActionsING.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'corporate actions')])[2]")).getText()).containsIgnoringCase("corporate actions");
			
		}else {
			
			pageUtils.WrapHeaderMenuNavigation(transactingMenu, lnk_CorporateActions);
			elm_corporateActions.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'corporate actions')])[1]")).getText()).containsIgnoringCase("corporate actions");
			
		}
			
		lnk_CorporateActionsCalender.waitUntilVisible();
		assertThat(getDriver().findElement(By.linkText("corporate actions calendar")).getText()).containsIgnoringCase("corporate actions calendar");
		lnk_FloatsNPlacementCalender.waitUntilVisible();
		assertThat(getDriver().findElement(By.linkText("floats and placements calendar")).getText()).containsIgnoringCase("floats and placements calendar");	
		Serenity.takeScreenshot();
	}
	
	//@FindBy(linkText = "Model portfolios")
	@FindBy(partialLinkText = "Model")
	private WebElementFacade lnk_ModelPortfolios;
	
	@FindBy(partialLinkText = "model")
	private WebElementFacade lnk_ModelPortfoliosING;
	
	@FindBy(xpath = "(//*[contains(text(), 'Models')])[1]")
	private WebElementFacade elm_Models;
	
	public void NavigateModels(String BV){
		
		String parentWindowHandle = getDriver().getWindowHandle();
		if(BV.toUpperCase().contains("ING")){
			
			pageUtils.WrapHeaderMenuNavigation(lnk_ModelPortfoliosING);
			
		}else{
			
			pageUtils.WrapHeaderMenuNavigation(transactingMenu, lnk_ModelPortfolios);
			
		}
		
		
		for(int a =1; a <=5; a++ ){									
			if(getDriver().getWindowHandles().size()>1){						
				break;
			}
		}			
		
		for(String handle : getDriver().getWindowHandles()){		
				
				getDriver().switchTo().window(handle);						
		}
		
		
		//elm_Models.waitUntilVisible();
		pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(), 'Models')])[1]"),60);
		assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'Models')])[1]")).getText()).containsIgnoringCase("Models");
		
		Serenity.takeScreenshot();
		getDriver().close();
		getDriver().switchTo().window(parentWindowHandle);
		
	}
	
	//@FindBy(linkText = "Bulk wholesale managed investments")
	@FindBy(partialLinkText = "Bulk")
	private WebElementFacade lnk_BulkWholesaleManagedInvestments;	
	
	@FindBy(xpath = "//*[contains(text(), 'bulk transacting')]")
	private WebElementFacade elm_BulkTransacting;
	
	@FindBy(linkText = "bulk transact")
	private WebElementFacade lnk_BulkWholesaleManagedInvestmentsING;
	
	@FindBy(xpath = "(//*[contains(text(), 'bulk transacting')])[2]")
	private WebElementFacade elm_BulkTransactingING;
	
	public void NavigateBulkWholesaleMgdInvestments(String BV){
		
		if(BV.toUpperCase().contains("ING")){
			
			pageUtils.WrapHeaderMenuNavigation(transactingMenu_ING, lnk_BulkWholesaleManagedInvestmentsING);
			elm_BulkTransactingING.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'bulk transacting')])[2]")).getText()).containsIgnoringCase("bulk transacting");
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'switch')]")).getText()).containsIgnoringCase("switch");
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'redemption')]")).getText()).containsIgnoringCase("redemption");			
			
		} else {
			
			pageUtils.WrapHeaderMenuNavigation(transactingMenu, lnk_BulkWholesaleManagedInvestments);
			elm_BulkTransacting.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'bulk transacting')]")).getText()).containsIgnoringCase("bulk transacting");
			
		}
		
		Serenity.takeScreenshot();
	}
	
	//@FindBy(linkText = "Other assets")
	//@FindBy(partialLinkText = "Other")
	@FindBy(partialLinkText = "ssets")
	private WebElementFacade lnk_OtherAssets;
	
	@FindBy(xpath = "//*[contains(text(), 'Account search')]")
	private WebElementFacade elm_OtherAssets;
	
	public void NavigateOtherAssets(String BV){
		
		pageUtils.WrapHeaderMenuNavigation(transactingMenu, lnk_OtherAssets);
		elm_OtherAssets.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'Account search')]")).getText()).containsIgnoringCase("Account search");		
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(linkText = "transacting")
	private WebElementFacade transactingMenu_ING;
	
	@FindBy(xpath = "//*[contains(text(), 'self managed')]")
	private WebElementFacade lnk_InvestmentING;
	
	@FindBy(xpath = "//*[contains(text(), 'transact on an investment account')]")
	private WebElementFacade elm_TransactInvestmentAcctING;
	
	public void navigateTransactingInvestmentING(String BV){
		
		pageUtils.WrapHeaderMenuNavigation(transactingMenu_ING, lnk_InvestmentING);
		elm_TransactInvestmentAcctING.waitUntilVisible();
		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'transact on an investment account')]")).getText()).containsIgnoringCase("transact on an investment account");		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'application')]")).getText()).containsIgnoringCase("application");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'redemption')]")).getText()).containsIgnoringCase("redemption");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'switch')]")).getText()).containsIgnoringCase("switch");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'buy shares')]")).getText()).containsIgnoringCase("buy shares");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'sell shares')]")).getText()).containsIgnoringCase("sell shares");
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(xpath = "//*[contains(text(), 'superannuation')]")
	private WebElementFacade lnk_superING;
	
	@FindBy(xpath = "//*[contains(text(), 'transact on a super account')]")
	private WebElementFacade elm_TransactSuperAcctING;
	
	public void navigateTransactingSuperING(String BV){
		
		pageUtils.WrapHeaderMenuNavigation(transactingMenu_ING, lnk_superING);
		elm_TransactSuperAcctING.waitUntilVisible();
		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'transact on a super account')]")).getText()).containsIgnoringCase("transact on a super account");		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'switch')]")).getText()).containsIgnoringCase("switch");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'buy shares')]")).getText()).containsIgnoringCase("buy shares");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'sell shares')]")).getText()).containsIgnoringCase("sell shares");
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(xpath = "(//*[contains(text(), 'pension')])[2]")
	private WebElementFacade lnk_pensionING;
	
	@FindBy(xpath = "//*[contains(text(), 'transact on a pension account')]")
	private WebElementFacade elm_TransactPensionAcctING;
	
	public void navigateTransactingPensionING(String BV){
		
		pageUtils.WrapHeaderMenuNavigation(transactingMenu_ING, lnk_pensionING);
		elm_TransactPensionAcctING.waitUntilVisible();
		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'transact on a pension account')]")).getText()).containsIgnoringCase("transact on a pension account");		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'switch')]")).getText()).containsIgnoringCase("switch");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'buy shares')]")).getText()).containsIgnoringCase("buy shares");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'sell shares')]")).getText()).containsIgnoringCase("sell shares");
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(linkText = "enter")
	private WebElementFacade lnk_enterTransferInING;
	
	@FindBy(xpath = "//*[contains(text(), 'choose transfer in type')]")
	private WebElementFacade elm_TransferInDetailsING;
	
	public void navigateTransferInDetailsING(String BV){
		
		pageUtils.WrapHeaderMenuNavigation(transactingMenu_ING, lnk_enterTransferInING);
		elm_TransferInDetailsING.waitUntilVisible();
		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'choose transfer in type')]")).getText()).containsIgnoringCase("choose transfer in type");		
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'broker')]")).getText()).containsIgnoringCase("broker");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'issuer')]")).getText()).containsIgnoringCase("issuer");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'wholesale managed funds')]")).getText()).containsIgnoringCase("wholesale managed funds");
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'australian standard transfer form')]")).getText()).containsIgnoringCase("australian standard transfer form");
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(xpath = "(//*[contains(text(), 'Resources')])[1]")
	private WebElementFacade lnk_ResourcesLvl1;
	
	@FindBy(xpath = "(//*[contains(text(), 'Resources')])[2]")
	private WebElementFacade lnk_ResourcesLvl2;
	
	@FindBy(xpath = "//*[contains(text(), 'resources')]")
	private WebElementFacade lnk_ResourcesING;
	
	@FindBy(xpath = "//span[contains(text(), 'resources')]")
	private WebElementFacade elm_Resources;
	
	public void NavigateResources(String BV){
		
		if(BV.toUpperCase().contains("ING")){
			
			pageUtils.WrapHeaderMenuNavigation(lnk_ResourcesING);
			
		}else {
			
			pageUtils.WrapHeaderMenuNavigation(lnk_ResourcesLvl1, lnk_ResourcesLvl2);	
		}
		
		elm_Resources.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'resources')]")).getText()).containsIgnoringCase("resources");		
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(xpath = "//*[contains(text(), 'News & updates')]")
	private WebElementFacade lnk_NewsNUpdates;
	
	@FindBy(xpath = "//*[contains(text(), 'news and updates')]")
	private WebElementFacade lnk_NewsNUpdatesING;
	
	@FindBy(xpath = "//span[contains(text(), 'news and updates')]")
	private WebElementFacade elm_NewsNUpdates;
	
	public void NavigateNewsNUpdates(String BV){
		
		if(BV.toUpperCase().contains("ING")){
			
			pageUtils.WrapHeaderMenuNavigation(lnk_NewsNUpdatesING);
			
		}else {
			
			pageUtils.WrapHeaderMenuNavigation(lnk_ResourcesLvl1, lnk_NewsNUpdates);
			
		}		
		elm_NewsNUpdates.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'news and updates')]")).getText()).containsIgnoringCase("news and updates");		
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(xpath = "//*[contains(text(), 'Technical library')]")
	private WebElementFacade lnk_TechLibrary;
	
	@FindBy(xpath = "//*[contains(text(), 'tech library')]")
	private WebElementFacade elm_TechLibrary;
	
	public void NavigateTechLibrary(String BV){
		
		String parentWindowHandle = getDriver().getWindowHandle();
	
		pageUtils.WrapHeaderMenuNavigation(lnk_ResourcesLvl1, lnk_TechLibrary);
				
		
		for(int a =1; a <=5; a++ ){									
			if(getDriver().getWindowHandles().size()>1){						
				break;
			}
		}			
		
		for(String handle : getDriver().getWindowHandles()){		
				
				getDriver().switchTo().window(handle);						
		}
		
		
		//elm_TechLibrary.waitUntilVisible();
		pageUtils.fluentWaitElement(By.xpath("//*[contains(text(), 'tech library')]"),60);
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'tech library')]")).getText()).containsIgnoringCase("tech library");
		
		Serenity.takeScreenshot();
		getDriver().close();
		getDriver().switchTo().window(parentWindowHandle);
		
	}
	
	@FindBy(linkText = "Macquarie Access")
	private WebElementFacade lnk_MacqAccess;
	
	@FindBy(xpath = "//span[contains(text(), 'Macquarie Access')]")
	private WebElementFacade elm_MacqAccess;
	
public void NavigateMacquarieAccess(String BV) throws InterruptedException{
		
		String parentWindowHandle = getDriver().getWindowHandle();
	
		//pageUtils.WrapHeaderMenuNavigation(lnk_ResourcesLvl1, lnk_MacqAccess);
		lnk_ResourcesLvl1.waitUntilVisible();
		lnk_ResourcesLvl1.click();		
		Thread.sleep(2000);
		lnk_MacqAccess.waitUntilVisible();
		lnk_MacqAccess.click();
		
		for(int a =1; a <=5; a++ ){									
			if(getDriver().getWindowHandles().size()>1){						
				break;
			}
		}			
		
		for(String handle : getDriver().getWindowHandles()){		
				
				getDriver().switchTo().window(handle);						
		}
		
		
		//elm_MacqAccess.waitUntilVisible();
		pageUtils.fluentWaitElement(By.xpath("//span[contains(text(), 'Macquarie Access')]"),60);
		assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'Macquarie Access')]")).getText()).containsIgnoringCase("Macquarie Access");
		
		Serenity.takeScreenshot();
		getDriver().close();
		getDriver().switchTo().window(parentWindowHandle);
		
	}

	@FindBy(linkText = "alerts")
	private WebElementFacade lnk_Alerts;
	
	@FindBy(xpath = "//span[contains(text(), 'alerts')]")
	private WebElementFacade elm_Alerts;
	
	public void NavigateAlerts(String BV){
					
		pageUtils.WrapHeaderMenuNavigation(lnk_Alerts);
	
		elm_Alerts.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'alerts')]")).getText()).containsIgnoringCase("alerts");		
		Serenity.takeScreenshot();
		
	}
	
	@FindBy(partialLinkText = "Portfolio R")
	private WebElementFacade lnk_PRR;
	
	@FindBy(xpath = "//h1[contains(text(), 'Portfolio Review')]")
	private WebElementFacade elm_PRR;
		
	
	
	public void NavigatePortfolioReviewReport(String BV){
		
		pageUtils.WrapHeaderMenuNavigation(lnk_Reporting, lnk_PRR);
	
		elm_PRR.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//h1[contains(text(), 'Portfolio Review')]")).getText()).containsIgnoringCase("Portfolio Review");		
		assertThat(getDriver().findElement(By.xpath("//a[contains(text(), 'View account')]")).getText()).containsIgnoringCase("View account selection");
		Serenity.takeScreenshot();
		
	}
	
	
}