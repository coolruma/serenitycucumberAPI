package com.wealth.trading.pages;

import java.io.IOException;
import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class LoginPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();
	static com.wealth.trading.models.SetGetTestEnv SetGetTestEnv =  new com.wealth.trading.models.SetGetTestEnv();

	@FindBy(id = "username")
	private WebElementFacade AccessCode;

	@FindBy(id = "password")
	private WebElementFacade Password;

	@FindBy(css = ".primaryButton span")
	private WebElementFacade LoginButton;
	
	@FindBy(xpath = "//*[@id='loginBtn']")
	private WebElementFacade btn_LoginANZ;
	
	@FindBy(xpath = "//*[@name='action']")
	private WebElementFacade btn_LoginING;
	
	@FindBy(linkText = "Home")
	private WebElementFacade HomeLink;
	
	@FindBy(linkText = "home")
	private WebElementFacade HomeLinkING;

	@FindBy(xpath = "//a[@class='sf-with-ul' and contains(., 'Transacting')]")
	private WebElementFacade transactingMenu;

	@FindBy(linkText = "Portfolio transacting")
	private WebElementFacade portfolioTransactingLink;
	
	@FindBy(linkText = "Portfolio Transacting")
	private WebElementFacade portfolioTransactingLinkForANZ;
	
	@FindBy(linkText = "Administration")
	private WebElementFacade administrationLink;
	
	@FindBy(css = ".primaryButtonjagtesting span")
	private WebElementFacade SignInButton;

	@FindBy(xpath = "//span[@class='syncing']")
	private WebElementFacade syncIcon;

	@FindBy(linkText = "Logout")
	private WebElementFacade logOut;
	
	@FindBy(linkText = "logout")
	private WebElementFacade logOutING;

	@FindBy(linkText = "End Session")
	private WebElementFacade endSession;
	
	public void enterAccessCode(String accessCode) throws InterruptedException {

		// System.out.println("Jagrut"+LocalDateTime.now());
		// pageUtils.fluentWaitElement(By.id("username1"), 50);
		// System.out.println("Jagrut"+LocalDateTime.now());

		// System.out.println("Jagrut"+LocalDateTime.now());
		// pageUtils.fluentWaitElementSerenity(By.id("username"), 50);
		// System.out.println("Jagrut"+LocalDateTime.now());

		//AccessCode.sendKeys(accessCode);
		Thread.sleep(1000);
		AccessCode.sendKeys(accessCode+Keys.TAB);

	}

	public void enterPasswordField(String password) throws InterruptedException {
		//Password.sendKeys(password);
		Thread.sleep(1000);
		Password.type(password);
	}

	public void clickLogInButton(String BV) throws IOException {
		
		
		switch (BV.toUpperCase()) {
        case "MPMADG": case "MPMAWT":
			if(btn_LoginANZ.isPresent()){
				
				btn_LoginANZ.click();
				
			}else{
				
				btn_LoginING.click();
				
			}
			
			pageUtils.fluentWaitElement(By.linkText("Logout"), 50);
			String url = pageUtils.getSUTValue("webdriver.base.url." + BV);
			getDriver().get(url);
			break;
        	
        case "MPMING":
        	btn_LoginING.click();
			pageUtils.fluentWaitElement(By.linkText("home"), 50);
			HomeLinkING.waitUntilVisible();
        	break;
        	
        default:
        	LoginButton.click();			
            break;
        }
		
		if(!BV.toUpperCase().contains("ING")){
			
			pageUtils.fluentWaitElement(By.linkText("Home"), 50);
			HomeLink.waitUntilVisible();
		}
	
	}

	public String openWrapOnlineLoginPage(String bv) throws IOException,
			InterruptedException {
		String url = pageUtils.getSUTValue("webdriver.base.url." + bv);
		System.out.println("URL=" + url);
		
		String testEnv = "";
		
		if(url.toLowerCase().contains("test1")){
			
			testEnv =  "TEST1";
			//SetGetTestEnv.settestEnv(testEnv);			
			
		}else if(url.toLowerCase().contains("test2")){
			
			testEnv =  "TEST2";
			//SetGetTestEnv.settestEnv(testEnv);			
		}			
		
		getDriver().navigate().to(url);
		return testEnv;			
		
	}

	public void clickSignInButton() {
		SignInButton.click();
	}

	public void clickHomeLink() {
		//System.out.println("test guru");
		HomeLink.waitUntilVisible();
		HomeLink.click();
	}
	
	public void clickHomeLinkING() {
		//System.out.println("test guru");
		HomeLinkING.waitUntilVisible();
		HomeLinkING.click();
	}

	public void clickAdministrationLink() {
		administrationLink.click();
	}
	
	public void clickPortfolioTransactingLink() {
		Actions action = new Actions(getDriver());
		action.moveToElement(transactingMenu).build().perform();
		
		List<WebElementFacade> portFolioTransactingLinkList=pageUtils.findAll(By.linkText("Portfolio Transacting"));
		
		// linkText for MPM,PPT = linkText("Portfolio transacting"));
		// linkText for ANZ = linkText("Portfolio Transacting"));
		if(portFolioTransactingLinkList.size() > 0){
			portfolioTransactingLinkForANZ.waitUntilVisible();
			portfolioTransactingLinkForANZ.click();
		}else{
			portfolioTransactingLink.waitUntilVisible();
			portfolioTransactingLink.click();
		}
			
		
	}

	public void logOut() {
		logOut.click();
	}
	
	public void logOutING() {
		logOutING.click();
	}

	public void endSession() {
		
		if(endSession.isPresent()){
			
			endSession.click();	
			
		}else {
			
			logOut.click();
		}
		
	}
}
