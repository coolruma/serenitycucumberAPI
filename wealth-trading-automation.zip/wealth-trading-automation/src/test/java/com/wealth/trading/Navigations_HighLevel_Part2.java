package com.wealth.trading;

import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/WrapNavigations/Navigations_HighLevel_Part2.feature")
public class Navigations_HighLevel_Part2 {
}
