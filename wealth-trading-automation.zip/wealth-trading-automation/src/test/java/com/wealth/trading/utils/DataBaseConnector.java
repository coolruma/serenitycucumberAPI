package com.wealth.trading.utils;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DataBaseConnector {

	private static final Log log = LogFactory.getLog(DataBaseConnector.class);

    private static String dbusername;
    private static String dbpassword;

    //Should be defined as jdbc:mysql://host:port/database name
    private static String databaseURLTest1= "jdbc:sybase:Tds:saasdev30.macbank:21030/sd_wrap";
    private static String databaseURLTest2= "jdbc:sybase:Tds:saasdev19.macbank:20100/sd_wrap";
        

    public static String executeSQLQuery(String testEnv, String sqlQuery) {
        String connectionUrl="";
        Connection connection;
        String resultValue = "";
        ResultSet rs;

        //To connect with test1 Database
        if(testEnv.equalsIgnoreCase("TEST1")){
            connectionUrl = databaseURLTest1;
            dbusername = "wrapsupp";
            dbpassword = "navig8tor";
        }

        //To connect with Test2 sd Wrap DB
        else if(testEnv.equalsIgnoreCase("TEST2")) {
            connectionUrl = databaseURLTest2;
            dbusername = "wrapsupp";
            dbpassword = "navig8tor";
        }
       /*try {
            Class.forName("com.sybase.jdbc.driver");
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }*/

        try {
            connection = DriverManager.getConnection(connectionUrl,dbusername,dbpassword);
            if(connection!=null) {
                System.out.println("Connected to the database...");
            }else {
                System.out.println("Database connection failed to "+testEnv+" Environment");
            }
            Statement stmt = connection.createStatement();
            rs=stmt.executeQuery(sqlQuery);

            try {
                while(rs.next()){
                    resultValue = rs.getString(1).toString();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (NullPointerException err) {
                System.out.println("No Records obtained for this specific query");
                err.printStackTrace();
            }
            connection.close();

        }catch(SQLException sqlEx) {
            System.out.println( "SQL Exception:" +sqlEx.getStackTrace());
            System.out.println( "Database connection failed");
        }
        return resultValue;
    }


    public static ArrayList<String> executeSQLQuery_List(String testEnv, String sqlQuery) {
        String connectionUrl="";
        Connection connection;
        ArrayList<String> resultValue = new ArrayList<String>();
        ResultSet resultSet;

        //To connect with test1 Database
        if(testEnv.equalsIgnoreCase("Test1")){
            connectionUrl = databaseURLTest1;
            dbusername = "wrapsupp";
            dbpassword = "navig8tor";
        }

        //To connect with Test2 sd Wrap DB
        else if(testEnv.equalsIgnoreCase("TEST2")) {
            connectionUrl = databaseURLTest2;
            dbusername = "wrapsupp";
            dbpassword = "navig8tor";
        }
        
   
        try {
            Class.forName("com.mysql.jdbc.Driver");
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            connection = DriverManager.getConnection(connectionUrl,dbusername,dbpassword);
            if(connection!=null) {
                System.out.println("Connected to the database");
            }else {
                System.out.println("Failed to connect to "+testEnv+" database");
            }
            Statement statement = connection.createStatement();
            resultSet=statement.executeQuery(sqlQuery);

            try {
                while(resultSet.next()){
                    int columnCount = resultSet.getMetaData().getColumnCount();
                    StringBuilder stringBuilder = new StringBuilder();
                    for(int iCounter=1;iCounter<=columnCount; iCounter++){
                        stringBuilder.append(resultSet.getString(iCounter).trim()+" ");
                    }
                    String reqValue = stringBuilder.substring(0, stringBuilder.length()-1);
                    resultValue.add(reqValue);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (NullPointerException ex) {
                System.out.println("No Records found for this specific query" +ex.getStackTrace());
            }
            finally {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException ex) {
                        System.out.println( "SQL Exception:" +ex.getStackTrace());
                    }
                }
            }

        }catch(SQLException sqlEx) {
            System.out.println( "SQL Exception:" +sqlEx.getStackTrace());
        }
        return resultValue;
    }
    


    public static String executeSQLQuery(String sql) throws SQLException {
        Connection dbConnection = getShadowDBConnection();
        Statement statement = null;
        String resultValue = null;
        ResultSet resultSet = null;
        try {
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                resultValue = resultSet.getString(1).toString();
            }
        } catch (SQLException e) {
            log.error("Error executing sql", e);
            throw e;
        } finally {
            try {
                resultSet.close();
                statement.close();
                dbConnection.close();
            } catch (Exception e) {
                log.error("Error closing statement", e);
                throw e;
            }
        }
        return resultValue;
    }

    /**
     * Caller needs to close proc and connection!
     * @param storedProcSQL
     * @return
     * @throws Exception 
     */
    public static CallableStatement prepareStoredProc(String storedProcSQL) throws SQLException {
        Connection dbConnection = getShadowDBConnection();
        CallableStatement callableStatement = null;
        try {
            callableStatement = dbConnection.prepareCall(storedProcSQL);
        } catch (SQLException e) {
            log.error("Failed to prepare stored proc " + storedProcSQL, e);
            throw e;
        }
        return callableStatement;
    }

    public static void executeUpdateSQL(String updateSQL) throws SQLException {
        Connection dbConnection = getShadowDBConnection();
        Statement statement = null;
        try {
            statement = dbConnection.createStatement();
            statement.executeUpdate(updateSQL);
        } catch (SQLException e) {
            log.error("Error executeUpdateSQL", e);
        } finally {
            try {
                statement.close();
                dbConnection.close();
            } catch (Exception e) {
                log.error("Error closing connection", e);
                throw e;
            }
        }
    }

    private static Connection getShadowDBConnection() {
        String connectionUrl = null;
        String username = null;
        String password = null;
        try {
            connectionUrl = PageObjectUtils.getSUTValue("db.shadow.url");
            username = PageObjectUtils.getSUTValue("db.shadow.username");
            password = PageObjectUtils.getSUTValue("db.shadow.password");
        } catch (IOException e) {
            log.error("Error loading prop file", e);
            return null;
        }

        Connection connection = null;
        try {
            connection = DriverManager.getConnection(connectionUrl, username, password);
        } catch (SQLException e) {
            log.error("Error getting connection", e);
            return null;
        }
        return connection;
    }
    
}
