package com.wealth.trading.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.tools.ant.DirectoryScanner;
import com.wealth.trading.utils.CustomCommandLineJobRunner;
import com.wealth.trading.utils.DataBaseConnector;
import com.wealth.trading.utils.XMLComparator;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class CapsHardcopyXmlGenerationSteps extends ScenarioSteps {

	private static final long serialVersionUID = 1L;
	private static final Log log = LogFactory.getLog(CapsHardcopyXmlGenerationSteps.class);
	private static final String JOB_PATH = "com/mbl/wrap/caps/batch/batchApplicationContext.xml";
	private static final String JOB_NAME = "hardcopyToClientJob";

	@Step
	public void retrieveCorporateAction(int capsId) {
		log.info("Retrieving Corporate Action " + capsId);

		int id = 0;
		String actionType = "";
		String shortDesc = "";
		String asxCode = "";
		String actionStatus = "";

		try {
			CallableStatement proc = DataBaseConnector.prepareStoredProc("{call sd_caps_get_ca(?)}");

			proc.setInt(1, capsId);
			ResultSet rs = proc.executeQuery();

			while (rs.next()) {
				id = rs.getInt("cca_caps_id");
				actionType = rs.getString("cca_action_type");
				shortDesc = rs.getString("cat_short_desc");
				asxCode = rs.getString("cca_asx_code");
				actionStatus = rs.getString("cca_action_status");
			}

			log.debug("id: " + id);
			log.debug("actionType: " + actionType);
			log.debug("shortDesc: " + shortDesc);
			log.debug("asxCode: " + asxCode);
			log.debug("actionStatus: " + actionStatus);

			assertThat(capsId, equalTo(id));

			proc.close();
			proc.getConnection().close();
		} catch (SQLException e) {
			log.error("Error closing statement", e);
			fail("Error closing statement");
		}
	}

	@Step
	public void generateRequest(int capsId) {
		log.info("Generating Hardcopy Request for " + capsId);

		CallableStatement proc;
		try {
			proc = DataBaseConnector.prepareStoredProc("{call sd_caps_adv_email_hcopy_ins(?)}");
			proc.setInt(1, capsId);
			proc.execute();
			proc.close();
			proc.getConnection().close();
		} catch (SQLException e) {
			log.error("Error generateRequest", e);
			fail("Error generateRequest");
		}
	}

	@Step
	public void processRequest() {
		log.info("Processing hardcopy request");
		String[] jobArgs = { JOB_PATH, JOB_NAME };
		try {
			log.info("Running CustomCommandLineJobRunner");
			int exitCode = CustomCommandLineJobRunner.main(jobArgs);
			assertEquals(0, exitCode);
		} catch (Exception e) {
			log.error("Error running command line runner", e);
			fail("Error running command line runner");
		}
		log.info("SUCCESS");
	}

	@Step
	public void verifyXml(String expectedFile) throws Exception {
		log.info("Verifying generated xmls");
		InputStream expectedInputStream = CapsHardcopyXmlGenerationSteps.class
				.getResourceAsStream("/caps-batch/expected/" + expectedFile);
		if (expectedInputStream == null) {
			fail("No input XML file found");
		}
		String expectedXML = IOUtils.toString(expectedInputStream, "UTF-8");

		DirectoryScanner scanner = new DirectoryScanner();
		scanner.setBasedir("target/test-classes/caps-batch/generated");
		scanner.setIncludes(new String[] { "*hardcopy*.xml" });
		scanner.setCaseSensitive(false);
		scanner.scan();
		String[] files = scanner.getIncludedFiles();
		if (files.length == 0) {
			fail("No output XML file found");
		}
		log.debug("Output XML file: " + files[0]);
		InputStream actualInputStream = this.getClass().getResourceAsStream("/caps-batch/generated/" + files[0]);
		String actualXML = IOUtils.toString(actualInputStream, "UTF-8");

		log.trace("Expected XML: " + expectedXML);
		log.trace("Actual XML: " + actualXML);
		XMLComparator xmlComparator = new XMLComparator();
		xmlComparator.assertXMLEquals(expectedXML, actualXML);
	}

}
