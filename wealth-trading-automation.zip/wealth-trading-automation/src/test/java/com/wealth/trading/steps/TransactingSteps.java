package com.wealth.trading.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import com.wealth.trading.pages.AuthoriseOrdersPage;
import com.wealth.trading.pages.LoginPage;
import com.wealth.trading.pages.OrderConfirmationPage;
import com.wealth.trading.pages.PortfolioTransactingPage;

public class TransactingSteps extends ScenarioSteps {
	LoginPage loginPage;
	PortfolioTransactingPage portfolioTransactingPage;
	OrderConfirmationPage orderConfirmationPage;
	AuthoriseOrdersPage authoriseOrdersPage;

	@Step
	public void navigate_to_portfolio_transacting() {
		loginPage.clickPortfolioTransactingLink();
	}

	@Step
	public void search_account(String accountCode) {
		portfolioTransactingPage.searchForAccount(accountCode);
	}

	@Step
	public void create_equity_transaction(String securityCode, String quantity,
			String executeAt, String limit, String expiration) {
		portfolioTransactingPage.openBuyNewListedSecurityModal();
		portfolioTransactingPage.enterEquityTradeInfo(securityCode, quantity,
				executeAt, limit, expiration);
	}
	@Step
	public void buy_managed_investment(String securityCode, String amountValue){
		portfolioTransactingPage.openBuyNewManagedInvestmentsScreen();
		portfolioTransactingPage.enterManagedInvestmentInfo(securityCode, amountValue);
	}
	
	@Step
	public void generate_orders() {
		portfolioTransactingPage.generateOrders();

	}

	@Step
	public void authorise_orders(String accessCode, String password) {
		authoriseOrdersPage.populateAuthorizationForm(accessCode, password);
		authoriseOrdersPage.clickAuthoriseButton();
	}

	@Step
	public void authorise_orders(String password) {
		authoriseOrdersPage.populateAuthorizationForm(password);
		authoriseOrdersPage.clickAuthoriseButton();
	}

	@Step
	public void display_order_confirmation() {

		assertThat(orderConfirmationPage.checkConfirmationMessage().isEmpty(),
				equalTo(false));

	}

	@Step
	public void verifyOrderConfirmationMessage(String message) {
		assertThat(orderConfirmationPage.checkConfirmationMessage(),
				equalTo(message));
	}

}
