package com.wealth.trading.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class AdministrationPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();
	HomePage HomePage = new HomePage();

	@FindBy(linkText = "investment")
	private WebElementFacade lnk_investment;
	
	@FindBy(xpath = "//span[contains(text(), 'investment')]")
	private WebElementFacade elm_Investment;	
	
	public void navigate_MaintainInvestmentAccount(String BV) {				
			
			lnk_investment.waitUntilVisible();
			lnk_investment.click();				
		
	       	elm_Investment.waitUntilVisible();
	       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'investment')]")).getText()).containsIgnoringCase("maintain an investment account");	
		    			
			Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "superannuation")
	private WebElementFacade lnk_superannuation;	
	
	@FindBy(xpath = "//span[contains(text(), 'super')]")
	private WebElementFacade elm_Superannuation;
	
	public void navigate_MaintainSuperAccount(String BV) {				
		
		lnk_superannuation.waitUntilVisible();
		lnk_superannuation.click();				
	
		elm_Superannuation.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'super')]")).getText()).containsIgnoringCase("maintain a super account");	
	    			
		Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "pension")
	private WebElementFacade lnk_pension;	
	
	@FindBy(xpath = "//span[contains(text(), 'pension')]")
	private WebElementFacade elm_pension;
	
	public void navigate_MaintainPensionAccount(String BV) {				
		
		lnk_pension.waitUntilVisible();
		lnk_pension.click();				
	
		elm_pension.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'pension')]")).getText()).containsIgnoringCase("maintain a pension account");	
	    			
		Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "fiduciary")
	private WebElementFacade lnk_fiduciary;	
	
	@FindBy(xpath = "//span[contains(text(), 'fiduciary')]")
	private WebElementFacade elm_fiduciary;
	
	public void navigate_MaintainfiduciaryAccount(String BV) {				
		
		lnk_fiduciary.waitUntilVisible();
		lnk_fiduciary.click();				
	
		elm_fiduciary.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'fiduciary')]")).getText()).containsIgnoringCase("maintain a fiduciary account");	
	    			
		Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "adviser tax election")
	private WebElementFacade lnk_AdviserTaxElection;	
	
	@FindBy(xpath = "//span[contains(text(), 'tax')]")
	private WebElementFacade elm_AdviserTaxElection;
	
	public void navigate_ChangeAdviserTaxElection(String BV) {				
		
		lnk_AdviserTaxElection.waitUntilVisible();
		lnk_AdviserTaxElection.click();				
	
		elm_AdviserTaxElection.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'tax')]")).getText()).containsIgnoringCase("select adviser for tax elections");	
	    			
		Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "user preferences")
	private WebElementFacade lnk_UserPreferences;	
	
	@FindBy(xpath = "//span[contains(text(), 'prefer')]")
	private WebElementFacade elm_UserPreferences;
	
	public void navigate_ModifyUserPreferences(String BV) {				
		
		lnk_UserPreferences.waitUntilVisible();
		lnk_UserPreferences.click();				
	
		elm_UserPreferences.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'prefer')]")).getText()).containsIgnoringCase("your preferences");	
	    			
		Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "asset allocation override")
	private WebElementFacade lnk_assetAllocationOverride;	
	
	@FindBy(xpath = "//span[contains(text(), 'asset allocation over')]")
	private WebElementFacade elm_assetAllocationOverride;
	
	public void navigate_SetupOrMaintainAssetAllocationOverride(String BV) {				
		
		lnk_assetAllocationOverride.waitUntilVisible();
		lnk_assetAllocationOverride.click();				
	
		elm_assetAllocationOverride.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'asset allocation over')]")).getText()).containsIgnoringCase("asset allocation override");	
	    			
		Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "adviser/staff details")
	private WebElementFacade lnk_adviserOrstaffDetails;	
	
	@FindBy(xpath = "//span[contains(text(), 'select adviser')]")
	private WebElementFacade elm_adviserOrstaffDetails;
	
	public void navigate_ModifyAdviserOrStaffDetails(String BV) {				
		
		lnk_adviserOrstaffDetails.waitUntilVisible();
		lnk_adviserOrstaffDetails.click();				
	
		elm_adviserOrstaffDetails.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'select adviser')]")).getText()).containsIgnoringCase("select adviser codes to update");	
	    			
		Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "enter")
	private WebElementFacade lnk_EnterTransferInDetails;	
	
	@FindBy(xpath = "//span[contains(text(), 'choose')]")
	private WebElementFacade elm_EnterTransferInDetails;
	
	public void navigate_EnterTransferInDetails(String BV) {				
		
		lnk_EnterTransferInDetails.waitUntilVisible();
		lnk_EnterTransferInDetails.click();				
	
		elm_EnterTransferInDetails.waitUntilVisible();
       	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'choose')]")).getText()).containsIgnoringCase("choose transfer in type");	
	    			
		Serenity.takeScreenshot();		
	}	
	
}
