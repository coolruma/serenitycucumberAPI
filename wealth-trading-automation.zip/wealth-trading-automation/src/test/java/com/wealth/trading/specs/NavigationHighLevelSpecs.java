package com.wealth.trading.specs;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;

import net.thucydides.core.annotations.Steps;

import com.wealth.trading.steps.LoginSteps;
import com.wealth.trading.steps.TransactingSteps;
import com.wealth.trading.utils.PageObjectUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;

public class NavigationHighLevelSpecs {
	PageObjectUtils pageUtils = new PageObjectUtils();	
	
	@Steps
	com.wealth.trading.steps.NavigationHighLevelSteps NavigationHighLevelSteps;
	static LoginSteps loginSteps =  new LoginSteps();
	
	@When("^the \"(.*)\" adviser obtains the Dealer Reporting screen")	
	public void navigateDealerReporting(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_Dealer_Reporting(BV);
		
	}
	
	
	@Then("^the \"(.*)\" adviser can navigate to report by dealer screen")	
	public void navigatetoReportByDealer(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ReportByDealer(BV);
		NavigationHighLevelSteps.Navigate_Dealer_Reporting(BV);
		
	}
	
	@And("^the \"(.*)\" adviser can navigate to download files screen")	
	public void navigateDownloadFiles(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_downloadFiles(BV);
		NavigationHighLevelSteps.Navigate_Dealer_Reporting(BV);
		
	}
	
	@And("^the \"(.*)\" adviser can navigate to esi authentication details screen")	
	public void navigateEsiAuthDetails(String BV) throws InterruptedException{
				
		switch (BV.toUpperCase()) {
           	
        case "MPMPPT":
        	NavigationHighLevelSteps.log("esi authentication details option is NOT applicable for: "+BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("esi authentication details option is applicable for: "+BV);			
        	NavigationHighLevelSteps.Navigate_esiAuthDetails(BV);
    		NavigationHighLevelSteps.Navigate_Dealer_Reporting(BV);
        	break;
        }		
		
	}
	
	
	@And("^the \"(.*)\" adviser can navigate to fee disclosure statements screen")	
	public void navigateFeeDisclosureStmt(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMING":
        	NavigationHighLevelSteps.log("Fee disclosure statement option is NOT applicable for: "+BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Fee disclosure statement option is applicable for: "+BV);			
        	NavigationHighLevelSteps.Navigate_FeeDisclosureStmt(BV);
    		NavigationHighLevelSteps.Navigate_Dealer_Reporting(BV);
        	break;
        }
				
	}
	
	@And("^the \"(.*)\" adviser can navigate to RCTI screen")	
	public void navigateRCTI(String BV) throws InterruptedException{
		
		
		switch (BV.toUpperCase()) {
       	
        case "MPMADG": case "MPMAWT":
        	NavigationHighLevelSteps.log("RCTI option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_RCTI(BV);;
    		NavigationHighLevelSteps.Navigate_Dealer_Reporting(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("RCTI option is NOT applicable for: "+BV);        	
        	break;
        }
		
		
	}
	
	@When("^the \"(.*)\" adviser obtains the work in progress screen")	
	public void navigateWorkInProgress(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);;
		
	}
	
	@Then("^the \"(.*)\" adviser can navigate to work in progress orders screen")	
	public void navigateWipOrdersScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMING":
        	NavigationHighLevelSteps.log("work in progress orders option is NOT applicable for: "+BV);        	
        	break;
        	
        default:        	        	
        	NavigationHighLevelSteps.log("work in progress orders option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_Orders(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        }					
		
	}
	
	@And("^the \"(.*)\" adviser can navigate to Contract Notes screen")	
	public void navigateContractNotesScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT": case "MPMADG": case "MPMAWT":
        	NavigationHighLevelSteps.log("Contract notes option is NOT applicable for: "+BV);        	
        	break;
        	
        default:        	        	
        	NavigationHighLevelSteps.log("Contract notes option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_ContractNotes(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        }		
		
	}
	
	@And("^the \"(.*)\" adviser can navigate to Transfer In details screen")	
	public void navigateTransferInDetailsScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT": case "MPMADG": case "MPMAWT":
        	NavigationHighLevelSteps.log("Transfer in details option is NOT applicable for: "+BV);        	
        	break;
        	
        default:        	        	
        	NavigationHighLevelSteps.log("Transfer in details option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_TransferInDetails(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        }				
		
	}
	
	@And("^the \"(.*)\" adviser can navigate to esi transacting instruction screen")	
	public void navigatEsiTransactingInstructionScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT": case "MPMADG": case "MPMAWT": case "MPMSWP":
        	NavigationHighLevelSteps.log("esi transacting instruction option is NOT applicable for: "+BV);        	
        	break;
        	
        default:        	        	
        	NavigationHighLevelSteps.log("esi transacting instruction option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_esiTransactingInstruction(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        }		
		
	}
	
	@And("^the \"(.*)\" adviser can navigate to cash payments and receipts screen")	
	public void navigatCashPaymentsNReceiptsScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT":
        	NavigationHighLevelSteps.log("Cash payments and receipts option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_CashPaymentsNReceipts(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Cash payments and receipts option is NOT applicable for: "+BV);        	
        	break;
        }
		
				
	}
	
	@And("^the \"(.*)\" adviser can navigate to existing online applications")	
	public void navigatExistingOnlineAppsScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMADG": case "MPMAWT": case "MPMSWP":
        	NavigationHighLevelSteps.log("Existing online applications option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_ExistingOnlineApps(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Existing online applications option is NOT applicable for: "+BV);        	
        	break;
        }
		
				
	}
	
	@And("^the \"(.*)\" adviser can navigate to investment orders screen")	
	public void navigateInvestmentOrdersScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMING": 
        	NavigationHighLevelSteps.log("Investment orders option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_InvestmentOrders(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Investment orders option is NOT applicable for: "+BV);        	
        	break;
        }	
				
	}
	
	@And("^the \"(.*)\" adviser can navigate to super orders screen")	
	public void navigateSuperOrdersScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMING": 
        	NavigationHighLevelSteps.log("Super orders option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_SuperOrders(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Super orders option is NOT applicable for: "+BV);        	
        	break;
        }	
				
	}
	
	@And("^the \"(.*)\" adviser can navigate to pension orders screen")	
	public void navigatePensionOrdersScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMING": 
        	NavigationHighLevelSteps.log("Pension orders option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_PensionOrders(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Pension orders option is NOT applicable for: "+BV);        	
        	break;
        }	
				
	}
	
	@And("^the \"(.*)\" adviser can navigate to preset orders screen")	
	public void navigatePresetOrdersScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMING": 
        	NavigationHighLevelSteps.log("Preset orders option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_PresetOrders(BV);
    		NavigationHighLevelSteps.Navigate_WorkInProgress(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Preset orders option is NOT applicable for: "+BV);        	
        	break;
        }	
				
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate to portfolio transacting screen")	
	public void navigatePortfolioTranacting(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_PortfolioTransacting(BV);
		loginSteps.clickOnHomeLink();
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to corporate actions screen")	
	public void navigateCorporateActions(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_CorporateActions(BV);
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to Models screen")	
	public void navigateModels(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_Models(BV);
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to Bulk wholesale managed investments screen")	
	public void navigateBulkWholesaleManagedInvestments(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_BulkWholesaleManagedInvestments(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}		
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to Other Assets screen")	
	public void navigateOtherAssets(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPM":
        	NavigationHighLevelSteps.log("Other assets option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Other assets option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_OtherAssets(BV);
    		loginSteps.clickOnHomeLink();        	        	
        	break;
        }		
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate transact on investment account screen under transacting menu")	
	public void navigateTransactingInvestmentING(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_TransactingInvestmentING(BV);
		loginSteps.clickOnHomeLinkING(); 
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate transact on super account screen under transacting menu")	
	public void navigateTransactingSuperING(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_TransactingSuperING(BV);
		loginSteps.clickOnHomeLinkING(); 
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate transact on pension account screen under transacting menu")	
	public void navigateTransactingPensionING(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_TransactingPensionING(BV);
		loginSteps.clickOnHomeLinkING(); 
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate transfer in details screen under transacting menu")	
	public void navigateTransferInDetailsING(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_TransferInDetailsING(BV);
		loginSteps.clickOnHomeLinkING(); 
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate resources screen under resources menu")	
	public void navigateResourcesScreen(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_Resources(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate news and updates screen under resources menu")	
	public void navigateNewsNUpdatesScreen(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_NewsNUpdates(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate technical library screen under resources menu")	
	public void navigateTechLibraryScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT": case "MPMADG": case "MPMAWT": case "MPMING":
        	NavigationHighLevelSteps.log("Technical library option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Technical library option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_TechLibrary(BV);
    		loginSteps.clickOnHomeLink();      	        	
        	break;
        }
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate Macquarie Access screen under resources menu")	
	public void navigateMacqAccessScreen(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_MacqAccess(BV);
		loginSteps.clickOnHomeLink(); 
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate latest news screen under News and Updates page")	
	public void navigateLatestNewsINnewsNUpdates(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_latestNews(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate investment menu screen under News and Updates page")	
	public void navigateInvestmentMenuINnewsNUpdates(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_InvestmentMenu(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate Distribution update screen under News and Updates screen")	
	public void navigateDistributionUpdateINnewsNUpdates(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_DistributionUpdate(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate Alerts screen")	
	public void navigateAlerts(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_alerts(BV);	
		
		loginSteps.clickOnHomeLinkING();		
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate Portfolio Review Report screen")	
	public void navigatePortfolioReviewReport(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_portfolioReviewReport(BV);	
		
		loginSteps.clickOnHomeLink();		
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate Client And Adviser Reporting screen")	
	public void navigateClientAndAdviserReporting(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);	
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}		
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate run report for an investment or self managed super account screen")	
	public void navigateRunReportInvestmentAcct(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
		NavigationHighLevelSteps.Navigate_RunReportInvestment(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate run report for supperannuation account screen")	
	public void navigateRunReportSuperAcct(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
		NavigationHighLevelSteps.Navigate_RunReportSuper(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate run report for pension account screen")	
	public void navigateRunReportPensionAcct(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
		NavigationHighLevelSteps.Navigate_RunReportPension(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate run report for account group screen")	
	public void navigateRunReportByGroup(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
		NavigationHighLevelSteps.Navigate_RunReportAccountGroup(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate run report by adviser screen")	
	public void navigateRunReportByAdviser(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
		NavigationHighLevelSteps.Navigate_RunReportByAdviser(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate download statements screen")	
	public void navigateDownloadStatements(String BV) throws InterruptedException{
		
		
		switch (BV.toUpperCase()) {
       	
        case "MPMING": 
        	NavigationHighLevelSteps.log("Download statements option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Download statements option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
    		NavigationHighLevelSteps.Navigate_DownloadStmts(BV);
    		loginSteps.clickOnHomeLink();
        	break;
        }	
				
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to download file screen in client and adviser reporting")	
	public void navigateDownloadFilesAdviser(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
		NavigationHighLevelSteps.Navigate_downloadFiles(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to download excel report screen in client and adviser reporting")	
	public void navigateDownloadExcelAdviser(String BV) throws InterruptedException{
		
	switch (BV.toUpperCase()) {
       	
        case "MPMING": 
        	NavigationHighLevelSteps.log("Download excel report option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Download excel report option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
    		NavigationHighLevelSteps.Navigate_DownloadExcelReport(BV);		
    		loginSteps.clickOnHomeLink();
        	break;
        }	
		
		
		
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to esi authentication detail screen in client and adviser reporting")	
	public void navigateEsiAuthDetailsAdviser(String BV) throws InterruptedException{
		
	switch (BV.toUpperCase()) {
       	
        case "MPMSWP": 
        	NavigationHighLevelSteps.log("esi Authentication details option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("esi Authentication details option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
    		NavigationHighLevelSteps.Navigate_esiAuthDetails(BV);    		
    		
    		if(!BV.toUpperCase().contains("ING")){
    			
    			loginSteps.clickOnHomeLink();			
    			
    		}else {
    			
    			loginSteps.clickOnHomeLinkING();
    		}	
    		
        	break;
        }	
		
		
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to schedule reports screen in client and adviser reporting")	
	public void navigateScheduleReports(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
		NavigationHighLevelSteps.Navigate_ScheduleReport(BV);
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to report contact details screen in client and adviser reporting")	
	public void navigateReportContactDetails(String BV) throws InterruptedException{		
		
		switch (BV.toUpperCase()) {
       	
        case "MPMADG": case "MPMAWT": 
        	NavigationHighLevelSteps.log("Report contact details option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Report contact details option is  applicable for: "+BV);        	
        	NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
    		NavigationHighLevelSteps.Navigate_ReportContactDetails(BV);    		
    		
    		if(!BV.toUpperCase().contains("ING")){
    			
    			loginSteps.clickOnHomeLink();			
    			
    		}else {
    			
    			loginSteps.clickOnHomeLinkING();
    		}	
    		
        	break;
        }	
		
	}
	
	@SuppressWarnings("static-access")
	@And("^the \"(.*)\" adviser can navigate to fee disclosure stmts screen in client and adviser reporting")	
	public void navigateFeeDisClosureStmtsScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMSWP": case "MPMING":
        	NavigationHighLevelSteps.log("Fee disclosure statements option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Fee disclosure statements option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
    		NavigationHighLevelSteps.Navigate_FeeDiscStatementsAdviser(BV);		
    		loginSteps.clickOnHomeLink();
        	break;
        }
		
		
	}
	
	@And("^the \"(.*)\" adviser can navigate fiduciary reports screen in client and adviser reporting")	
	public void navigateFiduciaryReportsScreen(String BV) throws InterruptedException{
		
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT":
        	NavigationHighLevelSteps.log("Fiduciary reports option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_ClientNAdvierReporting(BV);
        	NavigationHighLevelSteps.Navigate_FiduciaryReportsAdviser(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Fiduciary reports option is NOT applicable for: "+BV);        	
        	break;
        }
		
	}
	
	@SuppressWarnings("static-access")
	@Then("^the \"(.*)\" adviser can navigate Administration screen")	
	public void navigateAdministration(String BV) throws InterruptedException{
		
		NavigationHighLevelSteps.Navigate_Administration(BV);	
		
		if(!BV.toUpperCase().contains("ING")){
			
			loginSteps.clickOnHomeLink();			
			
		}else {
			
			loginSteps.clickOnHomeLinkING();
		}		
		
	}
	
	
	@And("^the \"(.*)\" adviser can navigate maintain an investment account screen in administration page")	
	public void navigateMaintainInvestmentAccountScreen(String BV) throws InterruptedException{
		        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_MaintainInvestmentAccount(BV);
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate maintain a superannuation account screen in administration page")	
	public void navigateMaintainSuperAccountScreen(String BV) throws InterruptedException{
		        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_MaintainSuperannuationAccount(BV);
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate maintain a pension account screen in administration page")	
	public void navigateMaintainPensionAccountScreen(String BV) throws InterruptedException{
		        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_MaintainPensionAccount(BV);
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate maintain a fiduciary account screen in administration page")	
	public void navigateMaintainFiduciaryAccountScreen(String BV) throws InterruptedException{
		        	
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT":
        	NavigationHighLevelSteps.log("Maintain Fiduciary account option is applicable for: "+BV);
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_MaintainFiduciaryAccount(BV);
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Maintain Fiduciary account option is NOT applicable for: "+BV);        	
        	break;
        }		
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate change adviser tax election screen in administration page")	
	public void navigateAdviserTaxElectionScreen(String BV) throws InterruptedException{
		        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_ChangeAdviserTaxElection(BV);
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate modify user preferences screen in administration page")	
	public void navigateModifyUserPreferencesScreen(String BV) throws InterruptedException{
		        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_ModifyUserPreferences(BV);
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate setup or maintain asset allocation override screen in administration page")	
	public void navigateSetupOrMaintainAssetAllocationOverride(String BV) throws InterruptedException{		    	
        	
		switch (BV.toUpperCase()) {
       	
        case "MPMADG": case "MPMAWT":
        	NavigationHighLevelSteps.log("Asset allocation override option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Asset allocation override option is applicable for: "+BV);        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_SetupOrMaintainAssetAllocationOverride(BV);
        	break;
        }		
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate modify adviser or staff details screen in administration page")	
	public void navigateModifyAdviserOrStaffDetails(String BV) throws InterruptedException{
		        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_ModifyAdviserOrStaffDetails(BV);
   		
	}
	
	@And("^the \"(.*)\" adviser can navigate enter transfer in details screen in administration page")	
	public void navigateEnterTransferInDetails(String BV) throws InterruptedException{
		        	
        	
		switch (BV.toUpperCase()) {
       	
        case "MPMPPT": case "MPMADG": case "MPMAWT": 
        	NavigationHighLevelSteps.log("Enter transfer in details option is NOT applicable for: "+BV);        	
        	break;
        	
        default:
        	NavigationHighLevelSteps.log("Enter transfer in details option is applicable for: "+BV);        	
        	NavigationHighLevelSteps.Navigate_Administration(BV);
        	NavigationHighLevelSteps.Navigate_EnterTransferInDetails(BV);
        	break;
        }			
   		
	}
	
}
