package com.wealth.trading.utils;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.webdriver.WebDriverFacade;
import net.thucydides.core.webdriver.javascript.JavascriptExecutorFacade;

public class PageObjectUtils extends PageObject {

	static Properties properties;
	static String sutProfile = System.getProperty("sutProfile");

	public static String getSUTValue(String sKey) throws IOException {
		return loadSUTProfile().getProperty(sKey);
	}

	private static Properties loadSUTProfile() throws IOException {
		properties = new Properties();
		properties.load(new FileInputStream("src/test/resources/profiles/" + sutProfile + ".properties"));
		return properties;
	}

	public void scrollToWebElementFacade(WebElementFacade webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("arguments[0].scrollIntoView(true)",
				webElementToBeFocussed);
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollToWebElementAbove(WebElement webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("window.scrollTo(0,"
				+ webElementToBeFocussed.getLocation().y + "-100)");
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollToWebElementBelow(WebElement webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("window.scrollTo(0,"
				+ webElementToBeFocussed.getLocation().y + "+100)");
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollToWebElement(WebElement webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("arguments[0].scrollIntoView(true)",
				webElementToBeFocussed);
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollBy(final int ypos) {
		/*
		 * WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver())
		 * .getProxiedDriver();
		 * 
		 * JavascriptExecutor jse = (JavascriptExecutor) driver;
		 */
		JavascriptExecutorFacade js = new JavascriptExecutorFacade(getDriver());
		try {
			js.executeScript("scroll(0," + ypos + ")");
		} catch (Exception e) {
			System.out.println("-----Scroll Exception-----" + e.toString());
		}

	}

	public void zoomBy(int zoom) {
		WebDriver driver = ((WebDriverFacade) getDriver()).getProxiedDriver();

		JavascriptExecutor jse = (JavascriptExecutor) driver;

		try {
			jse.executeScript("document.body.style.zoom='" + zoom + "%'");

			// jse.executeScript("history.go(0)");

		} catch (Exception e) {
			System.out.println("-----Zoom Exception-----" + e);
		}
	}

	public List<WebElementFacade> findWebElementsForCss(String topElementClass) {
		return findAll(By.cssSelector(topElementClass));
	}

	public boolean isTextPresentInCSSSection(String topElementClass,
			String drawerTitle) throws InterruptedException {
		List<WebElementFacade> webElement = findWebElementsForCss(topElementClass);
		System.out.println("EXPECTED TO FIND:" + drawerTitle);
		for (WebElementFacade draw : webElement) {
			System.out.println("\n****FOUND *****\n:"
					+ draw.getText().replace("\n", ""));

			if (draw.getText().replace("\n", "").contains(drawerTitle)) {
				System.out.println("\n****VALUE IS *****\n:" + draw.getText());
				return true;
			}
		}
		return false;
	}

	public WebElement fluentWaitElement(final By byType) {
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver())
				.getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(7, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(byType);
			}
		});
		return element;
	}

	public WebElement fluentWaitElement(final By byType, int waitTime) {
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver())
				.getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(waitTime, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(byType);
			}
		});
		return element;
	}

	// Please note - below is not working as expected.. It needs some time to
	// fix
	// basically this will be utilise to access dynamic object with serenity
	// methods.
	// for sync purpose please use fluentWaitElement
	public WebElementFacade fluentWaitElementSerenity(final By byType) {
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver())
				.getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(7, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class);
		WebElementFacade element = wait
				.until(new Function<WebDriver, WebElementFacade>() {
					public WebElementFacade apply(WebDriver driver) {
						return element(byType);
					}
				});
		return element;
	}

	public WebElementFacade fluentWaitElementSerenity(final By byType,
			int waitTime) {
		// System.out.println("Jagrut" + LocalDateTime.now());
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver())
				.getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(waitTime, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class);
		WebElementFacade element = wait
				.until(new Function<WebDriver, WebElementFacade>() {
					public WebElementFacade apply(WebDriver driver) {
						// System.out.println("Jagruthello" +
						// LocalDateTime.now());
						return element(byType);
					}
				});
		// System.out.println("Jagrut" + LocalDateTime.now());
		return element;
	}

	public void waitForInvisibility(WebElement webElement, int maxSeconds) {
		waitFor(1000).milliseconds();
		Long startTime = System.currentTimeMillis();
		try {
			while (System.currentTimeMillis() - startTime < maxSeconds * 1000
					&& webElement.isDisplayed()) {
			}
		} catch (StaleElementReferenceException e) {
			return;
		} catch (Exception exp) {
			return;
		}
	}

	public int randInt(int min, int max) {

		Random rand = new Random();

		int randomNum = rand.nextInt((max - min) + 1) + min;

		return randomNum;
	}

	public static void clickTableCell(WebDriver driver, String ByVal,
			String tableId, String cellText) {
		// Grab the table
		WebElement table = null;
		if (ByVal.equalsIgnoreCase("cssSelector")) {
			table = driver.findElement(By.cssSelector(tableId));
		} else if (ByVal.equalsIgnoreCase("cssSelector")) {
			table = driver.findElement(By.id(tableId));
		} else if (ByVal.equalsIgnoreCase("xpath")) {
			table = driver.findElement(By.xpath(tableId));
		} else if (ByVal.equalsIgnoreCase("name")) {
			table = driver.findElement(By.name(tableId));
		}

		// Now get all the TR elements from the table
		List<WebElement> allRows = table.findElements(By.tagName("tr"));
		int rows_count = allRows.size();
		// And iterate over them, getting the cells
		Boolean flag = false;
		for (int row = 0; row < rows_count; row++) {
			if (!flag) {
				List<WebElement> cells = allRows.get(row).findElements(
						By.tagName("td"));
				int columns_count = cells.size();
				for (int column = 0; column < columns_count; column++) {
					// And so on
					String cellValue = cells.get(column).getText();
					if (cellValue.trim().equals(cellText)) {
						System.out.println("cell text is " + cellValue
								+ " and desired cell value is "
								+ cells.get(1).getText());
						// cells.get(1).
						cells.get(1).findElement(By.tagName("a")).click();
						// cell.click();
						flag = true;
						break;
					}
				}
			}
		}
	}

	public static void Verify_ListItems(WebDriver driver, String[] expected,
			String xpath) {

		// String[] expected = {"Stage 1 Get started", "Stage 2 Client details",
		// "Stage 3 Account details", "Stage 4 Entity details",
		// "Stage 5 Trustee details", "Stage 6 Officers and owners",
		// "Stage 7 Beneficial ownership", "Stage 8 Fee details",
		// "Stage 9 Office use only", "Stage 10 Entity verification",
		// "Stage 11 Client verification", "Stage 12 Documents upload",
		// "Stage 13 Submit"};
		WebElement dropdown = driver.findElement(By.xpath(xpath));
		Select select = new Select(dropdown);

		List<WebElement> allElements = select.getOptions();

		// make sure you found the right number of elements
		if (expected.length != allElements.size()) {
			System.out.println("fail, wrong number of stages found");
		}
		// make sure that the value of every <option> element equals the
		// expected value
		for (int i = 0; i < expected.length; i++) {

			String stageValue = allElements.get(i).getText();

			assertThat(stageValue).containsIgnoringCase(expected[i]);

			if (stageValue.equals(expected[i])) {
				System.out.println("passed on: " + stageValue);
			} else {
				System.out.println("failed on: " + stageValue);
			}
		}

	}

	public void WrapHeaderMenuNavigation(WebElementFacade link1,
			WebElementFacade link2) {
		link1.waitUntilVisible();
		// Thread.sleep(1000);
		link1.click();
		// link1.sendKeys(Keys.ENTER);
		/*
		 * Actions action = new Actions(getDriver());
		 * action.moveToElement(link1).build().perform();
		 */
		link2.waitUntilVisible();
		link2.click();
	}

	public void WrapHeaderMenuNavigation(WebElementFacade link1) {
		/*
		 * Actions action = new Actions(getDriver());
		 * action.moveToElement(link1).build().perform();
		 */
		link1.waitUntilVisible();
		link1.click();
	}

}
