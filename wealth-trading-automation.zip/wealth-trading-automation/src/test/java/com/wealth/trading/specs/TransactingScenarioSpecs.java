package com.wealth.trading.specs;

import java.util.List;

import net.thucydides.core.annotations.Steps;

import com.wealth.trading.steps.TransactingSteps;
import com.wealth.trading.utils.PageObjectUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransactingScenarioSpecs {
	PageObjectUtils pageUtils = new PageObjectUtils();

	@Steps
	TransactingSteps transactingSteps;

	@Given("^the adviser obtains the transacting screen for \"(.*)\" account")
	public void navigateToPortfolioTransactingWithSearchAccount(String account) {
		transactingSteps.navigate_to_portfolio_transacting();
		transactingSteps.search_account(account);
	}

	@When("User navigates to Portfolio Transacting")
	public void navigateToPortfolioTransacting() {
		transactingSteps.navigate_to_portfolio_transacting();
	}

	@When("User searches for account")
	public void searchAccount() {
		transactingSteps.search_account("M00006"); // D06562
	}

	@When("the adviser creates a new equity transaction with any of below security:")
	public void createEquityTransaction(DataTable tradeData) throws Throwable {

		List<List<String>> data = tradeData.raw();

		int randNumber = pageUtils.randInt(1, data.size() - 1); // Execute
																// random trade

		String SecurityCode = data.get(randNumber).get(0);
		String TradeValue = data.get(randNumber).get(1);
		String ExecuteAt = data.get(randNumber).get(2);
		String LimitPrice = data.get(randNumber).get(3);
		String Expiration = data.get(randNumber).get(4);

		transactingSteps.create_equity_transaction(SecurityCode, TradeValue,
				ExecuteAt, LimitPrice, Expiration);

	}
	
	@When("the adviser buys a new managed investment for security \"(.*)\" and amount \"(.*)\"")
	public void buyManagedInvestment(String securityCode, String amountValue){
		transactingSteps.buy_managed_investment(securityCode, amountValue);
	}
	@When("User generates orders")
	public void generateOrdersOld() {
		transactingSteps.generate_orders();
	}
	@When("Generates orders")
	public void generateOrders() {
		transactingSteps.generate_orders();
	}

	@When("Order is authorised")
	public void authoriseOrders() {
		transactingSteps.authorise_orders("60006754", "pass123");
	}

	@When("Authorise order with \"(.*)\"")
	public void authoriseOrdersWithPassword(String password) {
		transactingSteps.authorise_orders(password);
	}

	@Then("Display Order Confirmation Page")
	public void confirmOrder() {
		transactingSteps.display_order_confirmation();
	}

	@Then("Verify the following Order Confirmation:")
	public void confirmOrderWithMessage(DataTable message) {
		List<List<String>> data = message.raw();
		transactingSteps.verifyOrderConfirmationMessage(data.get(0).get(0));
	}
}
