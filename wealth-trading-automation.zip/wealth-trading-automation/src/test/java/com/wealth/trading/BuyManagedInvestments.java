package com.wealth.trading;

import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/BuyManagedInvestments/wrap_buy_managed_investment.feature")
public class BuyManagedInvestments {
}
