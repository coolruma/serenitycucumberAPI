package com.wealth.trading.models;

public class TradeOrderSummary {

	public String securityCode;
	public String tradeValue;
	public String executeAt;
	public String limitPrice;
	public String expiration;
	public String availableCash;

	public TradeOrderSummary(String SecurityCode, String TradeValue,
			String ExecuteAt, String LimitPrice, String Expiration) {
		this.securityCode = SecurityCode;
		this.tradeValue = TradeValue;
		this.executeAt = ExecuteAt;
		this.limitPrice = LimitPrice;
		this.expiration = Expiration;
	}

	public String getAvailableCash() {
		return availableCash;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public String getTradeValue() {
		return tradeValue;
	}

	public String getExecuteAt() {
		return executeAt;
	}

	public String getLimitPrice() {
		return limitPrice;
	}

	public String getExpiration() {
		return expiration;
	}

}
