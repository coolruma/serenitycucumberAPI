package com.wealth.trading.utils;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;


public class SSHUtils {
	
	public void runBatchJob(String user, String password, String hostName, int portNumber,String command1,String command2) throws IOException{
		
		try{
	    	Session session = new JSch().getSession(user, hostName, 22);        
	    	session.setPassword(password);
	    	java.util.Properties config = new java.util.Properties(); 
	    	config.put("StrictHostKeyChecking", "no");
	    	session.setConfig(config);
	    	session.connect();
	    	Channel channel=session.openChannel("exec");
	    	((ChannelExec)channel).setCommand(command1 + "|" + command2);
	    	@SuppressWarnings({ "deprecation", "unused" })
			String result = IOUtils.toString(channel.getInputStream());
	    	channel.disconnect();
	    	session.disconnect();
		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			
		}
	}
	
}

