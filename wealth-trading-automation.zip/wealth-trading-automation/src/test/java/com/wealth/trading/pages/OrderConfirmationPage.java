package com.wealth.trading.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

public class OrderConfirmationPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();

	@FindBy(id = "jq-spinnerContainer")
	private WebElementFacade spinnerContainer;

	@FindBy(xpath = "//p[@class='bold medium paddingTop inlineBlock']")
	private WebElementFacade confirmationMessage;

	public String checkConfirmationMessage() {
		pageUtils.fluentWaitElement(
				By.xpath("//p[@class='bold medium paddingTop inlineBlock']"),
				60);
		confirmationMessage.waitUntilVisible();
		return confirmationMessage.getText();
	}

}
