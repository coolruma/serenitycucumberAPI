package com.wealth.trading.specs;

import java.io.IOException;

import net.thucydides.core.annotations.Steps;

import com.wealth.trading.steps.LoginSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginScenarioSpecs {

	@Steps
	LoginSteps loginSteps;	
	static com.wealth.trading.models.SetGetTestEnv SetGetTestEnv =  new com.wealth.trading.models.SetGetTestEnv();

	@Given("User is on log-in page")
	public void goto_WrapOnline_LoginPage() throws IOException,
			InterruptedException {
		loginSteps.open_WrapOnline_LoginPage("MPM");
	}

	/*@When("User enters login details")
	public void enterLoginDetails() {
		loginSteps.login_to_WrapOnline_HardCoded_ToBeDeleted();
	}*/

	@When("User enters signin details")
	public void enterSignInDetails() throws InterruptedException {
		loginSteps.signIn_to_WrapOnline();
	}

	@When("User clicks on Transacting link")
	public void clickOnTransactingLink() {
		loginSteps.clickOnHomeLink();
	}

	@Then("User clicks on Home link")
	public void clickOnHomeLink() {
		loginSteps.clickOnHomeLink();
	}
	
	@Then("User clicks on Administration link")
	public void clickOnAdministrationLink() {
		loginSteps.clickOnAdministrationLink();
	}
	
	@Then("User logs out")
	public void logOut() {
		loginSteps.logOut();
	}

	@Then("the \"(.*)\" adviser logs out")
	public void adviserLogOut(String bv) {
		switch (bv.toUpperCase()) {
        case "MPMPPT":
        	//loginSteps.logOut();
        	loginSteps.endSession();
        	break;
        case "MPMING":
        	loginSteps.logOutING();;
        	break;
        	
        default:
           	loginSteps.logOut();
            break;
        }
	}

	@Given("^the \"(.*)\" adviser logs into wrap online with mac \"(.*)\" and password \"(.*)\"")
	public void loginTo_Wrap_Online(String bv, String mac, String password)
			throws Throwable {
		loginSteps.open_WrapOnline_LoginPage(bv.toUpperCase());
		//String testEnv = loginSteps.getTestEnv();
		//System.out.println("Guru print: " +testEnv);
		loginSteps.log("This execution is being done on: " +loginSteps.getTestEnv() + " Env");
		loginSteps.login_to_WrapOnline(bv,mac, password);
	}

}
