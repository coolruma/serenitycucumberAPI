package com.wealth.trading.specs;

import com.wealth.trading.steps.EmailBouncebackSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class EmailBouncebackScenarioSpecs {

    @Steps
    EmailBouncebackSteps emailBouncebackSteps;

    @Given("^Email with id \"(.*)\" is in initial status \"(.*)\"")
    public void setEmailInitialStatus(String id, String initialStatus) {
        emailBouncebackSteps.setEmailInitialStatus(id, initialStatus);
    }

    @When("Reporting service stored procedure is called with corro id \"(.*)\" and status \"(.*)\"")
    public void callReportingServiceStoredProcedure(String corroID, String reportStatus) {
        emailBouncebackSteps.callReportingServiceStoredProcedure(corroID, reportStatus);
    }

    @Then("Email with id \"(.*)\" is updated to \"(.*)\"")
    public void confirmUpdatedStatus(String id, String updatedStatus) {
        emailBouncebackSteps.confirmUpdatedStatus(id, updatedStatus);
    }
}
