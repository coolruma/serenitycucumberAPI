package com.wealth.trading.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class ClientAndAdviserReportsPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();
	HomePage HomePage = new HomePage();

	@FindBy(linkText = "investment")
	private WebElementFacade lnk_Investment;
	
	@FindBy(xpath = "//*[contains(text(), 'investment/self')]")
	private WebElementFacade elm_InvestmentSuperReport;
	
	@FindBy(xpath = "//span[contains(text(), 'investment reports')]")
	private WebElementFacade elm_InvestmentReports;
	
	public void navigate_RunReportInvestment(String BV) {				
			
			lnk_Investment.waitUntilVisible();
			lnk_Investment.click();				
			
			switch (BV.toUpperCase()) {
	        case "MPMPPT":
	        	elm_InvestmentReports.waitUntilVisible();
	        	assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'investment reports')]")).getText()).containsIgnoringCase("investment reports");
				break; 	       
	        	
	        default:
	        	elm_InvestmentSuperReport.waitUntilVisible();
	        	assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'investment/self')]")).getText()).containsIgnoringCase("investment/self managed super report");			
		        break;	        
			}
			
			Serenity.takeScreenshot();		
	}
	
	@FindBy(linkText = "superannuation")
	private WebElementFacade lnk_Super;
	
	@FindBy(xpath = "//*[contains(text(), 'superannuation reports')]")
	private WebElementFacade elm_superReports;
	
	public void navigate_RunReportSuper(String BV) {				
			
			lnk_Super.waitUntilVisible();
			lnk_Super.click();
			elm_superReports.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'superannuation reports')]")).getText()).containsIgnoringCase("superannuation reports");
			Serenity.takeScreenshot();		
		
	}
	
	@FindBy(linkText = "pension")
	private WebElementFacade lnk_pension;
	
	@FindBy(xpath = "//*[contains(text(), 'pension reports')]")
	private WebElementFacade elm_pensionReports;
	
	public void navigate_RunReportPension(String BV) {				
			
			lnk_pension.waitUntilVisible();
			lnk_pension.click();
			elm_pensionReports.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'pension reports')]")).getText()).containsIgnoringCase("pension reports");
			Serenity.takeScreenshot();		
		
	}
	
	/*@FindBy(xpath = "(//a[contains(text(), 'download')])[1]")
	private WebElementFacade lnk_downloadFiles;
	
	@FindBy(xpath = "//span[contains(text(), 'select download')]")
	private WebElementFacade elm_downloadFiles;
	
	public void navigate_DownloadFiles(String BV) {				
			
			lnk_downloadFiles.waitUntilVisible();
			lnk_downloadFiles.click();
			elm_downloadFiles.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'select download')]")).getText()).containsIgnoringCase("select download function");
			Serenity.takeScreenshot();		
		
	}*/
	
	@FindBy(xpath = "(//a[contains(text(), 'download')])[2]")
	private WebElementFacade lnk_downloadExcelReports;
	
	@FindBy(xpath = "//h2[contains(text(), 'Excel Reports')]")
	private WebElementFacade elm_excelReports;
	
	public void navigate_DownloadExcelReports(String BV) {				
			
			lnk_downloadExcelReports.waitUntilVisible();
			lnk_downloadExcelReports.click();
			elm_excelReports.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//h2[contains(text(), 'Excel Reports')]")).getText()).containsIgnoringCase("Excel Reports");
			Serenity.takeScreenshot();		
		
	}
	
	@FindBy(linkText = "account group")
	private WebElementFacade lnk_AccountGroup;
	
	@FindBy(xpath = "//span[contains(text(), 'report by group')]")
	private WebElementFacade elm_reportByGroup;
	
	public void navigate_RunReportAccountGroup(String BV) {				
			
			lnk_AccountGroup.waitUntilVisible();
			lnk_AccountGroup.click();
			elm_reportByGroup.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'report by group')]")).getText()).containsIgnoringCase("report by group");
			Serenity.takeScreenshot();
		
	}
	
	@FindBy(linkText = "all")
	private WebElementFacade lnk_AllReportByAdviser;
	
	@FindBy(xpath = "//span[contains(text(), 'report by adviser')]")
	private WebElementFacade elm_reportByAdviser;
	
	public void navigate_RunReportByAdviser(String BV) {				
			
			lnk_AllReportByAdviser.waitUntilVisible();
			lnk_AllReportByAdviser.click();
			elm_reportByAdviser.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//span[contains(text(), 'report by adviser')]")).getText()).containsIgnoringCase("report by adviser");
			Serenity.takeScreenshot();
		
	}
	
	@FindBy(linkText = "statements")
	private WebElementFacade lnk_Statements;
	
	@FindBy(xpath = "//h2[contains(text(), 'Statements')]")
	private WebElementFacade elm_Statements;
	
	public void navigate_downloadStatements(String BV) {				
			
			lnk_Statements.waitUntilVisible();
			lnk_Statements.click();
			elm_Statements.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//h2[contains(text(), 'Statements')]")).getText()).containsIgnoringCase("Statements");
			Serenity.takeScreenshot();
		
	}
	
	// for esi authentication details look into dealer reports page object
	
	@FindBy(linkText = "schedule")
	private WebElementFacade lnk_Schedule;
	
	@FindBy(xpath = "//span[contains(text(),'scheduling')]")
	private WebElementFacade elm_Schedule;
	
	public void navigate_ScheduleReports(String BV) {				
			
			lnk_Schedule.waitUntilVisible();
			lnk_Schedule.click();
			elm_Schedule.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//span[contains(text(),'scheduling')]")).getText()).containsIgnoringCase("select adviser for scheduling");
			Serenity.takeScreenshot();
		
	}
	
	@FindBy(linkText = "report contact details")
	private WebElementFacade lnk_ReportContactDetails;
	
	@FindBy(xpath = "//span[contains(text(),'reporting contact details')]")
	private WebElementFacade elm_ReportContactDetails;
	
	public void navigate_ReportContactDetails(String BV) {				
			
			lnk_ReportContactDetails.waitUntilVisible();
			lnk_ReportContactDetails.click();
			elm_ReportContactDetails.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//span[contains(text(),'reporting contact details')]")).getText()).containsIgnoringCase("reporting contact details");
			Serenity.takeScreenshot();
		
	}
	
	@FindBy(linkText = "fee disclosure statements")
	private WebElementFacade lnk_FeeDiscStatements;
	
	@FindBy(xpath = "//h2[contains(text(),'Fee disclosure statements')]")
	private WebElementFacade elm_FeeDiscStmts;
	
	public void navigate_FeeDisclosureStmtsAdviser(String BV) {				
			
			lnk_FeeDiscStatements.waitUntilVisible();
			lnk_FeeDiscStatements.click();
			elm_FeeDiscStmts.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//h2[contains(text(),'Fee disclosure statements')]")).getText()).containsIgnoringCase("Fee disclosure statements");
			assertThat(getDriver().findElement(By.xpath("(//span[contains(text(),'FDS profiles')])[1]")).getText()).containsIgnoringCase("FDS profiles");
			assertThat(getDriver().findElement(By.xpath("(//span[contains(text(),'FDS profiles')])[2]")).getText()).containsIgnoringCase("accounts to FDS profiles");
			Serenity.takeScreenshot();
		
	}
	
	@FindBy(linkText = "fiduciary")
	private WebElementFacade lnk_fiduciary;
	
	@FindBy(xpath = "//span[contains(text(),'fiduciary reports')]")
	private WebElementFacade elm_fiduciaryReports;
	
	public void navigate_FiduciaryReportsAdviser(String BV) {				
			
			lnk_fiduciary.waitUntilVisible();
			lnk_fiduciary.click();
			elm_fiduciaryReports.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//span[contains(text(),'fiduciary reports')]")).getText()).containsIgnoringCase("fiduciary reports");		
			Serenity.takeScreenshot();
		
	}
	
}
