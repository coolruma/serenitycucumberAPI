package com.wealth.trading.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class WorkInProgressPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();
	HomePage HomePage = new HomePage();

	@FindBy(xpath = "//*[contains(text(), 'orders')]")
	private WebElementFacade lnk_Orders;
		
	@FindBy(xpath = "//*[contains(text(),'Update search')]")
	private WebElementFacade btn_updateSearchWIP;
	
	@FindBy(xpath = "//button[@ng-click='close()']")
	private WebElementFacade btn_closeWIP;
	
	@FindBy(xpath = "(//*[contains(text(),'Work in progress')])[2]")
	private WebElementFacade elm_workInProgress;
	
	public void navigate_WipOrders(String BV) throws InterruptedException {
		
		if(lnk_Orders.isPresent()){
			
			lnk_Orders.waitUntilVisible();
			lnk_Orders.click();
			
			if(BV.toUpperCase().contains("ING")){
				
				pageUtils.fluentWaitElement(By.xpath("//*[contains(text(),'order list')]"),60);
				assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'order list')]")).getText()).containsIgnoringCase("order list");	
				
			}else {
				
				Thread.sleep(2000);
				if(btn_updateSearchWIP.isPresent()){

					btn_closeWIP.click();
				}
				
				//pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(),'Work in progress')])[2]"),60);
				elm_workInProgress.waitUntilVisible();
				assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Work in progress')])[2]")).getText()).containsIgnoringCase("Work in progress");

			}
			
			Serenity.takeScreenshot();
			
		}
	
	}
	
	@FindBy(xpath = "(//*[contains(text(), 'investment')])[2]")
	private WebElementFacade lnk_investmentOrders;
	
	@FindBy(xpath = "//*[contains(text(), 'investment order list')]")
	private WebElementFacade elm_investmentOrders;
	
	public void navigate_investmentOrders(String BV){
		
		lnk_investmentOrders.waitUntilVisible();
		lnk_investmentOrders.click();
		elm_investmentOrders.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'investment order list')]")).getText()).containsIgnoringCase("investment order list");
		Serenity.takeScreenshot();
	}
	
	@FindBy(xpath = "//*[contains(text(), 'superannuation')]")
	private WebElementFacade lnk_Superannuation;
	
	@FindBy(xpath = "//*[contains(text(), 'super order list')]")
	private WebElementFacade elm_SuperOrders;
	
	public void navigate_SuperOrders(String BV){
		
		lnk_Superannuation.waitUntilVisible();
		lnk_Superannuation.click();
		elm_SuperOrders.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'super order list')]")).getText()).containsIgnoringCase("super order list");
		Serenity.takeScreenshot();
	}
	
	@FindBy(xpath = "(//*[contains(text(), 'pension')])[2]")
	private WebElementFacade lnk_pension;
	
	@FindBy(xpath = "//*[contains(text(), 'pension order list')]")
	private WebElementFacade elm_PensionOrders;
	
	public void navigate_PensionOrders(String BV){
		
		lnk_pension.waitUntilVisible();
		lnk_pension.click();
		elm_PensionOrders.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'pension order list')]")).getText()).containsIgnoringCase("pension order list");
		Serenity.takeScreenshot();
	}
	
	@FindBy(xpath = "(//*[contains(text(), 'preset')])[2]")
	private WebElementFacade lnk_presetOrder;
	
	@FindBy(xpath = "(//*[contains(text(), 'view preset orders')])[2]")
	private WebElementFacade elm_presetOrders;
	
	public void navigate_PresetOrders(String BV){
		
		lnk_presetOrder.waitUntilVisible();
		lnk_presetOrder.click();
		elm_presetOrders.waitUntilVisible();
		assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'view preset orders')])[2]")).getText()).containsIgnoringCase("view preset orders");
		Serenity.takeScreenshot();
	}
	
	
	
	@FindBy(xpath = "(//*[contains(text(), 'contract notes')])[1]")
	private WebElementFacade lnk_contractNotes;
	
	
	@FindBy(xpath = "//*[contains(text(), 'contract note history')]")
	private WebElementFacade elm_contractNotes;
	
	public void navigate_ContractNotes(String BV) {
		
		if(lnk_contractNotes.isPresent()){
						
			lnk_contractNotes.waitUntilVisible();
			lnk_contractNotes.click();
			elm_contractNotes.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'contract note history')]")).getText()).containsIgnoringCase("contract note history");
			Serenity.takeScreenshot();
		} 
				
	}
	
	@FindBy(xpath = "//*[contains(text(), 'transfer in')]")
	private WebElementFacade lnk_TransferIn;
	
	@FindBy(xpath = "//*[contains(text(), 'transfer in list')]")
	private WebElementFacade elm_TransferIn;
	
	public void navigate_TransferIn(String BV) {
		
		if(lnk_TransferIn.isPresent()){
						
			lnk_TransferIn.waitUntilVisible();
			lnk_TransferIn.click();
			elm_TransferIn.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'transfer in list')]")).getText()).containsIgnoringCase("transfer in list");
			Serenity.takeScreenshot();
		} 
				
	}
	
	@FindBy(xpath = "(//*[contains(text(), 'esi transacting')])[1]")
	private WebElementFacade lnk_esiTransactingInstruction;
	
	@FindBy(xpath = "(//*[contains(text(), 'esi')])[2]")
	private WebElementFacade elm_esi;
	
	@FindBy(xpath = "(//*[contains(text(), 'esi')])[3]")
	private WebElementFacade elm_esiING;
	
	@FindBy(xpath = "(//*[contains(text(), 'transacting instruction')])[1]")
	private WebElementFacade elm_TransactingInstruction;
	
	@FindBy(xpath = "(//*[contains(text(), 'transacting instruction')])[2]")
	private WebElementFacade elm_TransactingInstructionING;
	
	public void navigate_esiTransatingInstruction(String BV) {
		
		lnk_esiTransactingInstruction.waitUntilVisible();
		lnk_esiTransactingInstruction.click();
		
		if(BV.toUpperCase().contains("ING")){						
			
			elm_esiING.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'esi')])[3]")).getText()).containsIgnoringCase("esi");
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'transacting instruction')])[2]")).getText()).containsIgnoringCase("transacting instruction");
			
		} else {
						
			elm_esi.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'esi')])[2]")).getText()).containsIgnoringCase("esi");
			assertThat(getDriver().findElement(By.xpath("(//*[contains(text(), 'transacting instruction')])[1]")).getText()).containsIgnoringCase("transacting instruction");
			
		}
		
		Serenity.takeScreenshot();
				
	}
	
	@FindBy(xpath = "//*[contains(text(), 'cash payments')]")
	private WebElementFacade lnk_CashPaymentsAndReceipts;
	
	@FindBy(xpath = "//*[contains(text(), 'Cash payments')]")
	private WebElementFacade elm_CashPaymentsAndReceipts;
	
	public void navigate_CashPaymentNReceipts(String BV) {
		
		if(lnk_CashPaymentsAndReceipts.isPresent()){
						
			lnk_CashPaymentsAndReceipts.waitUntilVisible();
			lnk_CashPaymentsAndReceipts.click();
			elm_CashPaymentsAndReceipts.waitUntilVisible();
			assertThat(getDriver().findElement(By.xpath("//*[contains(text(), 'Cash payments')]")).getText()).containsIgnoringCase("Cash payments and receipts");
			Serenity.takeScreenshot();
		} 
				
	}
	
	@FindBy(xpath = "//*[contains(text(), 'existing')]")
	private WebElementFacade lnk_existingOnlineApps;
	
	public void navigate_existingOnlineApps(String BV) throws InterruptedException{
		
		String parentWindowHandle = getDriver().getWindowHandle();
			
			lnk_existingOnlineApps.waitUntilVisible();
			lnk_existingOnlineApps.click();
			
			for(int a =1; a <=5; a++ ){									
				if(getDriver().getWindowHandles().size()>1){						
					break;
				}
			}			
			
			for(String handle : getDriver().getWindowHandles()){		
					
					getDriver().switchTo().window(handle);						
			}
			
			Thread.sleep(3000);
			
			if(!BV.toUpperCase().contains("SWP")){
				
				assertThat(getDriver().getCurrentUrl()).containsIgnoringCase("PegaWrap");	
				
			} else {
				
				assertThat(getDriver().getCurrentUrl()).containsIgnoringCase("PegaMacquarie");
				
			}
			
			assertThat(getDriver().getCurrentUrl()).containsIgnoringCase(BV.subSequence(3,6));
			
			Serenity.takeScreenshot();
			getDriver().close();
			getDriver().switchTo().window(parentWindowHandle);
		
	}
	
	
}
