package com.wealth.trading.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.wealth.trading.utils.PageObjectUtils;

//@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest1.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class ClientDetailsPage extends PageObject {

	PageObjectUtils pageUtils = new PageObjectUtils();
	HomePage Homepage;

	@FindBy(xpath = "//*[contains(text(),'modify file notes')]")
	private WebElementFacade lnk_modifyFileNotes;
	
	@FindBy(xpath = "//*[@name='file_notes']")
	private WebElementFacade txt_FileNotes;
	
	@FindBy(xpath = "//*[contains(text(),'cancel')]")
	private WebElementFacade lnk_cancel;
	
	@FindBy(xpath = "(//*[contains(text(),'continue')])[1]")
	private WebElementFacade lnk_Continue;	
	
	@FindBy(xpath = "//*[@name='Choices01']")
	private WebElementFacade lst_ChooseDropDown;
	
	@FindBy(xpath = "//*[@id='applicationMessages']/table[6]/tbody/tr[2]/td[5]")
	private WebElementFacade tbl_AccountType;
	
	@FindBy(xpath = "//*[@class='clientList']/tbody/tr[2]/td[5]")
	private WebElementFacade tbl_AccountTypeING;	
	
	@FindBy(xpath = "//*[contains(text(),'Update search')]")
	private WebElementFacade btn_updateSearchWIP;
	
	@FindBy(xpath = "//button[@ng-click='close()']")
	private WebElementFacade btn_closeWIP;
	
	@FindBy(xpath = "//*[contains(text(),'update client details')]")
	private WebElementFacade lnk_UpdateClientDetails;
	
	@FindBy(xpath = "//*[contains(text(),'Please select the client details you wish to update')]")
	private WebElementFacade elm_ClientDetails;
	
	
			
	public void modifyFileNotes(String BV){
		
		if(!BV.toLowerCase().contains("swp")){
		
			lnk_modifyFileNotes.click();
			
			if(txt_FileNotes.isPresent()){
				
				txt_FileNotes.type("test");
				lnk_cancel.click();		
			
			}
		}
	}
	
	
	public void UpdateClientDetails(String BV, String ClientOrAccount){
		
		if(lnk_UpdateClientDetails.isPresent()){
				
				lnk_UpdateClientDetails.click();
				
				assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'Please select the client details you wish to update')]")).getText()).containsIgnoringCase("client details");
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);			
		}
	}
	
	
    @SuppressWarnings("static-access")
	public void verifylistItem_ChooseDropDown(String BV, String AccountType) {
		 
    	String xpath = "//*[@name='Choices01']";
    	//String AccountType = tbl_AccountType.getText();
    	
    	switch (BV.concat(AccountType).toUpperCase()) {
		  case "MPMIM":
			  String[] expectedMPMIM = {"","transacting","transfer funds from cash account","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","administration","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMIM, xpath);
			  break;
		  case "MPMIC":
			  String[] expectedMPMIC = {"","transacting","transfer funds from cash account","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","administration","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMIC, xpath);
			  break;
		  case "MPMSM":
			  String[] expectedMPMSM = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSM, xpath);
			  break;
		  case "MPMPM":
			  String[] expectedMPMPM = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMPM, xpath);
			  break;
		  case "MPMPC":
			  String[] expectedMPMPC = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMPC, xpath);
			  break;
		  case "MPMSC":
			  String[] expectedMPMSC = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSC, xpath);
			  break;
		  case "MPMTA":
			  String[] expectedMPMTA = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMTA, xpath);
			  break;
		  case "MPMPPTIC":
			  String[] expectedMPMPPTIC = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","work in progress","other assets"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMPPTIC, xpath);
			  break;
		  case "MPMPPTFC":
			  String[] expectedMPMPPTFC = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","work in progress","other assets"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMPPTFC, xpath);
			  break;
		  case "MPMPPTPC":
			  String[] expectedMPMPPTPC = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMPPTPC, xpath);
			  break;
		  case "MPMPPTSC":
			  String[] expectedMPMPPTSC = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMPPTSC, xpath);
			  break;		
		  case "MPMSWPIM":
			  String[] expectedMPMSWPIM = {"","transacting","transfer funds from cash account","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","administration","work in progress","manage assets"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPIM, xpath);
			  break;		
		  case "MPMSWPICVC":
			  String[] expectedMPMSWPICVC = {"","transacting","transfer funds from cash account","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","administration","work in progress","manage assets"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPICVC, xpath);
			  break;
		  case "MPMSWPICVT":
			  String[] expectedMPMSWPICVT = {"","transacting","transfer funds from cash account","portfolio valuation","investment transactions","cash transactions","account details","reporting","administration","work in progress","manage assets"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPICVT, xpath);
			  break;	
		  case "MPMSWPPM":
			  String[] expectedMPMSWPPM = {"","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPPM, xpath);
			  break;		
		  case "MPMSWPSM":
			  String[] expectedMPMSWPSM = {"","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPSM, xpath);
			  break;
		  case "MPMSWPPC":
			  String[] expectedMPMSWPPC = {"","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPPC, xpath);
			  break;		
		  case "MPMSWPSC":
			  String[] expectedMPMSWPSC = {"","portfolio review","transacting","transfer funds from cash account","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPSC, xpath);
			  break;		
		  case "MPMSWPAP":
			  String[] expectedMPMSWPAP = {"","transacting","portfolio snapshot","portfolio valuation","investment transactions","cash transactions","account details","reporting","statements","administration","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMSWPAP, xpath);
			  break;	
		  case "MPMADGIC":
			  String[] expectedMPMADGIC = {"","portfolio review","transacting","transfer funds from cash account", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","work in progress","other assets"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMADGIC, xpath);
			  break;
		  case "MPMADGIM":
			  String[] expectedMPMADGIM = {"","transacting","transfer funds from cash account", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMADGIM, xpath);
			  break;
		  case "MPMADGSC":
			  String[] expectedMPMADGSC = {"","transacting","portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","portfolio review","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMADGSC, xpath);
			  break;
		  case "MPMADGPC":
			  String[] expectedMPMADGPC = {"","transacting","portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","portfolio review","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMADGPC, xpath);
			  break;			  
		  case "MPMAWTIM":
			  String[] expectedMPMAWTIM = {"","portfolio review","transacting","transfer funds from cash account", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","work in progress","other assets"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMAWTIM, xpath);
			  break;
		  case "MPMAWTTA":
			  String[] expectedMPMAWTTA = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","portfolio reivew","limit check","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMAWTTA, xpath);
			  break;
		  case "MPMAWTAP":
			  String[] expectedMPMAWTAP = {"","transacting", "portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "administration","limit check","portfolio reivew","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMAWTAP, xpath);
			  break;
		  case "MPMAWTSP":
			  String[] expectedMPMAWTSP = {"","portfolio snapshot", "portfolio valuation", "investment transactions", "cash transactions", "account details", "reporting", "statements", "portfolio reivew","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMAWTSP, xpath);
			  break;
		  case "MPMINGIM":
			  String[] expectedMPMINGIM = {"","portfolio snapshot", "portfolio valuation", "investment transactions", "cms transactions", "account details", "reporting", "administration","transacting","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMINGIM, xpath);
			  break;
		  case "MPMINGPM":
			  String[] expectedMPMINGPM = {"","portfolio snapshot", "portfolio valuation", "investment transactions", "cms transactions", "account details", "reporting", "administration","transacting","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMINGPM, xpath);
			  break;
		  case "MPMINGSM":
			  String[] expectedMPMINGSM = {"","portfolio snapshot", "portfolio valuation", "investment transactions", "cms transactions", "account details", "reporting", "administration","transacting","work in progress"};
			  pageUtils.Verify_ListItems(getDriver(), expectedMPMINGSM, xpath);
			  break;
			  
		 default:
			 //System.out.println("Gurus test--"+BV.concat(AccountType).toUpperCase());  
			 throw new IllegalArgumentException();
		       
		 }		 
		
    }
    
    
    public void verifyNavigation_ChooseDropDown(String BV, String ClientOrAccount) throws InterruptedException{
    	
    	WebElement dropdown = getDriver().findElement(By.xpath("//*[@name='Choices01']"));
		Select select = new Select(dropdown);
		List<WebElement> allElements = select.getOptions();
		
		String parentWindowHandle = getDriver().getWindowHandle();
		
		for (int i = 1; i < allElements.size(); i++){
			
			
			pageUtils.fluentWaitElement(By.xpath("//*[@name='Choices01']"), 20);
			
			lst_ChooseDropDown.selectByIndex(i);
			
			switch (lst_ChooseDropDown.getSelectedValue()){
				
			case "portfolio review" :
				lnk_Continue.click();
				assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Portfolio Review')])[2]")).getText()).containsIgnoringCase("Portfolio Review");
				//assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Portfolio balance graph')])[1]")).getText()).containsIgnoringCase("Portfolio balance graph");
				
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
			
			case "transacting" :
				lnk_Continue.click();
				
				if(BV.toUpperCase().contains("ING")){
					
				assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'transact on an')]")).getText()).containsIgnoringCase("transact on an");
					
				}else{
					
				assertThat(getDriver().findElement(By.xpath("//h2[contains(text(),'Portfolio transacting')]")).getText()).isEqualToIgnoringCase("Portfolio transacting");				
				}
				
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "transfer funds from cash account" :
				lnk_Continue.click();
				assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'funds transfer entry')]")).getText()).isEqualToIgnoringCase("funds transfer entry");
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "portfolio snapshot" :
				
				lnk_Continue.click();				
				System.out.println("parent window handle is -- " +parentWindowHandle);
				
				for(int a =1; a <=5; a++ ){									
					if(getDriver().getWindowHandles().size()>1){						
						break;
					}
				}			
				
				for(String handle : getDriver().getWindowHandles()){						
										
						getDriver().switchTo().window(handle);
						//System.out.println("switched to handle -- " +handle);					
										
				}
				
				pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(),'Snapshot')])[2]"),60);
				assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Snapshot')])[2]")).getText()).containsIgnoringCase("Snapshot");				
				Serenity.takeScreenshot();
				getDriver().close();
				getDriver().switchTo().window(parentWindowHandle);
				break;
				
			case "portfolio valuation" :
				
				lnk_Continue.click();
				
				for(int a =1; a <=5; a++ ){									
					if(getDriver().getWindowHandles().size()>1){						
						break;
					}
				}			
				
				for(String handle : getDriver().getWindowHandles()){		
						
						getDriver().switchTo().window(handle);						
				}
				
				pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(),'Portfolio Valuation')])[2]"),60);
				assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Portfolio Valuation')])[2]")).getText()).containsIgnoringCase("Portfolio Valuation");
				Serenity.takeScreenshot();
				getDriver().close();
				getDriver().switchTo().window(parentWindowHandle);
				break;
				
			case "investment transactions" :
				
				lnk_Continue.click();
				
				for(int a =1; a <=5; a++ ){									
					if(getDriver().getWindowHandles().size()>1){						
						break;
					}
				}			
				
				for(String handle : getDriver().getWindowHandles()){		
						
						getDriver().switchTo().window(handle);						
				}
				
				pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(),'Investment Transactions')])[2]"),60);
				assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Investment Transactions')])[2]")).getText()).containsIgnoringCase("Investment Transactions");
				Serenity.takeScreenshot();
				getDriver().close();
				getDriver().switchTo().window(parentWindowHandle);
				break;
				
			case "cash transactions" : case "cms transactions":
				
				lnk_Continue.click();
				
				for(int a =1; a <=5; a++ ){									
					if(getDriver().getWindowHandles().size()>1){						
						break;
					}
				}			
				
				for(String handle : getDriver().getWindowHandles()){		
						
						getDriver().switchTo().window(handle);						
				}
				
				pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(),'Cash Transactions')])[2]"),60);
				assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Cash Transactions')])[2]")).getText()).containsIgnoringCase("Cash Transactions");
				Serenity.takeScreenshot();
				getDriver().close();
				getDriver().switchTo().window(parentWindowHandle);
				break;
				
				
			case "account details" :
				
				lnk_Continue.click();
				
				if(BV.toUpperCase().contains("PPT")){
					
	     		assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'Account details')]")).getText()).containsIgnoringCase("Account details");
	     		Serenity.takeScreenshot();
	     		Homepage.clientAccountSearch(BV,ClientOrAccount);	
					
				}else{
					
					for(int a =1; a <=5; a++ ){									
						if(getDriver().getWindowHandles().size()>1){						
							break;
						}
					}			
					
					for(String handle : getDriver().getWindowHandles()){		
							
							getDriver().switchTo().window(handle);						
					}
					
					pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(),'Account Details')])[2]"),60);
					assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Account Details')])[2]")).getText()).containsIgnoringCase("Account Details");
					Serenity.takeScreenshot();
					getDriver().close();
					getDriver().switchTo().window(parentWindowHandle);
						
				}
				
				break;
				
			case "reporting" :
				lnk_Continue.click();
				assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'format for reports')]")).getText()).containsIgnoringCase("format for reports");
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "statements" :
				lnk_Continue.click();
				assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'Statements')]")).getText()).containsIgnoringCase("Statements");
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "administration" :	
				
				String AccountType = "";
								
				if(BV.toUpperCase().contains("ING")){
					
					 AccountType = tbl_AccountTypeING.getText();	
					
				}else{
					
					 AccountType = tbl_AccountType.getText();	
				}
				
				
				lnk_Continue.click();
				
				if(AccountType.equalsIgnoreCase("IC")||AccountType.equalsIgnoreCase("IM")||AccountType.equalsIgnoreCase("IA")||AccountType.equalsIgnoreCase("VT")||AccountType.equalsIgnoreCase("VC")){
					
					assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'maintain an investment account')]")).getText()).containsIgnoringCase("maintain an investment account");
					
				} else if (AccountType.equalsIgnoreCase("PC")||AccountType.equalsIgnoreCase("PM")||AccountType.equalsIgnoreCase("TA")){
					
					assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'maintain a pension account')]")).getText()).containsIgnoringCase("maintain a pension account");
					
				} else if (AccountType.equalsIgnoreCase("SM")||AccountType.equalsIgnoreCase("SA")||AccountType.equalsIgnoreCase("SC")){
					
					assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'maintain a super account')]")).getText()).containsIgnoringCase("maintain a super account");
					
				}
				
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "work in progress" :
				lnk_Continue.click();
				
				if(BV.toUpperCase().contains("ING")){
					
					pageUtils.fluentWaitElement(By.xpath("//*[contains(text(),'order list')]"),60);
					assertThat(getDriver().findElement(By.xpath("//*[contains(text(),'order list')]")).getText()).containsIgnoringCase("order list");	
					
				}else {
					
					Thread.sleep(2000);
					//pageUtils.fluentWaitElement(By.xpath("//*[contains(text(),'Update search')]"),60);
					if(btn_updateSearchWIP.isPresent()){

						//System.out.println("Guru Test");

						btn_closeWIP.click();
					}
					pageUtils.fluentWaitElement(By.xpath("(//*[contains(text(),'Work in progress')])[2]"),60);
					assertThat(getDriver().findElement(By.xpath("(//*[contains(text(),'Work in progress')])[2]")).getText()).containsIgnoringCase("Work in progress");
	
				}
				
				
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "limit check" :
				lnk_Continue.click();
				assertThat(getDriver().findElement(By.xpath("//a[contains(text(),'limit check')]")).getText()).containsIgnoringCase("limit check");
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "manage assets" :
				lnk_Continue.click();
				assertThat(getDriver().findElement(By.xpath("//h2[contains(text(),'Manage assets')]")).getText()).containsIgnoringCase("Manage assets");
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
				
			case "other assets" :
				lnk_Continue.click();
				assertThat(getDriver().findElement(By.xpath("//h2[contains(text(),'Other assets')]")).getText()).containsIgnoringCase("Other assets");
				Serenity.takeScreenshot();
				Homepage.clientAccountSearch(BV,ClientOrAccount);
				break;
			
			
			default:
				
				 throw new IllegalArgumentException();
										
			}
						
			
		}
    	
    	
    }


		
	
	
}
