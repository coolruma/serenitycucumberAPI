1. Please refer below to understand Serenity + Cucumber + BDD concepts
http://thucydides.info/docs/articles/an-introduction-to-serenity-bdd-with-cucumber.html


2. For your machine setup please follow below and ensure java build path is 1.8:
https://confluence.internal.macquarie.com/display/GUILD/Serenity+BDD+-+How+to+get+started 


3. Ensure your Chrome version and accordinlgy rename the chromedriver at "src\test\resources\chromedriver"
(E.g. if you have Chrome version 55 then change the chromedriver.exe to chromedriver_29.exe AND chromedriver_27.exe to chromedriver.exe)


4. To run the test: Access Command prompt. CD to the project directory (e.g. C:/TOOLS/projects/wealthtrading/wealth-trading-automation) 
and run "BDD.bat uat1"


5. Results will be available at "wealth-trading-automation/target/site/serenity/index.html"
(e.g. C:/TOOLS/projects/wealthtrading/wealth-trading-automation/target/site/serenity/index.html)
Please note - the results will be overwritten when you run again.

6. For further information refer below sites along with google:
http://toolsqa.com/cucumber/cucumber-jvm-feature-file/
http://thucydides.info/docs/serenity-staging/#introduction
https://cucumber.io/docs/reference