package com.org.macquarie.managedaccount.features.steps;

import org.junit.Assert;

import com.org.macquarie.managedaccount.pages.AutomaticCashManagement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AutomaticCashMgmntPageStep {
	AutomaticCashManagement currentPage;

	/// **** Code when user selects maximum plan with Dollars and Allocation
	/// method as Percentage***//

	@Given("^user has selected Maximum plan Buy investments with excess cash option$")
	public void user_has_selected_Maximum_plan_Buy_investments_with_excess_cash_option() throws Throwable {
		Assert.assertTrue((currentPage.containsText("Automatic Cash Management")));
	}

	@When("^User selects Dollars option$")
	public void user_selects_Dollars_option() throws Throwable {
		currentPage.clickCashTargetDollars();
		Thread.sleep(2000);
	}

	@When("^user enters cash target amount in Dollars '(\\d+)'$")
	public void user_enters_cash_target_amount_in_Dollars(int targetAmountInDollars) throws Throwable {
		Thread.sleep(4000);
		currentPage.enterCashTargetAmount(targetAmountInDollars + "");
	}

	@When("^user enters cash trigger amount in Dollars '(\\d+)'$")
	public void user_enters_cash_trigger_amount_in_Dollars(int triggerAmountInDollars) throws Throwable {
		currentPage.enterCashTriggerAmount(triggerAmountInDollars + "");
	}

	@When("^user enters investment limit amount '(\\d+)'$")
	public void user_enters_investment_limit_amount(int limitAmountInDollars) throws Throwable {
		currentPage.enterInvestmentLimitAmount(limitAmountInDollars + "");
	}

	@When("^user removes previously selected investment options if any$")
	public void user_removes_previously_selected_Investment_options_if_any() throws Throwable {
		currentPage.clickRemove();
	}

	@When("^user selects Investment options \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_selects_Investment_options(String percent1, String percent2, String percent3, String percent4)
			throws Throwable {
		currentPage.selectInvestmentOptions();
		currentPage.selectingMultipleInvestmentOptions(percent1, percent2, percent3, percent4);
	}

	@When("^user selects Investment options when allocation method is proportional$")
	public void user_selects_Investment_options_when_allocation_method_is_proportional() throws Throwable {
		currentPage.selectInvestmentOptions();
		currentPage.selectingMultipleInvestmentOptionsWithProportion();
	}

	@When("^clicks on Next$")
	public void clicks_on_Next() throws Throwable {
		currentPage.clickNext();
	}

	@Then("^user should land on Automatic Cash Management authorize page$")
	public void user_should_land_on_Automatic_Cash_Management_authorize_page() throws Throwable {
		Thread.sleep(3000);
		Assert.assertTrue((currentPage.containsText("Review and authorise")));
		currentPage.clickBack();
	}

	// *********Code for Maximum Plan with Cash Trigger/target value as
	// Percentage and allocation method as proportional******//
	@When("^User selects Percentage Portfolio Value$")
	public void user_selects_Percentage_Portfolio_Value() throws Throwable {
		currentPage.clickCashTargetPercentage();
	}

	@When("^user enters cash target amount in Percentage '(\\d+)'$")
	public void user_enters_cash_target_amount_in_Percentage(int targetAmountInPerc) throws Throwable {
		currentPage.enterCashTargetAmountInPercentage(targetAmountInPerc + "");
	}

	@When("^user enters cash trigger amount in Percentage '(\\d+)'$")
	public void user_enters_cash_trigger_amount_in_Percentage(int triggerAmountInPerc) throws Throwable {
		currentPage.enterCashTriggerAmountInPercentage(triggerAmountInPerc + "");
	}

	@When("^user selects allocation method as percentage$")
	public void user_selects_allocation_method_as_percentage() throws Throwable {
		currentPage.selectAllocationMethodInPercentage();
	}

	@When("^user selects allocation method as proportional$")
	public void user_selects_allocation_method_as_proportional() throws Throwable {
		currentPage.selectAllocationMethodInProportional();
	}

	@When("^user selects allocation method as proportional for min plan$")
	public void user_selects_allocation_method_as_proportional_for_min_plan() throws Throwable {
		currentPage.selectAllocationMethodInProportionalWithMinPlan();
	}

	// **********When User opts for Print Option*************************//
	@Given("^User has updated any cash plan in AutoCash Maangement screen$")
	public void user_has_updated_any_cash_plan_in_AutoCash_Maangement_screen() throws Throwable {

	}

	@When("^User seelcts printv option$")
	public void user_selects_print_option() throws Throwable {
	}

	@Then("^User should be able to save pdf file for selected Plan$")
	public void user_should_be_able_to_save_pdf_file_for_selected_Plan() throws Throwable {
	}

	// ********Code when user selects Minimum plan with Dollars and Allocation
	// method as Percentage****//

	@Given("^user has selected Minimum plan Buy investments with excess cash option$")
	public void user_has_selected_Minimum_plan_Buy_investments_with_excess_cash_option() throws Throwable {
		currentPage.UnClickMaxPlan();
		Thread.sleep(4000);
		currentPage.clickMinPlan();
	}

	@When("^User selects Dollars option for min plan$")
	public void user_selects_Dollars_option_for_min_plan() throws Throwable {
	}

	@When("^user enters cash target amount in Dollars with minimum option '(\\d+)'$")
	public void user_enters_cash_target_amount_for_min_plan(int targetAmountInDollarsMin) throws Throwable {
		currentPage.entersCashTargetAmountWithMinOption(targetAmountInDollarsMin + "");
	}

	@When("^user enters cash trigger amount in Dollars with minimum option '(\\d+)'$")
	public void user_enters_cash_trigger_amount_for_min_plan(int triggerAmountInDollarsMin) throws Throwable {
		currentPage.entersCashTriggerAmountWithMinOption(triggerAmountInDollarsMin + "");
	}

	@When("^user selects allocation method as percentage for min plan$")
	public void user_selects_allocation_method_as_percentage_for_min_plan() throws Throwable {
		currentPage.selectAllocationMethodInPercentageWithMinOption();
	}

	@When("^user selects Investment options for min plan \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_selects_Investment_options_for_min_plan(String percent1, String percent2, String percent3,
			String percent4) throws Throwable {
		currentPage.selectInvestmentOptionsWithMinOption();
		currentPage.selectingMultipleInvestmentOptionsWithMinOption(percent1, percent2, percent3, percent4);
	}

	@When("^user selects Investment options for min plan with priority option \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_selects_Investment_options_for_min_plan_with_priority_option(String priority1, String priority2,
			String priority3, String priority4) throws Throwable {
		// currentPage.selectInvestmentOptionsWithMinOption();
		currentPage.selectingMultipleInvestmentOptionsWithMinOptionWithPriority(priority1, priority2, priority3,
				priority4);
	}

	@When("^user selects Percentage Portfolio Value with min plan$")
	public void user_selects_Percentage_portfolio_value_with_min_plan() throws Throwable {
		currentPage.clickPercentagePortfolioValueWithMinOption();
	}

	@When("^user enters cash target amount in Percentage with min option '(\\d+)'$")
	public void user_enters_cash_target_amount_in_percentage_with_min_option(String targetAmountInPercsMin)
			throws Throwable {
		currentPage.setCashTargetWIthPercentagePortfolioWithMinOption(targetAmountInPercsMin + "");
	}

	@When("^user enters cash trigger amount in Percentage with min option '(\\d+)'$")
	public void user_enters_cash_trigger_amount_in_percentage_with_min_option(String triggerAmountInPercsMin)
			throws Throwable {
		currentPage.setCashTriggerWIthPercentagePortfolioWithMinOption(triggerAmountInPercsMin + "");
	}

	@When("^user selects Investment options for min plan with priority option$")
	public void user_selects_Investment_options_for_min_plan_with_priority_option() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	// ****************************************Validation
	// Scenarios***************************************//
	@Given("^User is on Automatic Cash Management page$")
	public void user_is_on_Automatic_Cash_Management_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User clicks on Maximum plan Buy investments with excess cash option$")
	public void user_clicks_on_Maximum_plan_Buy_investments_with_excess_cash_option() throws Throwable {
		currentPage.UnClickMinPlan();
		currentPage.clickMaxPlan();
	}

	@When("^User enters cash target amount in Dollars with maximum option '(\\d+)'$")
	public void user_enters_cash_target_amount_in_Dollars_with_maximum_option(int targetAmount) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User enters cash trigger amount less than Cash targetamount in Dollars '(\\d+)'$")
	public void user_enters_cash_trigger_amount_less_than_Cash_targetamount_in_Dollars(int triggerAmount)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^User should get error \"([^\"]*)\"$")
	public void user_should_get_error_Maximum_cash_trigger_must_be_greater_than_the_Maximum_cash_target(String error)
			throws Throwable {
		System.out.println(error);
		Assert.assertTrue(currentPage.validatesErrorMaxDollarCashTriggerGreaterThanCashTarget(error));
		// Assert.assertTrue(currentPage.containsText(error));
	}

	@When("^User enters cash target amount in Dollars with amount less than (\\d+) with maximum option '(\\d+)'$")
	public void user_enters_cash_target_amount_in_Dollars_with_amount_less_than_with_maximum_option(int targetAmount)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User enters cash target and cash trigger amount with difference less than '(\\d+)'$")
	public void user_enters_cash_target_and_cash_trigger_amount_with_difference_less_than(int arg1, int arg2)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User clicks on Investment Option checkbox$")
	public void user_clicks_on_Investment_Option_checkbox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User directly clicks on 'OK' button without selecting any investments$")
	public void user_directly_clicks_on_OK_button_without_selecting_any_investments() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^User should receive an error 'You must select at least one option'$")
	public void user_should_receive_an_error_You_must_select_at_least_one_option() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User clicks on Minimum plan Buy investments with excess cash option$")
	public void user_clicks_on_Minimum_plan_Buy_investments_with_excess_cash_option() throws Throwable {
		currentPage.UnClickMaxPlan();
		Thread.sleep(4000);
		currentPage.clickMinPlan();
	}

	@When("^User enters cash trigger amount  greater than Cash target amount in Dollars '(\\d+)'$")
	public void user_enters_cash_trigger_amount_greater_than_Cash_target_amount_in_Dollars(int triggerAmount)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^user selects Investment options for min plan$")
	public void user_selects_Investment_options_for_min_plan() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

}
