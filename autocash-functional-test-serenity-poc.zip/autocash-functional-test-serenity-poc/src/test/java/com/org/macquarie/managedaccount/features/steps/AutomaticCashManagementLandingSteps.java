package com.org.macquarie.managedaccount.features.steps;

import org.junit.Assert;

import com.org.macquarie.managedaccount.pages.AutomaticCashManagement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AutomaticCashManagementLandingSteps {
	AutomaticCashManagement currentPage;

	// AutoCash Management with Maximum plan
	@Given("^user is on Automatic Cash Management page$")
	public void user_is_on_Automatic_Cash_Management_page() throws Throwable {
		for (String winHandle : currentPage.getDriver().getWindowHandles()) {
			currentPage.getDriver().switchTo().window(winHandle);
		}
		currentPage.containsText("Automatic Cash Management");
		Assert.assertTrue((currentPage.containsText("Automatic Cash Management")));
	}

	@When("^User clicks on Maximum plan Buy investments with excess cash$")
	public void user_clicks_on_Maximum_plan_Buy_investments_with_excess_cash() throws Throwable {
		currentPage.clickMaxPlan();
		Thread.sleep(2000);
	}

	@Then("^'Maximum Plan Buy pane opens'$")
	public void maximum_Plan_Buy_pane_opens() throws Throwable {
		Thread.sleep(2000);
		Assert.assertTrue((currentPage.containsText("Investment selection")));
		currentPage.getDriver().manage().window().maximize();
	}

	// AutoCash Management with Minimum plan
	@When("^User clicks on Minimum plan Buy investments with excess cash$")
	public void user_clicks_on_Minimum_plan_Buy_investments_with_excess_cash() throws Throwable {
		currentPage.clickMinPlan();
		Thread.sleep(2000);
	}

	@Then("^'Minimum Plan Buy pane opens'$")
	public void minimum_Plan_Buy_pane_opens() throws Throwable {
		Assert.assertTrue((currentPage.containsText("Investment selection")));
	}

}
