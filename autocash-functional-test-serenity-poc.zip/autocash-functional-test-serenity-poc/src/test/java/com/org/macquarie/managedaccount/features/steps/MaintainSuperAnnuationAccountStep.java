package com.org.macquarie.managedaccount.features.steps;

import org.junit.Assert;

import com.org.macquarie.managedaccount.pages.AutomaticCashManagement;
import com.org.macquarie.managedaccount.pages.MaintainSuperAnnuationAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MaintainSuperAnnuationAccountStep {

	MaintainSuperAnnuationAccountPage currentPage;
	AutomaticCashManagement acm;

	@When("^User clicks on 'superannuation account'$")
	public void user_clicks_on_maintains_an_investment_account() throws Throwable {
		currentPage.clickOnSuperAnnuationLink();
	}

	@Then("^'User Should be on maintain a super account search page'$")
	public void user_Should_be_on_maintain_an_investment_account_search_page() throws Throwable {
	}

	@Given("^User is on maintain a super account search page$")
	public void user_is_on_maintain_a_super_account_search_page() throws Throwable {
	}

	@When("^under super,User enters \"([^\"]*)\"$")
	public void under_super_User_enters(String account) throws Throwable {
		currentPage.searchSuperAccount(account);
	}

	@When("^under super,clicks on 'automatic cash management'$")
	public void under_super_clicks_on_automatic_cash_management() throws Throwable {
		currentPage.clickOnAutomaticCashManagement();
		Thread.sleep(10000);
	}

	@Then("^under super, 'User Should be on Automatic Cash Management page with same 'D(\\d+)'$")
	public void under_super_User_Should_be_on_Automatic_Cash_Management_page_with_same_D(int arg1) throws Throwable {
	}

	@Given("^under super, user is on Automatic Cash Management page$")
	public void under_super_user_is_on_Automatic_Cash_Management_page() throws Throwable {

		for (String winHandle : currentPage.getDriver().getWindowHandles()) {
			currentPage.getDriver().switchTo().window(winHandle);
		}
		currentPage.containsText("Automatic Cash Management");
		Assert.assertTrue((currentPage.containsText("Automatic Cash Management")));
	}

	@When("^under super, User clicks on Maximum plan Buy investments with excess cash$")
	public void under_super_User_clicks_on_Maximum_plan_Buy_investments_with_excess_cash() throws Throwable {
		currentPage.clickMaxPlan();
		Thread.sleep(2000);
	}

	@Then("^under super,'Maximum Plan Buy pane opens'$")
	public void under_super_Maximum_Plan_Buy_pane_opens() throws Throwable {
		Thread.sleep(2000);
		Assert.assertTrue((currentPage.containsText("Investment selection")));
		currentPage.getDriver().manage().window().maximize();
	}

	@Given("^under super, user has selected Maximum plan Buy investments with excess cash option$")
	public void under_super_user_has_selected_Maximum_plan_Buy_investments_with_excess_cash_option() throws Throwable {
		Assert.assertTrue((currentPage.containsText("Automatic Cash Management")));
	}

	@When("^under super, User selects Dollars option$")
	public void under_super_User_selects_Dollars_option() throws Throwable {
		currentPage.clickCashTargetDollars();
		Thread.sleep(2000);
	}

	@When("^under super,user enters cash target amount in Dollars '(\\d+)'$")
	public void under_super_user_enters_cash_target_amount_in_Dollars(int targetAmountInDollars) throws Throwable {
		Thread.sleep(4000);
		currentPage.enterCashTargetAmount(targetAmountInDollars + "");
	}

	@When("^under super,user enters cash trigger amount in Dollars '(\\d+)'$")
	public void under_super_user_enters_cash_trigger_amount_in_Dollars(int triggerAmountInDollars) throws Throwable {
		currentPage.enterCashTriggerAmount(triggerAmountInDollars + "");
	}

	@When("^under super,user enters investment limit amount '(\\d+)'$")
	public void under_super_user_enters_investment_limit_amount(int limitAmountInDollars) throws Throwable {
		currentPage.enterInvestmentLimitAmount(limitAmountInDollars + "");
	}

	@When("^under super,user selects allocation method as percentage$")
	public void under_super_user_selects_allocation_method_as_percentage() throws Throwable {
		currentPage.clickAllocationMethodAsPercentageForMaxPlan();
	}

	@When("^under super,user selects Investment options \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void under_super_user_selects_Investment_options_and_and_and(String percent1, String percent2,
			String percent3, String percent4) throws Throwable {
		currentPage.selectInvestmentOptions();
		currentPage.selectingMultipleInvestmentOptions(percent1, percent2, percent3, percent4);
	}

	@When("^under super,clicks on Next$")
	public void under_super_clicks_on_Next() throws Throwable {
		currentPage.clickNext();
	}

	@Then("^under super,user should land on Automatic Cash Management authorize page$")
	public void under_super_user_should_land_on_Automatic_Cash_Management_authorize_page() throws Throwable {
		Assert.assertTrue((currentPage.containsText("Review and authorise")));
		currentPage.clickBack();
	}

	@Given("^under super,user has selected Minimum plan Buy investments with excess cash option$")
	public void under_super_user_has_selected_Minimum_plan_Buy_investments_with_excess_cash_option() throws Throwable {
		currentPage.UnClickMaxPlan();
		Thread.sleep(4000);
		currentPage.clickMinPlan();
	}

	@When("^under super,user enters cash target amount in Dollars with minimum option '(\\d+)'$")
	public void under_super_user_enters_cash_target_amount_in_Dollars_with_minimum_option(int targetAmountInDollarsMin)
			throws Throwable {
		currentPage.entersCashTargetAmountWithMinOption(targetAmountInDollarsMin + "");
	}

	@When("^under super,user enters cash trigger amount in Dollars with minimum option '(\\d+)'$")
	public void under_super_user_enters_cash_trigger_amount_in_Dollars_with_minimum_option(
			int triggerAmountInDollarsMin) throws Throwable {
		currentPage.entersCashTriggerAmountWithMinOption(triggerAmountInDollarsMin + "");
	}

	@When("^under super,user selects allocation method as priority for min plan$")
	public void under_super_user_selects_allocation_method_as_priority_for_min_plan() throws Throwable {
		currentPage.selectAllocationMethodInProportionalWithMinPlan();
	}

	@When("^under super,user selects Investment options for min plan with priority option \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void under_super_user_selects_Investment_options_for_min_plan_with_priority_option_and_and_and(
			String priority1, String priority2, String priority3, String priority4) throws Throwable {
		// currentPage.selectInvestmentOptionsWithMinOption();
		currentPage.selectInvestmentOptions();
		currentPage.selectingMultipleInvestmentOptionsWithMinOptionWithPriority(priority1, priority2, priority3,
				priority4);
	}

	@When("^under super,user selects allocation method as proportional$")
	public void under_super_user_selects_allocation_method_as_proportional() throws Throwable {
	}

	@When("^under super,user selects Percentage Portfolio Value with min plan$")
	public void under_super_user_selects_Percentage_Portfolio_Value_with_min_plan() throws Throwable {
		currentPage.clickPercentagePortfolioValueWithMinOption();
	}

	@When("^under super,user enters cash target amount in Percentage with min option '(\\d+)'$")
	public void under_super_user_enters_cash_target_amount_in_Percentage_with_min_option(int targetAmountInPercsMin)
			throws Throwable {
		currentPage.setCashTargetWIthPercentagePortfolioWithMinOption(targetAmountInPercsMin + "");
	}

	@When("^under super,user enters cash trigger amount in Percentage with min option '(\\d+)'$")
	public void under_super_user_enters_cash_trigger_amount_in_Percentage_with_min_option(int triggerAmountInPercsMin)
			throws Throwable {
		currentPage.setCashTriggerWIthPercentagePortfolioWithMinOption(triggerAmountInPercsMin + "");
	}

	@When("^under super,user selects allocation method as percentage for min plan$")
	public void under_super_user_selects_allocation_method_as_percentage_for_min_plan() throws Throwable {
		currentPage.selectAllocationMethodInPercentageWithMinOption();
	}

	@When("^under super,user selects Investment options for min plan \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void under_super_user_selects_Investment_options_for_min_plan(String percent1, String percent2,
			String percent3, String percent4) throws Throwable {
		// currentPage.selectInvestmentOptionsWithMinOption();
		currentPage.selectInvestmentOptions();
		currentPage.selectingMultipleInvestmentOptionsWithMinOption(percent1, percent2, percent3, percent4);
	}

}
