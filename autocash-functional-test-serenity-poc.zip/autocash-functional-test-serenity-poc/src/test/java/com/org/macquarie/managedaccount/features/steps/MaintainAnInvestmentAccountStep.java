package com.org.macquarie.managedaccount.features.steps;

import org.junit.Assert;

import com.org.macquarie.managedaccount.pages.AutomaticCashManagement;
import com.org.macquarie.managedaccount.pages.MaintainInvestmentAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MaintainAnInvestmentAccountStep {

	MaintainInvestmentAccountPage currentPage;
	AutomaticCashManagement acm;

	@Given("^User is on maintain an investment account search page$")
	public void user_is_on_maintain_an_investment_account_search_page() throws Throwable {
		if (!currentPage.containsText("maintain an investment account")) {
			throw new RuntimeException("Error loading page");
		} else {
			System.out.println("Investment page was loaded");
		}
	}

	@When("^User search an \"([^\"]*)\"$")
	public void user_search_an_V(String account) throws Throwable {
		currentPage.searchInvestmentAccount(account);
	}

	@When("^clicks on 'automatic cash management'$")
	public void clicks_on_automatic_cash_management() throws Throwable {
		currentPage.clickOnAutomaticCashManagement();
		Thread.sleep(10000);
	}

	@Then("^User Should be on Automatic Cash Management page with same \"([^\"]*)\"$")
	public void user_Should_be_on_Automatic_Cash_Management_page_with_same(String account) {
		Assert.assertTrue(currentPage.getDriver().getWindowHandles().size() == 2);

	}

}
