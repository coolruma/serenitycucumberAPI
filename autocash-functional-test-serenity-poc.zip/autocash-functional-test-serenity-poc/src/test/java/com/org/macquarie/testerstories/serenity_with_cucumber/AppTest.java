package com.org.macquarie.testerstories.serenity_with_cucumber;

/**
 * Unit test for simple App.
 */

public class AppTest {
}
