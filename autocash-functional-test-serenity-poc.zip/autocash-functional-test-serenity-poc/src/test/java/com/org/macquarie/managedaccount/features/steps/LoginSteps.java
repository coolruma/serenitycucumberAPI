package com.org.macquarie.managedaccount.features.steps;

import com.org.macquarie.managedaccount.pages.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	LoginPage loginPage;

	@Given("^User is on Macquarie wrap Homepage$")
	public void user_is_on_Macquarie_wrap_Homepage() throws Throwable {
		loginPage.open();
	}

	@When("^User Navigate to LogIn Page$")
	public void user_Navigate_to_LogIn_Page() throws Throwable {
	}

	// @Given("^I use Valid \"([^\"]*)\" and Valid \"([^\"]*)\"$")
	@When("^User enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_UserName_and_Password(String userId, String password) throws Throwable {
		loginPage.addLoginCredentialsAndSubmit(userId, password);
	}

	@Then("^'User should be able to login' on Macquarie Wrap HomePage$")
	public void user_should_be_able_to_login_on_Macquarie_Wrap_HomePage() throws Throwable {

		// Assert.assertEquals(loginPage.getTitle(),"Macquarie Wrap");

	}
}
