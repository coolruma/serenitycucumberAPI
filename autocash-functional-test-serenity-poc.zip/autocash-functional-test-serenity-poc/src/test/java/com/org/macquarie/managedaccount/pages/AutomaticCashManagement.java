package com.org.macquarie.managedaccount.pages;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.org.macquarie.managedaccount.utils.PageObjectUtils;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.webelements.Checkbox;

public class AutomaticCashManagement extends PageObject {

	// Find elements within AutoCash Screen
	PageObjectUtils pageObjectUtils = new PageObjectUtils();

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:cashPlanDetailsPanel']/table/tbody/tr[2]/td[3]/input[1]")
	WebElementFacade autoCashCheckBoxes;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:cashPlanDetailsPanel']/table/tbody/tr[2]/td[3]/input[2]")
	WebElementFacade autoCashCheckBoxesMinPlan;

	@FindBy(linkText = "Cancel")
	WebElementFacade autoCashCancel;

	@FindBy(name = "autocashSubview:autocashForm:j_id4641")
	WebElementFacade autoCashCheckBoxes2;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanUnitSelection:0']")
	WebElementFacade radioCashTriggerTargetDollars;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanUnitSelection:1")
	WebElementFacade radioCashTriggerTargetPercentage;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlancashTargetInputD")
	WebElementFacade cashTargetAmount;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTargetInputD")
	WebElementFacade cashTargetAmountWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTriggerInputD")
	WebElementFacade cashashTriggerToBuyAmountWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlancashTargetInputP")
	WebElementFacade cashTargetAmountInPercent;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlancashTriggerInputD")
	WebElementFacade cashashTriggerToBuyAmount;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlancashTriggerInputP")
	WebElementFacade cashashTriggerToBuyAmountInPercent;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanInvestmentLimitInput")
	WebElementFacade investmentLimitAmount;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanallocationMethod:1']")
	WebElementFacade allocationMethodPercentage;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanallocationMethod:1']")
	WebElementFacade allocationMethodPercentageWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id4860")
	WebElementFacade investmentOptions;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:j_id5164")
	WebElementFacade investmentOptionsWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:autocashMaxIMFOptions:0")
	WebElementFacade investmentOptionList;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:availableMaxIMFCheckAll")
	WebElementFacade investmentOptionSelectAll;

	@FindBy(name = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:autocashMaxIMFOptions")
	List<WebElementFacade> invOptionIMFCheckboxList;

	@FindBy(name = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:autocashMinIMFOptions")
	List<WebElementFacade> invOptionIMFCheckboxListWithMinOption;

	// autocashSubview:autocashForm:minPlanAutocashPlanSubView:autocashMinIMFOptions:0

	/// autocashSubview:autocashForm:minPlanAutocashPlanSubView:autocashMinIMFOptions

	@FindBy(name = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:autocashMaxSMAOptions")
	List<WebElementFacade> invOptionSMACheckboxList;

	@FindBy(name = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:autocashMinSMAOptions")
	List<WebElementFacade> invOptionSMACheckboxListWithMinOption;

	// @FindBy(id =
	// "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id4842")
	// @FindBy(xpath=".//*[@id^='autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id4845']/span")
	/*
	 * @FindBy(id =
	 * "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id4845")
	 * WebElementFacade okButton;
	 */
	// By.cssSelector("*[id^='tile'][id$='input']")

	// autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id4845

	// WebElement
	// okButton=this.getDriver().findElement(By.xpath("//*[contains(@id,'autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id484')]"));

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:j_id5147")
	WebElementFacade okButtonWithMinOption;

	/*
	 * @FindBy(id = "autocashSubview:autocashForm:j_id5317") WebElementFacade
	 * backButton;
	 */

	// WebElement
	// backButton=this.getDriver().findElement(By.xpath("//*[contains(@id,'autocashSubview:autocashForm:j_id531')]"));

	// Define Text Fields within autoCash screen
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashManagedInvestmentDetailsTable:0:maxPlanautocashManagedFundTargetAllocationDecoration:maxPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField1;
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashManagedInvestmentDetailsTable:1:maxPlanautocashManagedFundTargetAllocationDecoration:maxPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField2;
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashSMADetailsTable:0:maxPlanautocashSMATargetAllocationDecoration:maxPlanautocashSMATargetAllocation")
	WebElementFacade textField3;
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashSMADetailsTable:1:maxPlanautocashSMATargetAllocationDecoration:maxPlanautocashSMATargetAllocation")
	WebElementFacade textField4;

	// Min option
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:0:minPlanautocashManagedFundTargetAllocationDecoration:minPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField1WithMinOption;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:1:minPlanautocashManagedFundTargetAllocationDecoration:minPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField2WithMinOption;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:0:minPlanautocashSMATargetAllocationDecoration:minPlanautocashSMATargetAllocation")
	WebElementFacade textField3WithMinOption;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:1:minPlanautocashSMATargetAllocationDecoration:minPlanautocashSMATargetAllocation")
	WebElementFacade textField4WithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:0:minPlanautocashManagedFundPriorityAllocationDecoration:minPlanautocashManagedFundPriorityAllocation")
	WebElementFacade textField1WithMinOptionWithPriority;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:1:minPlanautocashManagedFundPriorityAllocationDecoration:minPlanautocashManagedFundPriorityAllocation")
	WebElementFacade textField2WithMinOptionWithPriority;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:0:minPlanautocashSMAPriorityAllocationDecoration:minPlanautocashSMAPriorityAllocation")
	WebElementFacade textField3WithMinOptionWithPriority;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:1:minPlanautocashSMAPriorityAllocationDecoration:minPlanautocashSMAPriorityAllocation")
	WebElementFacade textField4WithMinOptionWithPriority;

	// min option
	@FindBy(id = "autocashSubview:autocashForm:authorisationSubView:authorisationPasswordDecoration:authorisationPassword")
	WebElementFacade textField5;
	@FindBy(id = "autocashSubview:autocashForm:j_id5482")
	WebElementFacade textField6;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashTotal")
	WebElementFacade totalText;

	@FindBy(css = ".primary-button")
	WebElementFacade nextButtonCss;

	@FindBy(id = "autocashSubview:autocashForm:j_id5326")
	WebElementFacade authoriseButton;

	@FindBy(id = "autocashSubview:autocashForm:j_id4603")
	WebElementFacade printButton;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanallocationMethod:0")
	WebElementFacade allocationMethodProportional;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanallocationMethod:0")
	WebElementFacade allocationMethodProportionalWithMinPlan;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanUnitSelection:1']")
	WebElementFacade percentagePortfolioValueWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTargetInputP")
	WebElementFacade cashTargetWithPercentagePOrtfolioWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTriggerInputP")
	WebElementFacade cashTriggerWithPercentagePOrtfolioWithMinOption;

	// @FindBy(css="#autocashSubview\3a autocashForm\3a errormessages > li")
	// @FindBy(id="autocashSubview:autocashForm:errormessages")
	@FindBy(xpath = "//*[@id='autocashSubview:autocashForm:errormessages']/li")
	List<WebElementFacade> errorMaxDollarCashTriggerGreaterThanCashTarget;

	@FindBy(css = "#autocashSubview\3a autocashForm\3a errormessages > li")
	List<WebElementFacade> errorMinDollarCashTargetGreaterThanCashTrigger;

	@FindBy(linkText = "Remove")
	List<WebElementFacade> removeButtonList;

	public void clickMaxPlan() {
		System.out.println("visiDDDDDDDDDDDDDD: " + autoCashCheckBoxes.isCurrentlyVisible());
		Checkbox checkbox = new Checkbox(autoCashCheckBoxes);
		checkbox.setChecked(true);
	}

	public void UnClickMaxPlan() {
		Checkbox checkbox = new Checkbox(autoCashCheckBoxes);
		System.out.println("visi: " + autoCashCheckBoxes.isCurrentlyVisible());
		checkbox.setChecked(false);
	}

	public void clickMinPlan() {
		System.out.println("visi: " + autoCashCheckBoxesMinPlan.isCurrentlyVisible());
		Checkbox checkbox = new Checkbox(autoCashCheckBoxesMinPlan);
		checkbox.setChecked(true);
	}

	public void UnClickMinPlan() {
		Checkbox checkbox = new Checkbox(autoCashCheckBoxesMinPlan);
		checkbox.setChecked(false);
	}

	public void clickCashTargetDollars() {
	}

	public void clickCashTargetPercentage() {
		radioCashTriggerTargetPercentage.click();
	}

	public void enterCashTargetAmount(String amount) {
		cashTargetAmount.clear();
		cashTargetAmount.sendKeys(amount);
		cashTargetAmount.sendKeys(Keys.TAB);
	}

	public void enterCashTriggerAmount(String amount) {
		cashashTriggerToBuyAmount.clear();
		cashashTriggerToBuyAmount.sendKeys(amount);
		cashashTriggerToBuyAmount.sendKeys(Keys.TAB);
	}

	public void enterCashTargetAmountInPercentage(String amount) throws InterruptedException {
		Thread.sleep(6000);
		cashTargetAmountInPercent.clear();
		cashTargetAmountInPercent.sendKeys(amount);
		cashTargetAmountInPercent.sendKeys(Keys.TAB);
	}

	public void enterCashTriggerAmountInPercentage(String amount) {
		cashashTriggerToBuyAmountInPercent.clear();
		cashashTriggerToBuyAmountInPercent.sendKeys(amount);
		cashashTriggerToBuyAmountInPercent.sendKeys(Keys.TAB);
	}

	public void enterInvestmentLimitAmount(String amount) {
		investmentLimitAmount.clear();
		investmentLimitAmount.sendKeys(amount);
		investmentLimitAmount.sendKeys(Keys.TAB);
	}

	public void selectAllocationMethodInPercentage() {
		allocationMethodPercentage.click();
	}

	public void selectAllocationMethodInProportional() {
		allocationMethodProportional.click();
	}

	public void selectAllocationMethodInProportionalWithMinPlan() {
		allocationMethodProportionalWithMinPlan.click();
	}

	public void selectInvestmentOptions() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
		WebElement investmentOptions = this.getDriver().findElement(By.cssSelector(".drop-button"));
		investmentOptions.click();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void selectingMultipleInvestmentOptions(String percent1, String percent2, String percent3, String percent4)
			throws InterruptedException {

		Thread.sleep(4000);
		invOptionIMFCheckboxList.forEach(webElementFacade -> {
			// webElementFacade.waitUntilVisible();
			// webElementFacade.waitUntilClickable();
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});
		invOptionSMACheckboxList.forEach(webElementFacade -> {
			// webElementFacade.waitUntilVisible();
			// webElementFacade.waitUntilClickable();
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});

		// WebElement
		// okButton=this.getDriver().findElement(By.xpath("//*[contains(@id,'autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id484')]"));
		// WebElement
		// okButton=this.getDriver().findElement(By.cssSelector(".sml-scndry-button"));
		WebElement okButton = this.getDriver().findElement(By.linkText("OK"));
		// OK

		okButton.click();
		Thread.sleep(4000);
		int sumTotal = Integer.parseInt(percent1);
		List<WebElement> managedInvestmentList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,'maxPlanautocashManagedFundTargetAllocationDecoration:maxPlanautocashManagedFundTargetAllocation')]"));
		List<WebElement> separatelyManagedAccountList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,'maxPlanautocashSMATargetAllocationDecoration:maxPlanautocashSMATargetAllocation')]"));

		equallyDistributedPercent(managedInvestmentList, separatelyManagedAccountList);
		Thread.sleep(2000);
	}

	public void equallyDistributedPercent(List<WebElement> managedInvestmentList,
			List<WebElement> separatelyManagedAccountList) {
		AtomicInteger atomicIntegerForSMA = new AtomicInteger(0);
		AtomicInteger atomicIntegerForMI = new AtomicInteger(0);
		if ((null == separatelyManagedAccountList || separatelyManagedAccountList.size() == 0)
				&& (null != managedInvestmentList && managedInvestmentList.size() > 0)) {
			int percentageDistributionForMI = 100 / managedInvestmentList.size();
			final int leftOverMI = 100 - (percentageDistributionForMI * managedInvestmentList.size());

			managedInvestmentList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForMI + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForMI.getAndIncrement();
				if (leftOverMI != 0 && atomicIntegerForMI.get() == managedInvestmentList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverMI + percentageDistributionForMI) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});
		} else if ((null != separatelyManagedAccountList && separatelyManagedAccountList.size() > 0)
				&& (null == managedInvestmentList || managedInvestmentList.size() == 0)) {
			int percentageDistributionForSMA = 100 / separatelyManagedAccountList.size();
			int leftOverSMA = 100 - (percentageDistributionForSMA * separatelyManagedAccountList.size());

			separatelyManagedAccountList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForSMA + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForSMA.getAndIncrement();
				if (leftOverSMA != 0 && atomicIntegerForSMA.get() == separatelyManagedAccountList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverSMA + percentageDistributionForSMA) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});
		} else {
			int percentageDistributionForMI = 50 / managedInvestmentList.size();
			int leftOverMI = 50 - (percentageDistributionForMI * managedInvestmentList.size());
			int percentageDistributionForSMA = 50 / separatelyManagedAccountList.size();
			int leftOverSMA = 50 - (percentageDistributionForSMA * separatelyManagedAccountList.size());
			managedInvestmentList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForMI + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForMI.getAndIncrement();
				if (leftOverMI != 0 && atomicIntegerForMI.get() == managedInvestmentList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverMI + percentageDistributionForMI) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});
			separatelyManagedAccountList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForSMA + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForSMA.getAndIncrement();
				if (leftOverSMA != 0 && atomicIntegerForSMA.get() == separatelyManagedAccountList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverSMA + percentageDistributionForSMA) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});

		}
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {

		}

	}

	// Min option start
	public void selectInvestmentOptionsWithMinOption() {
		// investmentOptionsWithMinOption.click();
		// WebElement
		// investmentOptionsWithMinOption=this.getDriver().findElement(By.cssSelector(".drop-button"));
		//
		// investmentOptionsWithMinOption.click();

		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
		WebElement investmentOptions = this.getDriver().findElement(By.cssSelector(".drop-button"));
		investmentOptions.click();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void selectingMultipleInvestmentOptionsWithMinOption(String percent1, String percent2, String percent3,
			String percent4) throws InterruptedException {

		Thread.sleep(4000);
		invOptionIMFCheckboxListWithMinOption.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});
		invOptionSMACheckboxListWithMinOption.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});

		// WebElement
		// okButtonWithMinOption=this.getDriver().findElement(By.xpath("//*[contains(@id,'autocashSubview:autocashForm:minPlanAutocashPlanSubView:j_id515')]"));
		WebElement okButtonWithMinOption = this.getDriver().findElement(By.linkText("OK"));
		okButtonWithMinOption.click();

		Thread.sleep(3000);

		List<WebElement> managedInvestmentList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,'minPlanautocashManagedFundTargetAllocationDecoration:minPlanautocashManagedFundTargetAllocation')]"));
		List<WebElement> separatelyManagedAccountList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,'minPlanautocashSMATargetAllocationDecoration:minPlanautocashSMATargetAllocation')]"));
		equallyDistributedPercent(managedInvestmentList, separatelyManagedAccountList);

		Thread.sleep(2000);

		// authoriseButton.click();

	}

	public void selectingMultipleInvestmentOptionsWithMinOptionWithPriority(String priority1, String priority2,
			String priority3, String priority4) throws InterruptedException {

		/*
		 * Thread.sleep(4000);
		 * invOptionIMFCheckboxListWithMinOption.forEach(webElementFacade -> {
		 * Checkbox checkbox = new Checkbox(webElementFacade);
		 * checkbox.setChecked(true); });
		 * invOptionSMACheckboxListWithMinOption.forEach(webElementFacade -> {
		 * Checkbox checkbox = new Checkbox(webElementFacade);
		 * checkbox.setChecked(true); });
		 * 
		 * //Thread.sleep(3000); //okButtonWithMinOption.click(); // WebElement
		 * okButtonWithMinOption=this.getDriver().findElement(By.xpath(
		 * "//*[contains(@id,'autocashSubview:autocashForm:minPlanAutocashPlanSubView:j_id515')]"
		 * )); // okButtonWithMinOption.click(); // WebElement
		 * okButtonWithMinOption=this.getDriver().findElement(By.linkText("OK"))
		 * ; // okButtonWithMinOption.click();
		 * 
		 * WebElement
		 * okButtonWithMinOption1=this.getDriver().findElement(By.xpath(
		 * "//*[contains(@id,'autocashSubview:autocashForm:minPlanAutocashPlanSubView:j_id')]"
		 * )); okButtonWithMinOption1.click();
		 * 
		 * Thread.sleep(3000);
		 */

		List<WebElement> managedInvestmentList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,'minPlanautocashManagedFundPriorityAllocationDecoration:minPlanautocashManagedFundPriorityAllocation')]"));
		List<WebElement> separatelyManagedAccountList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,'minPlanautocashSMAPriorityAllocationDecoration:minPlanautocashSMAPriorityAllocation')]"));

		// autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:0:minPlanautocashManagedFundPriorityAllocationDecoration:minPlanautocashManagedFundPriorityAllocation
		AtomicInteger atomicInteger = new AtomicInteger(0);
		managedInvestmentList.forEach(textField -> {
			atomicInteger.getAndIncrement();
			textField.clear();
			textField.sendKeys(atomicInteger.get() + "");
			textField.sendKeys(Keys.TAB);
		});
		separatelyManagedAccountList.forEach(textField -> {
			atomicInteger.getAndIncrement();
			textField.clear();
			textField.sendKeys(atomicInteger.get() + "");
			textField.sendKeys(Keys.TAB);
		});

		System.out.println("R1 LIST SIZE=" + managedInvestmentList.size());
		// System.out.println("R2 LIST SIZE="+managedInvestmentList.size());

		// secondField.sendKeys(Keys.TAB);

		Thread.sleep(1000);

		// authoriseButton.click();

	}
	// min option ends

	public void selectingMultipleInvestmentOptionsWithProportion() throws InterruptedException {
		Thread.sleep(4000);
		invOptionIMFCheckboxList.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});
		invOptionSMACheckboxList.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});
		WebElement okButton = this.getDriver().findElement(
				By.xpath("//*[contains(@id,'autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id484')]"));
		okButton.click();
		Thread.sleep(5000);
	}

	public void clickCancel() {
		autoCashCancel.click();
	}

	public void clickBack() {

		// WebElement
		// backButton=this.getDriver().findElement(By.xpath("//*[contains(@id,'autocashSubview:autocashForm:j_id532')]"));
		WebElement backButton = this.getDriver().findElement(By.linkText("Back"));
		backButton.click();
	}

	public void clickNext() throws InterruptedException {
		nextButtonCss.click();
		Thread.sleep(5000);
	}

	public void clickRemove() {
		removeButtonList.stream().forEach(removeButton -> {
			if (removeButton.isCurrentlyVisible()) {
				removeButton.click();
			}
		});
	}

	public void entersCashTargetAmountWithMinOption(String amount) {
		cashTargetAmountWithMinOption.clear();
		cashTargetAmountWithMinOption.sendKeys(amount);
		cashTargetAmountWithMinOption.sendKeys(Keys.TAB);
	}

	public void entersCashTriggerAmountWithMinOption(String amount) {
		cashashTriggerToBuyAmountWithMinOption.clear();
		cashashTriggerToBuyAmountWithMinOption.sendKeys(amount);
		cashashTriggerToBuyAmountWithMinOption.sendKeys(Keys.TAB);
	}

	public void selectAllocationMethodInPercentageWithMinOption() {
		allocationMethodPercentageWithMinOption.click();
	}

	public void clickPercentagePortfolioValueWithMinOption() throws InterruptedException {
		percentagePortfolioValueWithMinOption.click();
		Thread.sleep(4000);
	}

	public void setCashTargetWIthPercentagePortfolioWithMinOption(String amount) throws InterruptedException {
		cashTargetWithPercentagePOrtfolioWithMinOption.clear();
		cashTargetWithPercentagePOrtfolioWithMinOption.sendKeys(amount);
		cashTargetWithPercentagePOrtfolioWithMinOption.sendKeys(Keys.TAB);
		Thread.sleep(2000);
	}

	public void setCashTriggerWIthPercentagePortfolioWithMinOption(String amount) throws InterruptedException {
		cashTriggerWithPercentagePOrtfolioWithMinOption.clear();
		cashTriggerWithPercentagePOrtfolioWithMinOption.sendKeys(amount);
		cashTriggerWithPercentagePOrtfolioWithMinOption.sendKeys(Keys.TAB);
		Thread.sleep(2000);
	}

	public boolean validatesErrorMaxDollarCashTriggerGreaterThanCashTarget(String error) throws InterruptedException {
		Thread.sleep(4000);
		boolean errorFound = false;
		WebElement industries = this.getDriver().findElement(By.id("autocashSubview:autocashForm:errormessages"));
		List<WebElement> links = industries.findElements(By.tagName("li"));
		for (int i = 0; i < links.size(); i++) {
			if (links.get(i).getText().contains(error)) {
				errorFound = true;
				break;
			}
			System.out.println("TPTPTPTPPTPTPTPTPTPTPTP:Result:" + links.get(i).getText());
			System.out.println("TPTPTPTPPTPTPTPTPTPTPTP:Error:" + error);
		}

		return errorFound;
	}

	public boolean validatesErrorMinDollarCashTargetGreaterThanCashTrigger(String error) {
		Optional<WebElementFacade> errorMessage = errorMinDollarCashTargetGreaterThanCashTrigger.stream()
				.filter(element -> element.containsText(error)).findAny();
		// return
		// errorMaxDollarCashTriggerGreaterThanCashTarget.containsText(error);
		return errorMessage.isPresent();
	}

	/*
	 * public boolean
	 * validatesErrorMaxDollarCashTriggerGreaterThanCashTarget(String
	 * error)throws InterruptedException{ Thread.sleep(4000); //errors //
	 * List<WebElement> errorMaxDollarCashTriggerGreaterThanCashTarget=
	 * this.getDriver().findElements(By.cssSelector(".errors")); long
	 * count=errorMaxDollarCashTriggerGreaterThanCashTarget.stream().filter(
	 * element->element.getText().contains(error)).count(); //return
	 * errorMaxDollarCashTriggerGreaterThanCashTarget.containsText(error);
	 * errorMaxDollarCashTriggerGreaterThanCashTarget.forEach(webElement->
	 * System.out.println(
	 * "LINE################################################## "
	 * +webElement.getText())); // return (count!=0L);
	 * //*[@id="autocashSubview:autocashForm:errormessages"]/li[1]
	 * 
	 * Optional<WebElementFacade>
	 * errorMessage=errorMaxDollarCashTriggerGreaterThanCashTarget.stream().
	 * filter(element->element.containsText(error)).findAny(); //return
	 * errorMaxDollarCashTriggerGreaterThanCashTarget.containsText(error); //
	 * WebElement
	 * errorMaxDollarCashTriggerGreaterThanCashTarget=this.getDriver().
	 * findElement(By.id("autocashSubview:autocashForm:errormessages")); //
	 * WebElement industries = this.getDriver().findElement(By.cssSelector(
	 * "div.columns.three.alpha > ul")); // List<WebElement> links =
	 * errorMaxDollarCashTriggerGreaterThanCashTarget.findElements(By.tagName(
	 * "li")); // for (int i = 1; i < links.size(); i++) // { //
	 * System.out.println("PPPPPPPPPPPPPPPPPPPPPPPPP:"+links.get(i).getText());
	 * // }
	 * 
	 * 
	 * WebElement industries = this.getDriver().findElement(By.id(
	 * "autocashSubview:autocashForm:errormessages")); List<WebElement> links =
	 * industries.findElements(By.tagName("li")); for (int i = 0; i <
	 * links.size(); i++) {
	 * System.out.println("TPTPTPTPPTPTPTPTPTPTPTP:XXXXXXXXXXXXXX"+links.get(i).
	 * getText()); }
	 * 
	 * 
	 * List<WebElement> liElements = this.getDriver().findElements(By.xpath(
	 * ".//*[@id='autocashSubview:autocashForm:errormessages']/li"));
	 * System.out.println("TTTEST"+liElements);
	 * 
	 * for(int i=0; i <= liElements.size(); i++) { WebElement linkElement =
	 * this.getDriver().findElement(By.xpath(
	 * ".//*[@id='autocashSubview:autocashForm:errormessages']/li[" + i + "]"));
	 * System.out.println("TTYYTEST"+linkElement.getText());
	 * 
	 * }
	 * 
	 * return errorMessage.isPresent(); }
	 */

}
