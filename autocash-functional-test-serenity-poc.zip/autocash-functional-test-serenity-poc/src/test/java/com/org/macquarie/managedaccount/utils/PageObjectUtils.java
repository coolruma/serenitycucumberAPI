package com.org.macquarie.managedaccount.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.webdriver.WebDriverFacade;
import net.thucydides.core.webdriver.javascript.JavascriptExecutorFacade;

public class PageObjectUtils extends PageObject {

	static Properties properties;
	static String sutProfile = System.getProperty("sutProfile");

	public String getSUTValue(String sKey) throws IOException {
		return loadSUTProfile().getProperty(sKey);
	}

	private Properties loadSUTProfile() throws IOException {

		if (sutProfile.equals("local")) {
			properties = new Properties();
			properties.load(new FileInputStream("src/test/resources/profiles/local.properties"));
		}

		else if (sutProfile.equals("uat1")) {
			properties = new Properties();
			properties.load(new FileInputStream("src/test/resources/profiles/uat1.properties"));

		}

		else if (sutProfile.equals("uat2")) {
			properties = new Properties();
			properties.load(new FileInputStream("src/test/resources/profiles/uat2.properties"));

		}

		return properties;
	}

	public void scrollToWebElementFacade(WebElementFacade webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("arguments[0].scrollIntoView(true)", webElementToBeFocussed);
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollToWebElementAbove(WebElement webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("window.scrollTo(0," + webElementToBeFocussed.getLocation().y + "-100)");
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollToWebElementBelow(WebElement webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("window.scrollTo(0," + webElementToBeFocussed.getLocation().y + "+100)");
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollToWebElement(WebElement webElementToBeFocussed) {
		JavascriptExecutor je = (JavascriptExecutor) getDriver();
		je.executeScript("arguments[0].scrollIntoView(true)", webElementToBeFocussed);
		// webElementToBeFocussed.typeAndTab("");

	}

	public void scrollBy(final int ypos) {
		/*
		 * WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver())
		 * .getProxiedDriver();
		 * 
		 * JavascriptExecutor jse = (JavascriptExecutor) driver;
		 */
		JavascriptExecutorFacade js = new JavascriptExecutorFacade(getDriver());
		try {
			js.executeScript("scroll(0," + ypos + ")");
		} catch (Exception e) {
			System.out.println("-----Scroll Exception-----" + e.toString());
		}

	}

	public void zoomBy(int zoom) {
		WebDriver driver = ((WebDriverFacade) getDriver()).getProxiedDriver();

		JavascriptExecutor jse = (JavascriptExecutor) driver;

		try {
			jse.executeScript("document.body.style.zoom='" + zoom + "%'");

			// jse.executeScript("history.go(0)");

		} catch (Exception e) {
			System.out.println("-----Zoom Exception-----" + e);
		}
	}

	public List<WebElementFacade> findWebElementsForCss(String topElementClass) {
		return findAll(By.cssSelector(topElementClass));
	}

	public boolean isTextPresentInCSSSection(String topElementClass, String drawerTitle) throws InterruptedException {
		List<WebElementFacade> webElement = findWebElementsForCss(topElementClass);
		System.out.println("EXPECTED TO FIND:" + drawerTitle);
		for (WebElementFacade draw : webElement) {
			System.out.println("\n****FOUND *****\n:" + draw.getText().replace("\n", ""));

			if (draw.getText().replace("\n", "").contains(drawerTitle)) {
				System.out.println("\n****VALUE IS *****\n:" + draw.getText());
				return true;
			}
		}
		return false;
	}

	public WebElement fluentWaitElement(final By byType) {
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(7, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(byType);
			}
		});
		return element;
	}

	public WebElement fluentWaitElement(final By byType, int waitTime) {
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(waitTime, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(byType);
			}
		});
		return element;
	}

	// Please note - below is not working as expected.. It needs some time to
	// fix
	// basically this will be utilise to access dynamic object with serenity
	// methods.
	// for sync purpose please use fluentWaitElement
	public WebElementFacade fluentWaitElementSerenity(final By byType) {
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(7, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
		WebElementFacade element = wait.until(new Function<WebDriver, WebElementFacade>() {
			public WebElementFacade apply(WebDriver driver) {
				return element(byType);
			}
		});
		return element;
	}

	public WebElementFacade fluentWaitElementSerenity(final By byType, int waitTime) {
		// System.out.println("Jagrut" + LocalDateTime.now());
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(waitTime, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
		WebElementFacade element = wait.until(new Function<WebDriver, WebElementFacade>() {
			public WebElementFacade apply(WebDriver driver) {
				// System.out.println("Jagruthello" +
				// LocalDateTime.now());
				return element(byType);
			}
		});
		// System.out.println("Jagrut" + LocalDateTime.now());
		return element;
	}

	public void waitForInvisibility(WebElement webElement, int maxSeconds) {
		waitFor(1000).milliseconds();
		Long startTime = System.currentTimeMillis();
		try {
			while (System.currentTimeMillis() - startTime < maxSeconds * 1000 && webElement.isDisplayed()) {
			}
		} catch (StaleElementReferenceException e) {
			return;
		} catch (Exception exp) {
			return;
		}
	}

	public int randInt(int min, int max) {

		Random rand = new Random();

		int randomNum = rand.nextInt((max - min) + 1) + min;

		return randomNum;
	}

}
