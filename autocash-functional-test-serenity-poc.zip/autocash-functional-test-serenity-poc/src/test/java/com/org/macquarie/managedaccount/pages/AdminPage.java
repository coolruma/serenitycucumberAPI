package com.org.macquarie.managedaccount.pages;

import org.openqa.selenium.support.FindBy;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AdminPage extends PageObject {

	@FindBy(linkText = "Administration")
	public WebElementFacade administrationElement;

	@FindBy(linkText = "investment")
	public WebElementFacade investmentElement;

	@FindBy(linkText = "pension")
	public WebElementFacade pensionElement;

	@FindBy(linkText = "superannuation")
	public WebElementFacade superannuationElement;

	public void clickAdministrationtab() throws InterruptedException {
		administrationElement.click();
	}

	public void clickOnMaintainAnInvestmentAccountLink() throws InterruptedException {
		investmentElement.click();
	}

	public void clickOnMaintainPensionAccountLink() throws InterruptedException {

	}

}
