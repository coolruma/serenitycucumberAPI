package com.org.macquarie.managedaccount.pages;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.webelements.Checkbox;

public class MaintainSuperAnnuationAccountPage extends PageObject {

	@FindBy(id = "accountddsearchfld")
	public WebElementFacade searchAccountField;

	@FindBy(how = How.CSS, using = ".ui-corner-all")
	public WebElementFacade searchAutoCompleterTextAccountField;

	@FindBy(linkText = "automatic cash management")
	public WebElementFacade automaticCashMgmntText;

	@FindBy(linkText = "superannuation")
	public WebElementFacade superAnnuationElement;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:cashPlanDetailsPanel']/table/tbody/tr[2]/td[3]/input[1]")
	WebElementFacade autoCashCheckBoxes;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlancashTargetInputD")
	WebElementFacade cashTargetAmount;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlancashTriggerInputD")
	WebElementFacade cashashTriggerToBuyAmount;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanInvestmentLimitInput")
	WebElementFacade investmentLimitAmount;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id4860")
	WebElementFacade investmentOptions;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanallocationMethod:0")
	WebElementFacade allocationMethodProportionalForMaxPlan;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanallocationMethod:1")
	WebElementFacade allocationMethodPercentageForMaxPlan;

	@FindBy(name = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:autocashMaxIMFOptions")
	List<WebElementFacade> invOptionIMFCheckboxList;

	@FindBy(name = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:autocashMaxSMAOptions")
	List<WebElementFacade> invOptionSMACheckboxList;

	@FindBy(css = ".primary-button")
	WebElementFacade nextButtonCss;

	@FindBy(id = "autocashSubview:autocashForm:j_id5321")
	WebElementFacade backButton;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:cashPlanDetailsPanel']/table/tbody/tr[2]/td[3]/input[2]")
	WebElementFacade autoCashCheckBoxesMinPlan;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTargetInputD")
	WebElementFacade cashTargetAmountWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTriggerInputD")
	WebElementFacade cashashTriggerToBuyAmountWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanallocationMethod:0")
	WebElementFacade allocationMethodPriorityWithMinPlan;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:j_id5164")
	WebElementFacade investmentOptionsWithMinOption;

	@FindBy(name = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:autocashMinIMFOptions")
	List<WebElementFacade> invOptionIMFCheckboxListWithMinOption;

	@FindBy(name = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:autocashMinSMAOptions")
	List<WebElementFacade> invOptionSMACheckboxListWithMinOption;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanUnitSelection:1']")
	WebElementFacade percentagePortfolioValueWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTargetInputP")
	WebElementFacade cashTargetWithPercentagePOrtfolioWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlancashTriggerInputP")
	WebElementFacade cashTriggerWithPercentagePOrtfolioWithMinOption;

	@FindBy(xpath = ".//*[@id='autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanallocationMethod:1']")
	WebElementFacade allocationMethodPercentageWithMinOption;

	// Define Text Fields within autoCash screen
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashManagedInvestmentDetailsTable:0:maxPlanautocashManagedFundTargetAllocationDecoration:maxPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField1;
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashManagedInvestmentDetailsTable:1:maxPlanautocashManagedFundTargetAllocationDecoration:maxPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField2;
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashSMADetailsTable:0:maxPlanautocashSMATargetAllocationDecoration:maxPlanautocashSMATargetAllocation")
	WebElementFacade textField3;
	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:maxPlanautocashSMADetailsTable:1:maxPlanautocashSMATargetAllocationDecoration:maxPlanautocashSMATargetAllocation")
	WebElementFacade textField4;

	@FindBy(id = "autocashSubview:autocashForm:maxPlanAutocashPlanSubView:j_id4845")
	WebElementFacade okButton;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:j_id5151")
	WebElementFacade okButtonWithMinOption;

	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:0:minPlanautocashManagedFundPriorityAllocationDecoration:minPlanautocashManagedFundPriorityAllocation")
	WebElementFacade textField1WithMinOptionWithPriority;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:1:minPlanautocashManagedFundPriorityAllocationDecoration:minPlanautocashManagedFundPriorityAllocation")
	WebElementFacade textField2WithMinOptionWithPriority;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:0:minPlanautocashSMAPriorityAllocationDecoration:minPlanautocashSMAPriorityAllocation")
	WebElementFacade textField3WithMinOptionWithPriority;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:1:minPlanautocashSMAPriorityAllocationDecoration:minPlanautocashSMAPriorityAllocation")
	WebElementFacade textField4WithMinOptionWithPriority;

	// Min option
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:0:minPlanautocashManagedFundTargetAllocationDecoration:minPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField1WithMinOption;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:1:minPlanautocashManagedFundTargetAllocationDecoration:minPlanautocashManagedFundTargetAllocation")
	WebElementFacade textField2WithMinOption;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:0:minPlanautocashSMATargetAllocationDecoration:minPlanautocashSMATargetAllocation")
	WebElementFacade textField3WithMinOption;
	@FindBy(id = "autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashSMADetailsTable:1:minPlanautocashSMATargetAllocationDecoration:minPlanautocashSMATargetAllocation")
	WebElementFacade textField4WithMinOption;

	public void searchSuperAccount(String searchText) throws InterruptedException {
		searchAccountField.sendKeys(searchText);
		Thread.sleep(6000);
		searchAutoCompleterTextAccountField.click();
	}

	public void clickOnAutomaticCashManagement() throws InterruptedException {
		automaticCashMgmntText.click();
	}

	public void clickOnSuperAnnuationLink() throws InterruptedException {
		superAnnuationElement.click();
	}

	public void clickMaxPlan() {
		System.out.println("visiDDDDDDDDDDDDDD: " + autoCashCheckBoxes.isCurrentlyVisible());
		Checkbox checkbox = new Checkbox(autoCashCheckBoxes);
		checkbox.setChecked(true);
	}

	public void clickAllocationMethodAsPercentageForMaxPlan() {
		allocationMethodPercentageForMaxPlan.click();
	}

	public void clickAllocationMethodAsProportionalForMaxPlan() {
		allocationMethodProportionalForMaxPlan.click();
	}

	public void clickCashTargetDollars() {
	}

	public void enterCashTargetAmount(String amount) {
		cashTargetAmount.clear();
		cashTargetAmount.sendKeys(amount);
		cashTargetAmount.sendKeys(Keys.TAB);
	}

	public void enterCashTriggerAmount(String amount) {
		cashashTriggerToBuyAmount.clear();
		cashashTriggerToBuyAmount.sendKeys(amount);
		cashashTriggerToBuyAmount.sendKeys(Keys.TAB);
	}

	public void enterInvestmentLimitAmount(String amount) {
		investmentLimitAmount.clear();
		investmentLimitAmount.sendKeys(amount);
		investmentLimitAmount.sendKeys(Keys.TAB);
	}

	public void selectInvestmentOptions() {
		// investmentOptions.click();
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
		WebElement investmentOptions = this.getDriver().findElement(By.cssSelector(".drop-button"));
		investmentOptions.click();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void selectingMultipleInvestmentOptions(String percent1, String percent2, String percent3, String percent4)
			throws InterruptedException {

		Thread.sleep(2000);
		invOptionIMFCheckboxList.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});
		invOptionSMACheckboxList.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});

		// okButton.click();
		WebElement okButton = this.getDriver().findElement(By.linkText("OK"));
		okButton.click();
		Thread.sleep(2000);

		// Enter Details in Text field of AutoCash Management screen When Option
		// selected is Percentage

		int sumTotal = Integer.parseInt(percent1);

		textField1.clear();
		textField1.sendKeys(percent1);
		textField1.sendKeys(Keys.TAB);

		if (sumTotal != 100) {
			textField2.clear();
			textField2.sendKeys(percent2);
			textField2.sendKeys(Keys.TAB);
			sumTotal += Integer.parseInt(percent2);
		}

		if (sumTotal != 100) {
			textField3.clear();
			textField3.sendKeys(percent3);
			textField3.sendKeys(Keys.TAB);
			sumTotal += Integer.parseInt(percent3);
		}
		if (sumTotal != 100) {
			textField4.clear();
			textField4.sendKeys(percent4);
			textField4.sendKeys(Keys.TAB);
			sumTotal += Integer.parseInt(percent4);
		}

		Thread.sleep(1000);
	}

	public void clickNext() throws InterruptedException {
		nextButtonCss.click();
		Thread.sleep(4000);
	}

	public void clickBack() {
		WebElement backButton = this.getDriver().findElement(By.linkText("Back"));
		backButton.click();
	}

	public void UnClickMaxPlan() {
		Checkbox checkbox = new Checkbox(autoCashCheckBoxes);
		System.out.println("visi: " + autoCashCheckBoxes.isCurrentlyVisible());
		checkbox.setChecked(false);
	}

	public void clickMinPlan() {
		System.out.println("visi: " + autoCashCheckBoxesMinPlan.isCurrentlyVisible());
		Checkbox checkbox = new Checkbox(autoCashCheckBoxesMinPlan);
		checkbox.setChecked(true);
	}

	public void entersCashTargetAmountWithMinOption(String amount) {
		cashTargetAmountWithMinOption.clear();
		cashTargetAmountWithMinOption.sendKeys(amount);
		cashTargetAmountWithMinOption.sendKeys(Keys.TAB);
	}

	public void entersCashTriggerAmountWithMinOption(String amount) {
		cashashTriggerToBuyAmountWithMinOption.clear();
		cashashTriggerToBuyAmountWithMinOption.sendKeys(amount);
		cashashTriggerToBuyAmountWithMinOption.sendKeys(Keys.TAB);
	}

	public void selectAllocationMethodInProportionalWithMinPlan() {
		allocationMethodPriorityWithMinPlan.click();
	}

	public void selectInvestmentOptionsWithMinOption() {
		investmentOptionsWithMinOption.click();
	}

	public void selectingMultipleInvestmentOptionsWithMinOptionWithPriority(String priority1, String priority2,
			String priority3, String priority4) throws InterruptedException {

		Thread.sleep(2000);
		invOptionIMFCheckboxListWithMinOption.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});
		invOptionSMACheckboxListWithMinOption.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});

		// okButtonWithMinOption.click();
		WebElement okButton = this.getDriver().findElement(By.linkText("OK"));
		okButton.click();
		Thread.sleep(2000);

		// Enter Details in Text field of AutoCash Management screen When Option
		// selected is Percentage
		if (textField1WithMinOptionWithPriority.isCurrentlyVisible()) {
			textField1WithMinOptionWithPriority.clear();
			textField1WithMinOptionWithPriority.sendKeys(priority1);
			textField1WithMinOptionWithPriority.sendKeys(Keys.TAB);
		}

		if (textField2WithMinOptionWithPriority.isCurrentlyVisible()) {
			textField2WithMinOptionWithPriority.clear();
			textField2WithMinOptionWithPriority.sendKeys(priority2);
			textField2WithMinOptionWithPriority.sendKeys(Keys.TAB);
		}

		if (textField3WithMinOptionWithPriority.isCurrentlyVisible()) {
			textField3WithMinOptionWithPriority.clear();
			textField3WithMinOptionWithPriority.sendKeys(priority3);
			textField3WithMinOptionWithPriority.sendKeys(Keys.TAB);
		}

		if (textField4WithMinOptionWithPriority.isCurrentlyVisible()) {
			textField4WithMinOptionWithPriority.clear();
			textField4WithMinOptionWithPriority.sendKeys(priority4);
			textField4WithMinOptionWithPriority.sendKeys(Keys.TAB);
		}
		// secondField.sendKeys(Keys.TAB);

		Thread.sleep(1000);
	}

	public void selectingMultipleInvestmentOptionsWithMinOption(String percent1, String percent2, String percent3,
			String percent4) throws InterruptedException {

		Thread.sleep(2000);
		invOptionIMFCheckboxListWithMinOption.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});
		invOptionSMACheckboxListWithMinOption.forEach(webElementFacade -> {
			Checkbox checkbox = new Checkbox(webElementFacade);
			checkbox.setChecked(true);
		});

		// okButtonWithMinOption.click();
		WebElement okButton = this.getDriver().findElement(By.linkText("OK"));
		okButton.click();
		Thread.sleep(2000);

		int sumTotal = Integer.parseInt(percent1);
		List<WebElement> managedInvestmentList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,':minPlanautocashManagedFundTargetAllocationDecoration:minPlanautocashManagedFundTargetAllocation')]"));

		// managedInvestmentList=managedInvestmentList.stream().filter(webElement->
		// webElement.)
		List<WebElement> separatelyManagedAccountList = this.getDriver().findElements(By.xpath(
				"//*[contains(@id,'minPlanautocashSMATargetAllocationDecoration:minPlanautocashSMATargetAllocation')]"));
		// autocashSubview:autocashForm:minPlanAutocashPlanSubView:minPlanautocashManagedInvestmentDetailsTable:0:minPlanautocashManagedFundTargetAllocationDecoration:minPlanautocashManagedFundTargetAllocation
		equallyDistributedPercent(managedInvestmentList, separatelyManagedAccountList);
		Thread.sleep(2000);

		// Enter Details in Text field of AutoCash Management screen When Option
		// selected is Percentage

		System.out.println("RM LIST SIZE=" + managedInvestmentList.size());
		Thread.sleep(1000);

	}

	public void equallyDistributedPercent(List<WebElement> managedInvestmentList,
			List<WebElement> separatelyManagedAccountList) {
		AtomicInteger atomicIntegerForSMA = new AtomicInteger(0);
		AtomicInteger atomicIntegerForMI = new AtomicInteger(0);
		if ((null == separatelyManagedAccountList || separatelyManagedAccountList.size() == 0)
				&& (null != managedInvestmentList && managedInvestmentList.size() > 0)) {
			int percentageDistributionForMI = 100 / managedInvestmentList.size();
			final int leftOverMI = 100 - (percentageDistributionForMI * managedInvestmentList.size());

			managedInvestmentList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForMI + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForMI.getAndIncrement();
				if (leftOverMI != 0 && atomicIntegerForMI.get() == managedInvestmentList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverMI + percentageDistributionForMI) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});
		} else if ((null != separatelyManagedAccountList && separatelyManagedAccountList.size() > 0)
				&& (null == managedInvestmentList || managedInvestmentList.size() == 0)) {
			int percentageDistributionForSMA = 100 / separatelyManagedAccountList.size();
			int leftOverSMA = 100 - (percentageDistributionForSMA * separatelyManagedAccountList.size());

			separatelyManagedAccountList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForSMA + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForSMA.getAndIncrement();
				if (leftOverSMA != 0 && atomicIntegerForSMA.get() == separatelyManagedAccountList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverSMA + percentageDistributionForSMA) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});
		} else {
			int percentageDistributionForMI = 50 / managedInvestmentList.size();
			int leftOverMI = 50 - (percentageDistributionForMI * managedInvestmentList.size());
			int percentageDistributionForSMA = 50 / separatelyManagedAccountList.size();
			int leftOverSMA = 50 - (percentageDistributionForSMA * separatelyManagedAccountList.size());
			managedInvestmentList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForMI + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForMI.getAndIncrement();
				if (leftOverMI != 0 && atomicIntegerForMI.get() == managedInvestmentList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverMI + percentageDistributionForMI) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});
			separatelyManagedAccountList.forEach(textfield -> {
				textfield.clear();
				textfield.sendKeys(percentageDistributionForSMA + "");
				textfield.sendKeys(Keys.TAB);
				atomicIntegerForSMA.getAndIncrement();
				if (leftOverSMA != 0 && atomicIntegerForSMA.get() == separatelyManagedAccountList.size()) {
					textfield.clear();
					textfield.sendKeys((leftOverSMA + percentageDistributionForSMA) + "");
					textfield.sendKeys(Keys.TAB);
				}
			});

		}
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {

		}

	}

	public void clickPercentagePortfolioValueWithMinOption() throws InterruptedException {
		percentagePortfolioValueWithMinOption.click();
		Thread.sleep(4000);
	}

	public void setCashTargetWIthPercentagePortfolioWithMinOption(String amount) throws InterruptedException {
		cashTargetWithPercentagePOrtfolioWithMinOption.clear();
		cashTargetWithPercentagePOrtfolioWithMinOption.sendKeys(amount);
		cashTargetWithPercentagePOrtfolioWithMinOption.sendKeys(Keys.TAB);
		Thread.sleep(2000);
	}

	public void setCashTriggerWIthPercentagePortfolioWithMinOption(String amount) throws InterruptedException {
		cashTriggerWithPercentagePOrtfolioWithMinOption.clear();
		cashTriggerWithPercentagePOrtfolioWithMinOption.sendKeys(amount);
		cashTriggerWithPercentagePOrtfolioWithMinOption.sendKeys(Keys.TAB);
		Thread.sleep(2000);
	}

	public void selectAllocationMethodInPercentageWithMinOption() {
		allocationMethodPercentageWithMinOption.click();
	}
}
