package com.org.macquarie.managedaccount.features.steps;

import org.junit.Assert;

import com.org.macquarie.managedaccount.pages.AutomaticCashManagement;
import com.org.macquarie.managedaccount.pages.MaintainPensionAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MaintainPensionAccountStep {

	MaintainPensionAccountPage currentPage;
	AutomaticCashManagement acm;

	@When("^User clicks on 'pension account'$")
	public void user_clicks_on_pension_account() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.clickOnPensionLink();
	}

	@Then("^'User Should be on maintain a pension account search page'$")
	public void user_Should_be_on_maintain_a_pension_account_search_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is on maintain a pension account search page$")
	public void user_is_on_maintain_a_pension_account_search_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^under pension,User enters \"([^\"]*)\"$")
	public void under_pension_User_enters(String account) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.searchPensionAccount(account);
	}

	@When("^under pension,clicks on 'automatic cash management'$")
	public void under_pension_clicks_on_automatic_cash_management() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.clickOnAutomaticCashManagement();
		Thread.sleep(10000);
	}

	@Then("^under pension, 'User Should be on Automatic Cash Management page with same 'O(\\d+)'$")
	public void under_pension_User_Should_be_on_Automatic_Cash_Management_page_with_same_O(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Given("^under pension, user is on Automatic Cash Management page$")
	public void under_pension_user_is_on_Automatic_Cash_Management_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		for (String winHandle : currentPage.getDriver().getWindowHandles()) {
			currentPage.getDriver().switchTo().window(winHandle);
		}
		currentPage.containsText("Automatic Cash Management");
		Assert.assertTrue((currentPage.containsText("Automatic Cash Management")));
	}

	@When("^under pension, User clicks on Maximum plan Buy investments with excess cash$")
	public void under_pension_User_clicks_on_Maximum_plan_Buy_investments_with_excess_cash() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.clickMaxPlan();
		Thread.sleep(2000);
	}

	@Then("^under pension,'Maximum Plan Buy pane opens'$")
	public void under_pension_Maximum_Plan_Buy_pane_opens() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		Assert.assertTrue((currentPage.containsText("Investment selection")));
		currentPage.getDriver().manage().window().maximize();
	}

	@Given("^under pension, user has selected Maximum plan Buy investments with excess cash option$")
	public void under_pension_user_has_selected_Maximum_plan_Buy_investments_with_excess_cash_option()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Assert.assertTrue((currentPage.containsText("Automatic Cash Management")));
	}

	@When("^under pension, User selects Dollars option$")
	public void under_pension_User_selects_Dollars_option() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.clickCashTargetDollars();
		Thread.sleep(2000);
	}

	@When("^under pension,user enters cash target amount in Dollars '(\\d+)'$")
	public void under_pension_user_enters_cash_target_amount_in_Dollars(int targetAmountInDollars) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(4000);
		currentPage.enterCashTargetAmount(targetAmountInDollars + "");
	}

	@When("^under pension,user enters cash trigger amount in Dollars '(\\d+)'$")
	public void under_pension_user_enters_cash_trigger_amount_in_Dollars(int triggerAmountInDollars) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.enterCashTriggerAmount(triggerAmountInDollars + "");
	}

	@When("^under pension,user enters investment limit amount '(\\d+)'$")
	public void under_pension_user_enters_investment_limit_amount(int limitAmountInDollars) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		currentPage.enterInvestmentLimitAmount(limitAmountInDollars + "");
	}

	@When("^under pension,user selects allocation method as percentage$")
	public void under_pension_user_selects_allocation_method_as_percentage() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.clickAllocationMethodAsPercentageForMaxPlan();
	}

	@When("^under pension,user selects Investment options \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void under_pension_user_selects_Investment_options_and_and_and(String percent1, String percent2,
			String percent3, String percent4) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.selectInvestmentOptions();
		currentPage.selectingMultipleInvestmentOptions(percent1, percent2, percent3, percent4);
	}

	@When("^under pension,clicks on Next$")
	public void under_pension_clicks_on_Next() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.clickNext();
	}

	@Then("^under pension,user should land on Automatic Cash Management authorize page$")
	public void under_pension_user_should_land_on_Automatic_Cash_Management_authorize_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Assert.assertTrue((currentPage.containsText("Review and authorise")));
		currentPage.clickBack();
	}

	@When("^under pension,user selects allocation method as proportional$")
	public void under_pension_user_selects_allocation_method_as_proportional() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Given("^under pension,user has selected Minimum plan Buy investments with excess cash option$")
	public void under_pension_user_has_selected_Minimum_plan_Buy_investments_with_excess_cash_option()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.UnClickMaxPlan();
		Thread.sleep(4000);
		currentPage.clickMinPlan();
	}

	@When("^under pension,user enters cash target amount in Dollars with minimum option '(\\d+)'$")
	public void under_pension_user_enters_cash_target_amount_in_Dollars_with_minimum_option(
			int targetAmountInDollarsMin) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.entersCashTargetAmountWithMinOption(targetAmountInDollarsMin + "");
	}

	@When("^under pension,user enters cash trigger amount in Dollars with minimum option '(\\d+)'$")
	public void under_pension_user_enters_cash_trigger_amount_in_Dollars_with_minimum_option(
			int triggerAmountInDollarsMin) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.entersCashTriggerAmountWithMinOption(triggerAmountInDollarsMin + "");
	}

	@When("^under pension,user selects allocation method as proportional for min plan$")
	public void under_pension_user_selects_allocation_method_as_proportional_for_min_plan() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^under pension,user selects Investment options for min plan with priority option \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void under_pension_user_selects_Investment_options_for_min_plan_with_priority_option_and_and_and(
			String priority1, String priority2, String priority3, String priority4) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.selectInvestmentOptionsWithMinOption();
		currentPage.selectingMultipleInvestmentOptionsWithMinOptionWithPriority(priority1, priority2, priority3,
				priority4);

	}

	@When("^under pension,user selects Percentage Portfolio Value with min plan$")
	public void under_pension_user_selects_Percentage_Portfolio_Value_with_min_plan() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.clickPercentagePortfolioValueWithMinOption();
	}

	@When("^under pension,user enters cash target amount in Percentage with min option '(\\d+)'$")
	public void under_pension_user_enters_cash_target_amount_in_Percentage_with_min_option(int targetAmountInPercsMin)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.setCashTargetWIthPercentagePortfolioWithMinOption(targetAmountInPercsMin + "");
	}

	@When("^under pension,user enters cash trigger amount in Percentage with min option '(\\d+)'$")
	public void under_pension_user_enters_cash_trigger_amount_in_Percentage_with_min_option(int triggerAmountInPercsMin)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.setCashTriggerWIthPercentagePortfolioWithMinOption(triggerAmountInPercsMin + "");
	}

	@When("^under pension,user selects allocation method as percentage for min plan$")
	public void under_pension_user_selects_allocation_method_as_percentage_for_min_plan() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		currentPage.selectAllocationMethodInPercentageWithMinOption();
	}

	@When("^under pension,user selects Investment options for min plan$")
	public void under_pension_user_selects_Investment_options_for_min_plan() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

}
