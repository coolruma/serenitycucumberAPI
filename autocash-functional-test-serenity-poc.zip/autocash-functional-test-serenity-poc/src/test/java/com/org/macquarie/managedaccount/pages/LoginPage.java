package com.org.macquarie.managedaccount.pages;

import org.openqa.selenium.support.FindBy;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class LoginPage extends PageObject {
	@FindBy(id = "username")
	public WebElementFacade userIdElement;

	@FindBy(id = "password")
	public WebElementFacade passwordElement;

	@FindBy(linkText = "Login")
	public WebElementFacade loginSubmit;

	public static boolean loggedInFlag = false;

	public void addLoginCredentialsAndSubmit(String userId, String password) throws InterruptedException {
		userIdElement.sendKeys(userId);
		passwordElement.sendKeys(password);
		loginSubmit.click();
		loggedInFlag = true;

	}
}
