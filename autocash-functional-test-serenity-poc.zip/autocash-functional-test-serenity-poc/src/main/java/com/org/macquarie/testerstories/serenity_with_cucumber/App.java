package com.org.macquarie.testerstories.serenity_with_cucumber;

public class App {

}
