package com.org.macquarie.managedaccount.utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.webdriver.WebDriverFacade;

// Wait Element by Type 
public class PageObjectUtils1 extends PageObject {
	
	public WebElement fluentWaitElement(final By byType) {
		
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(7, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(byType);
			}
		});
		return element;
	}
	
	public WebElement fluentWaitElement(final By byType, int waitTime) {
		WebDriver driver = (WebDriver) ((WebDriverFacade) getDriver())
				.getProxiedDriver();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(waitTime, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(byType);
			}
		});
		return element;
	}
	
}
