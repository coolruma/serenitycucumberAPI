package com.org.macquarie.managedaccount.pages;

import net.serenitybdd.core.pages.PageObject;

public class CurrentPage extends PageObject {
}
