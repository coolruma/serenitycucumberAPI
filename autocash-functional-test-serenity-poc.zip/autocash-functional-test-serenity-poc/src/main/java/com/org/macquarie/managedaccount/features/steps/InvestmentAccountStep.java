package com.org.macquarie.managedaccount.features.steps;

import com.org.macquarie.managedaccount.pages.AdminPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InvestmentAccountStep {
	
	AdminPage currentPage;
	
	@Given("^User is on Administration tab$")
	public void user_is_on_Administration_tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^User clicks on 'maintains an investment account'$")
	public void user_clicks_on_maintains_an_investment_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		currentPage.clickOnMaintainAnInvestmentAccountLink();
	}

	@Then("^'User Should be on maintain an investment account search page'$")
	public void user_Should_be_on_maintain_an_investment_account_search_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		if(!currentPage.containsText("maintain an investment account")){
			throw new RuntimeException("Error loading page");
		}else{
			System.out.println("Investment page was loaded");
		}
	}
}