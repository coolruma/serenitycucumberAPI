package com.org.macquarie.managedaccount.pages;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class MaintainInvestmentAccountPage extends PageObject{
	
	@FindBy(id="accountddsearchfld")
	public WebElementFacade searchAccountField;
	
	//@FindBy(how=How.CSS,using = "li.ui-menu-item:nth-of-type(-1)")
	//@FindBy(how=How.CSS,using = "li.ui-menu-item.ui-corner-all")
	@FindBy(how=How.CSS,using = ".ui-corner-all")
	public WebElementFacade searchAutoCompleterTextAccountField;
	
	@FindBy(linkText="automatic cash management")
	public WebElementFacade automaticCashMgmntText;
	
	
	public void searchAccount(String searchText) throws InterruptedException {
		searchAccountField.sendKeys(searchText);
		searchAutoCompleterTextAccountField.click();
		//*[@id="wraponline_template"]/ul/li/a
	}
	
	public void clickOnAutomaticCashManagement() throws InterruptedException {
		automaticCashMgmntText.click();
		//*[@id="wraponline_template"]/ul/li/a
	}

}
