package com.org.macquarie.managedaccount.pages;

import org.openqa.selenium.support.FindBy;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;


@DefaultUrl("https://secure-test.macquarie.com.au/sepas/serve?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&URL=%2Fpkmscdsso%3Fhttps%3A%2F%2Fwww-mastest2.macquarie.com.au%2Fwrapsolutions%2FPortfolioMgr&HOSTNAME=secure-test.macquarie.com.au&PROTOCOL=https")
public class LoginPage extends PageObject {
	@FindBy(id = "username")
	public WebElementFacade userIdElement;
	
	@FindBy(id = "password")
	public WebElementFacade passwordElement;
	
	@FindBy(linkText="Login")
	public WebElementFacade loginSubmit;
	
	public static boolean loggedInFlag=false;
	
	//@FindBy(linkText="Administration")
	//public WebElementFacade administrationElement;
	
	
	public void addLoginCredentialsAndSubmit(String userId,String password) throws InterruptedException {
		userIdElement.sendKeys(userId);
		passwordElement.sendKeys(password);
        loginSubmit.click();
        loggedInFlag=true;
        
      //  administrationElement.click();
      //  Thread.sleep(90000);
   }
	}
