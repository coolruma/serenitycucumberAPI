package com.org.macquarie.managedaccount.features.steps;

import com.org.macquarie.managedaccount.pages.MaintainInvestmentAccountPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MaintainAnInvestmentAccountStep {

	MaintainInvestmentAccountPage currentPage;
	@Given("^User is on maintain an investment account search page$")
	public void user_is_on_maintain_an_investment_account_search_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if(!currentPage.containsText("maintain an investment account")){
			throw new RuntimeException("Error loading page");
		}else{
			System.out.println("Investment page was loaded");
		}
	}

	@When("^User search an account number$")
	public void user_search_an_account_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		currentPage.searchAccount("V21840");
	}

	@When("^clicks on 'automatic cash management'$")
	public void clicks_on_automatic_cash_management() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		currentPage.clickOnAutomaticCashManagement();
		Thread.sleep(30000);
	}

	@Then("^'User Should be on Automatic Cash Management page'$")
	public void user_Should_be_on_Automatic_Cash_Management_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}
}
