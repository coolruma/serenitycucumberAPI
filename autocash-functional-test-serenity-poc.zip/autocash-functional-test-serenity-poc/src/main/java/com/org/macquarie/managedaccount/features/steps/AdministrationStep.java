package com.org.macquarie.managedaccount.features.steps;

import java.util.concurrent.TimeUnit;

import com.org.macquarie.managedaccount.pages.AdminPage;
import com.org.macquarie.managedaccount.pages.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AdministrationStep {
	
	AdminPage currentPage;
	LoginPage loginPage;
	
	@Given("^User is loggedin on Macquarie Wrap HomePage$")
	public void user_is_loggedin_on_Macquarie_Wrap_HomePage() throws Throwable {
		//currentPage.getTitle().equals("Macquarie Wrap");
		//if(!LoginPage.loggedInFlag){
			loginPage.open();
			loginPage.addLoginCredentialsAndSubmit("60006750","pass123");
		//}
		
	}

	@When("^User clicks on Administration tab$")
	public void user_clicks_on_Administration_tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		currentPage.clickAdministrationtab();
	}

	@Then("^'User Should be able to see Administration tab' on Macquarie Wrap HomePage$")
	public void user_Should_be_able_to_see_Administration_tab_on_Macquarie_Wrap_HomePage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		currentPage.setImplicitTimeout(2, TimeUnit.MINUTES);
	}

}
